// DAD.h : main header file for the DAD application
//

#if !defined(AFX_DAD_H__92DCBD06_DD48_11D3_B712_00A40080D29C__INCLUDED_)
#define AFX_DAD_H__92DCBD06_DD48_11D3_B712_00A40080D29C__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CDADApp:
// See DAD.cpp for the implementation of this class
//

class CDADApp : public CWinApp
{
public:
	CDADApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDADApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CDADApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DAD_H__92DCBD06_DD48_11D3_B712_00A40080D29C__INCLUDED_)

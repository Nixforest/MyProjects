// MyObject1.h: interface for the CMyObject1 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MYOBJECT1_H__29B0B58D_DE46_11D3_B712_00A40080D29C__INCLUDED_)
#define AFX_MYOBJECT1_H__29B0B58D_DE46_11D3_B712_00A40080D29C__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CMyObject1  
{
public:
	CString Data;
	CMyObject1();
	virtual ~CMyObject1();

};

#endif // !defined(AFX_MYOBJECT1_H__29B0B58D_DE46_11D3_B712_00A40080D29C__INCLUDED_)

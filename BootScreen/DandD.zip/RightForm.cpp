// RightForm.cpp : implementation file
//

#include "stdafx.h"
#include "DAD.h"
#include "RightForm.h"
#include "MyObject1.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRightForm

IMPLEMENT_DYNCREATE(CRightForm, CFormView)

CRightForm::CRightForm()
	: CFormView(CRightForm::IDD)
{
	//{{AFX_DATA_INIT(CRightForm)
	//}}AFX_DATA_INIT
}

CRightForm::~CRightForm()
{
}

void CRightForm::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRightForm)
	DDX_Control(pDX, IDC_LIST1, m_List);
	DDX_Control(pDX, IDC_EDIT1, m_Edit);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRightForm, CFormView)
	//{{AFX_MSG_MAP(CRightForm)
	ON_LBN_DBLCLK(IDC_LIST1, OnDblclkList1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRightForm diagnostics

#ifdef _DEBUG
void CRightForm::AssertValid() const
{
	CFormView::AssertValid();
}

void CRightForm::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CRightForm message handlers

void CRightForm::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();

	m_Edit.SetWindowText("This is text");

	CMyObject1* MyObj;

	MyObj = new CMyObject1(); //Don't forget to delete this object when through
	MyObj->Data = "String 1";
	int Pos = m_List.AddString( MyObj->Data  );
	m_List.SetItemDataPtr( Pos, (void*)MyObj );

	MyObj = new CMyObject1(); //Don't forget to delete this object when through
	MyObj->Data = "String 2";
	Pos = m_List.AddString( MyObj->Data  );
	m_List.SetItemDataPtr( Pos, (void*)MyObj );

	MyObj = new CMyObject1(); //Don't forget to delete this object when through
	MyObj->Data = "String 3";
	Pos = m_List.AddString( MyObj->Data  );
	m_List.SetItemDataPtr( Pos, (void*)MyObj );

	UpdateData( FALSE );

	m_Edit.Initialize( &m_Edit );
	m_List.Initialize( &m_List );

}

void CRightForm::OnDblclkList1() 
{
	int Pos = m_List.GetCurSel();
	if( LB_ERR == Pos )
		return;
	CMyObject1* MyObj = (CMyObject1*)m_List.GetItemDataPtr( Pos );
	MessageBox( "Performed some operation on MyObject1 containing the data " + MyObj->Data, "Wow this could be cool",MB_OK );
}

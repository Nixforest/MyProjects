// FamilyTree.cpp : implementation file
//

#include "stdafx.h"
#include "parsival.h"
#include "FamilyTree.h"
#include "Family.h"
#include "FamilyMaint.h"

#ifdef _DEBUG
//#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#ifdef _DEBUG
	#include <15d/rw/db/db.h>
#else
	#include <12d/rw/db/db.h>
#endif

extern RWDBDatabase aDB;
/////////////////////////////////////////////////////////////////////////////
// CFamilyTree

IMPLEMENT_DYNCREATE(CFamilyTree, CTreeView)

CFamilyTree::CFamilyTree()
{
}

CFamilyTree::~CFamilyTree()
{
}


BEGIN_MESSAGE_MAP(CFamilyTree, CTreeView)
	//{{AFX_MSG_MAP(CFamilyTree)
	ON_WM_CREATE()
	ON_NOTIFY_REFLECT(NM_DBLCLK, OnDblclk)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFamilyTree drawing

void CFamilyTree::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
}

/////////////////////////////////////////////////////////////////////////////
// CFamilyTree diagnostics

#ifdef _DEBUG
void CFamilyTree::AssertValid() const
{
	CTreeView::AssertValid();
}

void CFamilyTree::Dump(CDumpContext& dc) const
{
	CTreeView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CFamilyTree message handlers

void CFamilyTree::OnInitialUpdate() 
{
	CTreeView::OnInitialUpdate();
}

int CFamilyTree::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CTreeView::OnCreate(lpCreateStruct) == -1)
		return -1;

	AfxOleInit();
	CTreeCtrl* Tree = &GetTreeCtrl();
	BOOL x1 = DropTarget.Register( this );
 	return 0;
}

BOOL CFamilyTree::PreCreateWindow(CREATESTRUCT& cs) 
{
	cs.style |= TVS_HASLINES | TVS_LINESATROOT | TVS_HASBUTTONS  ;
	return CTreeView::PreCreateWindow(cs);
}

void CFamilyTree::OnDblclk(NMHDR* pNMHDR, LRESULT* pResult) 
{
	CFamilyMaint::PersonStruct* selected;
	CTreeCtrl* Tree = &GetTreeCtrl();

	HTREEITEM item = Tree->GetSelectedItem();
	if( item == NULL )
		return;

	selected = (CFamilyMaint::PersonStruct*)Tree->GetItemData( item );
	if( !selected->Family && selected->FamilyID)
		selected->Family = new CFamily( selected->FamilyID );
	if( Tree->ItemHasChildren( item ) ) //Double clicked at family level
		((CFamilyMaint*)GetParentFrame())->ShowFamily( selected );

	*pResult = 0;
}



DROPEFFECT CFamilyTree::OnDragEnter(COleDataObject* pDataObject, DWORD dwKeyState, CPoint point) 
{
	MessageBox( "Hello" );	
	return CTreeView::OnDragEnter(pDataObject, dwKeyState, point);
}

DROPEFFECT CFamilyTree::OnDragOver(COleDataObject* pDataObject, DWORD dwKeyState, CPoint point) 
{
		MessageBox( "Hello" );
	
	return CTreeView::OnDragOver(pDataObject, dwKeyState, point);
}

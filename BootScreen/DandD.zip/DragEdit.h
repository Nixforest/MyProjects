// DragEdit.h: interface for the CDragEdit class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DRAGEDIT_H__92DCBD1A_DD48_11D3_B712_00A40080D29C__INCLUDED_)
#define AFX_DRAGEDIT_H__92DCBD1A_DD48_11D3_B712_00A40080D29C__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
#include <afxole.h>
#include "DropTarget.h"
#include "DropSource.h"


/////////////////////////////////////////////////////////////////////////////
// CDragEdit window

class CDragEdit : public CEdit, public CDropTarget, public CDropSource
{
// Construction
public:
	CDragEdit();

    void operator delete(void* p)
        { CEdit::operator delete(p);
		  CDropTarget::operator delete(p); }


// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDragEdit)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDragEdit();

	// Generated message map functions
protected:
	virtual void CompleteMove();
	//{{AFX_MSG(CDragEdit)
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

/////////////////////////////////////////////////////////////////////////////
#endif // !defined(AFX_DRAGEDIT_H__92DCBD1A_DD48_11D3_B712_00A40080D29C__INCLUDED_)

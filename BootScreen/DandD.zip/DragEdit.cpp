// DragEdit.cpp : implementation file
//

#include "stdafx.h"
#include "DAD.h"
#include "DragEdit.h"
#include "MyObject1.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDragEdit

CDragEdit::CDragEdit()
{
}

CDragEdit::~CDragEdit()
{
}



BEGIN_MESSAGE_MAP(CDragEdit, CEdit)
	//{{AFX_MSG_MAP(CDragEdit)
	ON_WM_LBUTTONDOWN()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDragEdit message handlers

void CDragEdit::OnLButtonDown(UINT nFlags, CPoint point) 
{

	CEdit::OnLButtonDown(nFlags, point);
	CMyObject1* MyObj= new CMyObject1();
	GetWindowText( MyObj->Data );
	
	RECT rClient;
    GetClientRect(&rClient);

	StartDragging((DWORD)MyObj, &rClient, &point);
	return;
}

void CDragEdit::CompleteMove()
{
	SetWindowText("");    
}

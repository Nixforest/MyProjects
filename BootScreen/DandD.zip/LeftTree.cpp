// LeftTree.cpp : implementation file
//

#include "stdafx.h"
#include "DAD.h"
#include "LeftTree.h"
#include "MyObject1.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CLeftTree

IMPLEMENT_DYNCREATE(CLeftTree, CTreeView)

CLeftTree::CLeftTree()
{
}

CLeftTree::~CLeftTree()
{
}


BEGIN_MESSAGE_MAP(CLeftTree, CTreeView)
	//{{AFX_MSG_MAP(CLeftTree)
	ON_WM_LBUTTONDOWN()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLeftTree drawing

void CLeftTree::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
}

/////////////////////////////////////////////////////////////////////////////
// CLeftTree diagnostics

#ifdef _DEBUG
void CLeftTree::AssertValid() const
{
	CTreeView::AssertValid();
}

void CLeftTree::Dump(CDumpContext& dc) const
{
	CTreeView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CLeftTree message handlers

BOOL CLeftTree::PreCreateWindow(CREATESTRUCT& cs) 
{
	cs.style |= TVS_HASLINES | TVS_LINESATROOT | TVS_HASBUTTONS  ;
	
	return CTreeView::PreCreateWindow(cs);
}

void CLeftTree::OnInitialUpdate() 
{
	CTreeView::OnInitialUpdate();
	
	HTREEITEM LastRoot;
	HTREEITEM CurrentItem;

	CTreeCtrl* Tree = &GetTreeCtrl();

	LastRoot = Tree->InsertItem( "Left Tree Item 1", TVI_ROOT, TVI_LAST );
	CurrentItem = Tree->InsertItem( "Left Tree subitem 1-1", LastRoot, TVI_LAST );
	CurrentItem = Tree->InsertItem( "Left Tree subitem 1-2", LastRoot, TVI_LAST );
	CurrentItem = Tree->InsertItem( "Left Tree subitem 1-3", LastRoot, TVI_LAST );

	LastRoot = Tree->InsertItem( "Left Tree Item 2", TVI_ROOT, TVI_LAST );
	CurrentItem = Tree->InsertItem( "Left Tree subitem 2-1", LastRoot, TVI_LAST );
	CurrentItem = Tree->InsertItem( "Left Tree subitem 2-2", LastRoot, TVI_LAST );
	CurrentItem = Tree->InsertItem( "Left Tree subitem 2-3", LastRoot, TVI_LAST );	
}

void CLeftTree::OnLButtonDown(UINT nFlags, CPoint point) 
{
	CTreeView::OnLButtonDown(nFlags, point);
	CMyObject1* MyObj= new CMyObject1();

	CTreeCtrl* Tree = &GetTreeCtrl();
	CString Text = Tree->GetItemText(Tree->GetSelectedItem( ) );
	MyObj->Data = Text;

	RECT rClient;
    GetClientRect(&rClient);

	m_DropSource.StartDragging((DWORD)MyObj, &rClient, &point);

}

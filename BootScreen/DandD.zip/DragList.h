#if !defined(AFX_DRAGLIST_H__92DCBD1D_DD48_11D3_B712_00A40080D29C__INCLUDED_)
#define AFX_DRAGLIST_H__92DCBD1D_DD48_11D3_B712_00A40080D29C__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// DragList.h : header file
//
#include "DropTarget.h"
#include "DropSource.h"

/////////////////////////////////////////////////////////////////////////////
// CDragList window

class CDragList : public CListBox,	public CDropTarget, public CDropSource 
{
// Construction
public:
	CDragList();
   void operator delete(void* p)
        { CEdit::operator delete(p);
		  CDropTarget::operator delete(p); }
// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDragList)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDragList();
	virtual BOOL OnDrop(CWnd* pWnd, COleDataObject* pDataObject, DROPEFFECT dropEffect, CPoint point );
	// Generated message map functions
protected:
	virtual void CompleteMove();

	//{{AFX_MSG(CDragList)
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
private:
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DRAGLIST_H__92DCBD1D_DD48_11D3_B712_00A40080D29C__INCLUDED_)

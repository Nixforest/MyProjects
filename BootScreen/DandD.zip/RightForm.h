#if !defined(AFX_RIGHTFORM_H__92DCBD16_DD48_11D3_B712_00A40080D29C__INCLUDED_)
#define AFX_RIGHTFORM_H__92DCBD16_DD48_11D3_B712_00A40080D29C__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// RightForm.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CRightForm form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "DragEdit.h"
#include "DragList.h"

class CRightForm : public CFormView
{
protected:
	CRightForm();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CRightForm)

// Form Data
public:
	//{{AFX_DATA(CRightForm)
	enum { IDD = IDD_DIALOG1 };
	CDragList	m_List;
	CDragEdit	m_Edit;
	//}}AFX_DATA

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRightForm)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CRightForm();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CRightForm)
	afx_msg void OnDblclkList1();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_RIGHTFORM_H__92DCBD16_DD48_11D3_B712_00A40080D29C__INCLUDED_)

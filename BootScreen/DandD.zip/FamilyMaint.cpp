// FamilyMaint.cpp : implementation file
//

#include "stdafx.h"
#include "parsival.h"
#include "FamilyMaint.h"
#include "FamilyTree.h"
#include "SearchDlg.h"
#include "FamilyMaintDlg.h"

#ifdef _DEBUG
//#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#ifdef _DEBUG
	#include <15d/rw/db/db.h>
#else
	#include <12d/rw/db/db.h>
#endif

extern RWDBDatabase aDB;

/////////////////////////////////////////////////////////////////////////////
// CFamilyMaint

IMPLEMENT_DYNCREATE(CFamilyMaint, CFrameWnd)

CFamilyMaint::CFamilyMaint()
{
}

CFamilyMaint::~CFamilyMaint()
{
}


BEGIN_MESSAGE_MAP(CFamilyMaint, CFrameWnd)
	ON_WM_CREATE()
//	ON_COMMAND_EX(CG_ID_VIEW_FAMILYMAINTBAR, OnBarCheck)
//	ON_UPDATE_COMMAND_UI(CG_ID_VIEW_FAMILYMAINTBAR, OnUpdateControlBarMenu)
	//{{AFX_MSG_MAP(CFamilyMaint)
	ON_COMMAND(IDM_MAINTSEARCH, OnMaintsearch)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFamilyMaint message handlers

BOOL CFamilyMaint::OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext)
{
	// CG: The following block was added by the Split Bars component.

	CCreateContext context;
	context.m_pNewViewClass = RUNTIME_CLASS(CFamilyTree);
	context.m_pCurrentDoc = NULL;
	//CFamilyTree* pNewView = STATIC_DOWNCAST(CFamilyTree, CreateView(&context));



	{
/*
		if (!m_wndSplitter.Create(this,
		                          1, 2,          // TODO: adjust the number of rows, columns
		                          CSize(10, 10), // TODO: adjust the minimum pane size
		                          &context))
		{
			TRACE0("Failed to create split bar ");
			return FALSE;    // failed to create
		}
*/

	if (!m_wndSplitter.CreateStatic(this, 1, 2))
	{
		TRACE0("Failed to CreateStaticSplitter\n");
		return FALSE;
	}
		
	if (!m_wndSplitter.CreateView(0, 0,
		RUNTIME_CLASS(CFamilyTree), CSize(230, 50), &context))
	{
		TRACE0("Failed to create second pane\n");
		return FALSE;
	}
	
	if (!m_wndSplitter.CreateView(0, 1,
		RUNTIME_CLASS(CFamilyMaintDlg), CSize(230, 200), &context))
	{
		TRACE0("Failed to create second pane\n");
		return FALSE;
	}

	CFamilyMaintDlg* View = (CFamilyMaintDlg*)m_wndSplitter.GetPane(0,1);
	View->OnInitialUpdate();
	SetActiveView(View);
/*
	if (pNewView != NULL)
	{
		pNewView->ShowWindow(SW_SHOW);
		pNewView->OnInitialUpdate();
		SetActiveView(pNewView);
		RecalcLayout();
	}
	*/

		return TRUE;
	}
}

int CFamilyMaint::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	CMenu Menu;
	Menu.LoadMenu( IDR_FAMILYTREE );
	SetMenu( &Menu );
	Menu.Detach();

	// TODO: Add a menu item that will toggle the visibility of the
	// dialog bar named "FamilyMaintBar":
	//   1. In ResourceView, open the menu resource that is used by
	//      the CFamilyMaint class
	//   2. Select the View submenu
	//   3. Double-click on the blank item at the bottom of the submenu
	//   4. Assign the new item an ID: CG_ID_VIEW_FAMILYMAINTBAR
	//   5. Assign the item a Caption: FamilyMaintBar

	// TODO: Change the value of CG_ID_VIEW_FAMILYMAINTBAR to an appropriate value:
	//   1. Open the file resource.h
	// CG: The following block was inserted by the 'Dialog Bar' component
/*
	{
		// Initialize dialog bar m_wndFamilyMaintBar
		if (!m_wndFamilyMaintBar.Create(this, CG_IDD_FAMILYMAINTBAR,
			CBRS_TOP | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_HIDE_INPLACE,
			CG_ID_VIEW_FAMILYMAINTBAR))
		{
			TRACE0("Failed to create dialog bar m_wndFamilyMaintBar\n");
			return -1;		// fail to create
		}

		m_wndFamilyMaintBar.EnableDocking(CBRS_ALIGN_TOP | CBRS_ALIGN_BOTTOM);
		EnableDocking(CBRS_ALIGN_ANY);
		DockControlBar(&m_wndFamilyMaintBar);

	}
*/

	return 0;
}

void CFamilyMaint::OnMaintsearch() 
{
	PersonStruct* PS;
	long OldFamily = -1;
	HTREEITEM LastRoot;
	HTREEITEM CurrentItem;
	CSearchDlg Dlg(this );
	if(IDOK==Dlg.DoModal())
	{
		CTreeView* View = (CTreeView*)m_wndSplitter.GetPane(0,0);
		CTreeCtrl* Tree = &View->GetTreeCtrl();
		RWDBConnection conn2 = aDB.connection();
		RWDBResult results  = conn2.executeSql( Dlg.CurrentSelect.GetBuffer(0) );
		RWDBTable resultTable = results.table();                            //1
		RWDBReader rdr1 = resultTable.reader(); 
		if( !rdr1.isValid() )
		{
			MessageBox( (CString)"Error occured reading database with SQL statement " + Dlg.CurrentSelect + " Error is: " + (const char*)rdr1.status().message(), "Error", MB_OK );
			return;
		}
		ClearTree();
		while(rdr1())
		{
			RWCString Temp;
			PS = new PersonStruct();
			PS->Family = 0;
			rdr1["FamilyID"] >> PS->FamilyID;
			rdr1["ID"] >> PS->PersonID;
			rdr1["FirstName"] >> Temp;
			PS->FirstName = (const char*)Temp;
			rdr1["LastName"] >> Temp;
			PS->LastName = (const char*)Temp;
			if( OldFamily != PS->FamilyID )
			{
				OldFamily = PS->FamilyID;
				LastRoot = Tree->InsertItem( PS->LastName, TVI_ROOT, TVI_LAST );
				Tree->SetItemData( LastRoot, (DWORD)PS );
			}
			CurrentItem = Tree->InsertItem( PS->LastName + ", " + PS->FirstName, LastRoot, TVI_LAST );
			Tree->SetItemData( CurrentItem, (DWORD)PS );
		}
		Tree->SortChildren( NULL );
	}
}


void CFamilyMaint::OnDestroy() 
{
	CFrameWnd::OnDestroy();
	ClearTree();

}

void CFamilyMaint::DeleteChildren(CTreeCtrl * Tree, HTREEITEM item)
{
	HTREEITEM Childitem = Tree->GetChildItem( item );
	if( Childitem == NULL )
		return;
	PersonStruct* PS;
	PS = (PersonStruct*)Tree->GetItemData( Childitem );
	delete PS;
	while( NULL != ( Childitem = Tree->GetNextSiblingItem( Childitem ) ) )
	{
		PS = (PersonStruct*)Tree->GetItemData( Childitem );
		delete PS;
	}
}


void CFamilyMaint::ClearTree()
{
	CTreeView* View = (CTreeView*)m_wndSplitter.GetPane(0,0);
	CTreeCtrl* Tree = &View->GetTreeCtrl();
	HTREEITEM item;
	PersonStruct* PS;
	item = Tree->GetRootItem();
	if ( item == NULL )
		return;
	PS = (PersonStruct*)Tree->GetItemData( item );
	if( PS->Family )
		delete PS->Family;
	DeleteChildren( Tree, item );
	while( NULL != ( item = Tree->GetNextSiblingItem( item ) ) )
	{
		PS = (PersonStruct*)Tree->GetItemData( item );
		if( PS->Family )
			delete PS->Family;
		DeleteChildren( Tree, item );
	}
	Tree->DeleteAllItems();
	CFamilyMaintDlg* View1 = (CFamilyMaintDlg*)m_wndSplitter.GetPane(0,1);
	View1->ClearList();

}

void CFamilyMaint::ShowFamily( CFamilyMaint::PersonStruct* PS)
{
	CFamilyMaintDlg* View = (CFamilyMaintDlg*)m_wndSplitter.GetPane(0,1);
	SetActiveView(View);
	View->ShowFamily( PS );
}


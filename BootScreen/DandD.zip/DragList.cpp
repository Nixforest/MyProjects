// DragList.cpp : implementation file
//

#include "stdafx.h"
#include "DAD.h"
#include "DragList.h"
#include "MyObject1.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDragList

CDragList::CDragList()
{
}

CDragList::~CDragList()
{
}


BEGIN_MESSAGE_MAP(CDragList, CListBox)
	//{{AFX_MSG_MAP(CDragList)
	ON_WM_LBUTTONDOWN()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDragList message handlers

BOOL CDragList::OnDrop(CWnd* pWnd, COleDataObject* pDataObject,DROPEFFECT dropEffect, CPoint point )
{
    HGLOBAL  hGlobal;
    int      Pos;

	//hGlobal=pDataObject->GetGlobalData(CF_TEXT);
	hGlobal=pDataObject->GetGlobalData(CF_OWNERDISPLAY);
	
	LPCSTR pData=(LPCSTR)GlobalLock(hGlobal);    
    ASSERT(pData!=NULL); 

	CMyObject1* MyObj = (CMyObject1*)atol( pData );
    Pos=((CListBox*)pWnd)->AddString(MyObj->Data);
	((CListBox*)pWnd)->SetItemDataPtr(Pos,  MyObj );
    GlobalUnlock(hGlobal);
    if(Pos < 0)
        return FALSE;


    return TRUE;
}

void CDragList::OnLButtonDown(UINT nFlags, CPoint point) 
{
	CListBox::OnLButtonDown(nFlags, point);	
	int Pos = GetCurSel();
	if( LB_ERR == Pos)
		return;

	if( 0 == GetItemDataPtr( Pos ) )
		;
		//Make the object or something
	
	RECT rClient;
    GetClientRect(&rClient);
	
	StartDragging((DWORD)GetItemDataPtr( Pos ), &rClient, &point);
}

void CDragList::CompleteMove()
{
	int nItem = nItem=GetCurSel();
	if(nItem==LB_ERR)
        return;	
	DeleteString(nItem);
	SetCurSel(nItem-1);                                   
}

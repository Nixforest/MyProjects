#if !defined(AFX_FAMILYMAINTDLG_H__2DA1B093_CAB5_11D3_A331_00A024931528__INCLUDED_)
#define AFX_FAMILYMAINTDLG_H__2DA1B093_CAB5_11D3_A331_00A024931528__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// FamilyMaintDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFamilyMaintDlg form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "FamilyMaint.h"
class CDataObject;

class CFamilyMaintDlg : public CFormView
{
protected:
	CFamilyMaintDlg();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CFamilyMaintDlg)

// Form Data
public:
	//{{AFX_DATA(CFamilyMaintDlg)
	enum { IDD = IDD_MAINTFAMILY };
	CComboBox	m_HowHeard;
	CTreeCtrl	m_Tree;
	//}}AFX_DATA

// Attributes
public:

// Operations
public:
	void ClearList();
	void ShowFamily( CFamilyMaint::PersonStruct* PS );
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFamilyMaintDlg)
	public:
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	virtual void OnInitialUpdate();
	virtual BOOL OnDrop(COleDataObject* pDataObject, DROPEFFECT dropEffect, CPoint point);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CFamilyMaintDlg();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CFamilyMaintDlg)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSelchangeNhowheard();
	afx_msg void OnBegindragFamilytree(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	virtual HTREEITEM GetDropTarget(HTREEITEM hItem);
	BOOL IsDropSource( HTREEITEM hItem );
	CFamily* Family;
	void FillCombo();

	CImageList      m_Image;
    BOOL            m_bLDragging;
    HTREEITEM       m_hitemDrag,m_hitemDrop;
    HCURSOR         m_dropCursor,m_noDropCursor;

};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FAMILYMAINTDLG_H__2DA1B093_CAB5_11D3_A331_00A024931528__INCLUDED_)

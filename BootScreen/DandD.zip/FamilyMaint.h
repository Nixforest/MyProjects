#if !defined(AFX_FAMILYMAINT_H__A7B04954_8FE4_11D3_A32A_00A024931528__INCLUDED_)
#define AFX_FAMILYMAINT_H__A7B04954_8FE4_11D3_A32A_00A024931528__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// FamilyMaint.h : header file
//
class CFamily;
/////////////////////////////////////////////////////////////////////////////
// CFamilyMaint frame

class CFamilyMaint : public CFrameWnd
{
	DECLARE_DYNCREATE(CFamilyMaint)

	CFamilyMaint();           // protected constructor used by dynamic creation

// Attributes
public:

// Operations
public:
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFamilyMaint)
	//}}AFX_VIRTUAL
	struct PersonStruct
	{
		long FamilyID;
		long PersonID;
		CString FirstName;
		CString LastName;
		CFamily* Family;
	};
	void ShowFamily( CFamilyMaint::PersonStruct* PS);
protected:
	CDialogBar m_wndFamilyMaintBar;
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	CSplitterWnd m_wndSplitter;
	virtual BOOL OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext);
	virtual ~CFamilyMaint();


	// Generated message map functions
	//{{AFX_MSG(CFamilyMaint)
	afx_msg void OnMaintsearch();
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:

	void ClearTree();
	void DeleteChildren(CTreeCtrl* Tree, HTREEITEM item);


};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FAMILYMAINT_H__A7B04954_8FE4_11D3_A32A_00A024931528__INCLUDED_)

// MyObject1.cpp: implementation of the CMyObject1 class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "DAD.h"
#include "MyObject1.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMyObject1::CMyObject1()
{
	Data = "This is My object 1";
}

CMyObject1::~CMyObject1()
{

}

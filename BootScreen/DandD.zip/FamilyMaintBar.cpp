// FamilyMaintBar.cpp : implementation file
//

#include "stdafx.h"
#include "parsival.h"
#include "FamilyMaintBar.h"

#ifdef _DEBUG
//#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFamilyMaintBar dialog


CFamilyMaintBar::CFamilyMaintBar(CWnd* pParent /*=NULL*/)
	: CDialog(CFamilyMaintBar::IDD, pParent)
{
	//{{AFX_DATA_INIT(CFamilyMaintBar)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CFamilyMaintBar::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFamilyMaintBar)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CFamilyMaintBar, CDialog)
	//{{AFX_MSG_MAP(CFamilyMaintBar)
	ON_BN_CLICKED(IDC_SEARCHFAMILY, OnSearchfamily)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFamilyMaintBar message handlers

void CFamilyMaintBar::OnSearchfamily() 
{
	MessageBox( "Hello" );	
}

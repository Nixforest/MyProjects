// DADView.cpp : implementation of the CDADView class
//

#include "stdafx.h"
#include "DAD.h"

#include "DADDoc.h"
#include "DADView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDADView

IMPLEMENT_DYNCREATE(CDADView, CView)

BEGIN_MESSAGE_MAP(CDADView, CView)
	//{{AFX_MSG_MAP(CDADView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDADView construction/destruction

CDADView::CDADView()
{
	// TODO: add construction code here

}

CDADView::~CDADView()
{
}

BOOL CDADView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CDADView drawing

void CDADView::OnDraw(CDC* pDC)
{
	CDADDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CDADView diagnostics

#ifdef _DEBUG
void CDADView::AssertValid() const
{
	CView::AssertValid();
}

void CDADView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CDADDoc* CDADView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CDADDoc)));
	return (CDADDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CDADView message handlers

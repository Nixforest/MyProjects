// FamilyMaintDlg.cpp : implementation file
//

#include "stdafx.h"
#include "parsival.h"
#include "FamilyMaintDlg.h"
//#include "FamilyMaint.h"
#include "HHLookupNotifier.h"

#include "Family.h"
#include "Person.h"
#include "Address.h"
#include "Phone.h"
#include "Action.h"
#include "DataObject.h"

#ifdef _DEBUG
	#include <15d/rw/db/db.h>
#else
	#include <12d/rw/db/db.h>
#endif
extern RWDBDatabase aDB;

#include "Resource.h"

#ifdef _DEBUG
//#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CLookupRepository* Lookups;
/////////////////////////////////////////////////////////////////////////////
// CFamilyMaintDlg

IMPLEMENT_DYNCREATE(CFamilyMaintDlg, CFormView)

CFamilyMaintDlg::CFamilyMaintDlg()
	: CFormView(CFamilyMaintDlg::IDD)
{
	//{{AFX_DATA_INIT(CFamilyMaintDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_hitemDrag = NULL;
	m_bLDragging = FALSE;
}

CFamilyMaintDlg::~CFamilyMaintDlg()
{
}

void CFamilyMaintDlg::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFamilyMaintDlg)
	DDX_Control(pDX, IDC_NHOWHEARD, m_HowHeard);
	DDX_Control(pDX, IDC_FAMILYTREE, m_Tree);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CFamilyMaintDlg, CFormView)
	//{{AFX_MSG_MAP(CFamilyMaintDlg)
	ON_WM_CREATE()
	ON_CBN_SELCHANGE(IDC_NHOWHEARD, OnSelchangeNhowheard)
	ON_NOTIFY(TVN_BEGINDRAG, IDC_FAMILYTREE, OnBegindragFamilytree)
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFamilyMaintDlg diagnostics

#ifdef _DEBUG
void CFamilyMaintDlg::AssertValid() const
{
	CFormView::AssertValid();
}

void CFamilyMaintDlg::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

void CFamilyMaintDlg::ShowFamily( CFamilyMaint::PersonStruct* PS )
{
	HTREEITEM PersonItem;
	HTREEITEM AddressItem;
	HTREEITEM PhoneItem;
	HTREEITEM ActionItem;
	HTREEITEM PersonTitle;
	HTREEITEM AddressTitle;
	HTREEITEM PhoneTitle;
	HTREEITEM ActionTitle;
	CPerson* Person;
	CAction* Action;
	CPhone* Phone;
	CPerson::Place* Place;
	CAddress* Address;
	CResource* Resource;
	BOOL iPersonNumbers=TRUE, iAddresses=TRUE, iActions = TRUE, iResources=TRUE;

	if( !PS->Family )
		return;
	Family = PS->Family;
	m_Tree.DeleteAllItems();
	FillCombo();

	for( CFamily::LI fi = PS->Family->FamilyMembers.begin(); fi != PS->Family->FamilyMembers.end(); ++fi )
	{
		Person = *fi;
		PersonItem = m_Tree.InsertItem( Person->Name(), TVI_ROOT, TVI_LAST );
		m_Tree.SetItemData( PersonItem, (DWORD)Person );
		for( CPerson::PhoneIterator pi = Person->PhoneNumbers.begin(); pi != Person->PhoneNumbers.end(); ++pi )
		{
			if( iPersonNumbers )
			{
				iPersonNumbers = FALSE;
				PhoneTitle = m_Tree.InsertItem( "Personal Numbers", PersonItem, TVI_LAST );
			}
			Phone = *pi;
			PhoneItem = m_Tree.InsertItem( Phone->GetListLabel(), PhoneTitle, TVI_LAST );
			m_Tree.SetItemData( PhoneItem, (DWORD)Phone );
		}
		

		for( CPerson::PlaceIterator ai = Person->Places.begin(); ai != Person->Places.end(); ++ai )
		{
			if( iAddresses )
			{
				iAddresses = FALSE;
				AddressTitle = m_Tree.InsertItem( "Resides at addresses", PersonItem, TVI_LAST );
			}
			Place = *ai;
			AddressItem = m_Tree.InsertItem( Place->Address->GetListLabel(), AddressTitle, TVI_LAST );
			m_Tree.SetItemData( AddressItem, (DWORD)Place->Address );
			
			for( CAddress::PhoneIterator pia = Place->Address->PhoneNumbers.begin(); pia != Place->Address->PhoneNumbers.end(); ++pia )
			{
				Phone = *pia;
				PhoneItem = m_Tree.InsertItem( Phone->GetListLabel(), AddressItem, TVI_LAST );
				m_Tree.SetItemData( PhoneItem, (DWORD)Phone );
			}
		}
		
		for( CPerson::ActionIterator aci = Person->Actions.begin(); aci != Person->Actions.end(); ++aci )
		{
			if( iActions )
			{
				iActions = FALSE;
				ActionTitle = m_Tree.InsertItem( "Completed actions", PersonItem, TVI_LAST );
			}
			Action = *aci;
			ActionItem = m_Tree.InsertItem( Action->DateAsString() + " - " + (CString)Action->Type() + " - " + Action->Note(), ActionTitle, TVI_LAST );
			m_Tree.SetItemData( ActionItem, (DWORD)Action );
		}

		
		for( CPerson::ResourceIterator ri = Person->Resources.begin(); ri != Person->Resources.end(); ++ri )
		{
			if( iResources )
			{
				iResources = FALSE;
				ActionTitle = m_Tree.InsertItem( "To do items", PersonItem, TVI_LAST );
			}
			Resource = *ri;
			ActionItem = m_Tree.InsertItem( Resource->StartDateAsString() + " - " + (CString)Resource->Type() + " - " + Resource->Note(), ActionTitle, TVI_LAST );
			m_Tree.SetItemData( ActionItem, (DWORD)Resource );
		}
	}

	m_Tree.SortChildren( NULL );
	m_HowHeard.SelectString(-1,PS->Family->ReferredBy());
}

void CFamilyMaintDlg::FillCombo()
{
	if( 0 == m_HowHeard.GetCount() )
	{
		CLookupNotifier N;
		N.ControlTypeNeedingRefresh = CLookupNotifier::HOWHEARDCOMBO;
		N.ComboBox = &m_HowHeard;
		//N.SendNow(TRUE);
		Lookups->OnLookupNotifier( &N );
	}

}

BOOL CFamilyMaintDlg::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext) 
{
	// TODO: Add your specialized code here and/or call the base class

	return CFormView::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);
}

int CFamilyMaintDlg::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CFormView::OnCreate(lpCreateStruct) == -1)
		return -1;

	return 0;
}

void CFamilyMaintDlg::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	VERIFY (m_Image.Create (15, 16, TRUE, 0, 1));
	CBitmap bm;
	VERIFY (bm.LoadBitmap (IDB_DRAG));
	VERIFY (-1 != m_Image.Add (&bm, RGB (192, 192, 192)));
	m_dropCursor = LoadCursor( NULL, IDC_ARROW );
	m_noDropCursor = LoadCursor( NULL, IDC_NO );
	//m_Tree.SetImageList (&m_Image, TVSIL_NORMAL);
	
}

void CFamilyMaintDlg::OnSelchangeNhowheard() 
{
	int Pos = -1;
	if( CB_ERR == (Pos = m_HowHeard.GetCurSel() ) )
		return;

	CLookupRepository::Entry* HH = (CLookupRepository::Entry*)m_HowHeard.GetItemDataPtr( Pos );
	if( HH )
	{
		char SQL[100]="";
		sprintf( SQL, "update Family set HowHeardCode ='%s' where FamilyID = %d", HH->Code, Family->ID() );
		RWDBConnection conn2 = aDB.connection();
		RWDBResult  result2 = conn2.executeSql(SQL);
		RWDBStatus Status = result2.status();
		if( RWDBStatus::ok == Status.isValid() )
		{
			MessageBox( (CString)"Error occured writing to database. Error is: " + (CString)(const char*)Status.message() +"\nWith SQL statement: " + SQL , "Error", MB_OK );
			return;
		}
	}
}

void CFamilyMaintDlg::ClearList()
{
	m_Tree.DeleteAllItems();
}

void CFamilyMaintDlg::OnBegindragFamilytree(NMHDR* pNMHDR, LRESULT* pResult) 
{
	
	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;
	m_hitemDrag = pNMTreeView->itemNew.hItem;
    m_hitemDrop = NULL;
    m_Tree.SelectItem( m_hitemDrag );
    if (!IsDropSource(m_hitemDrag))
		return;

	VERIFY (m_Image.BeginDrag (0, CPoint (15, 15)));
	VERIFY (m_Image.DragEnter (GetDesktopWindow (), ((NM_TREEVIEW *)pNMHDR)->ptDrag));
	
	m_bLDragging = TRUE;
	/*
    POINT pt = pNMTreeView->ptDrag;
    ClientToScreen( &pt );
    m_pDragImage->DragEnter(NULL, pt);
	*/
    SetCapture();
}

void CFamilyMaintDlg::OnLButtonUp(UINT nFlags, CPoint point) 
{
	if (m_bLDragging)
	{
		m_bLDragging = FALSE;
        CImageList::DragLeave(this);
        CImageList::EndDrag();
        ReleaseCapture();

		m_Tree.SelectDropTarget(NULL);

        if( m_hitemDrag == m_hitemDrop || m_hitemDrop == NULL)
			return;

		TV_ITEM item;
		memset( &item, 0, sizeof( item ) );
		item.hItem = m_hitemDrag;
		item.mask = TVIF_PARAM  | TVIF_TEXT;
		m_Tree.GetItem( &item );

		MessageBox("Dropped " + ((CDataObject*)item.lParam)->ObjectType);

		/*
		// If Drag item is an ancestor of Drop item then return
        HTREEITEM htiParent = m_hitemDrop;
        while( (htiParent = GetParentItem( htiParent )) != NULL ) 
		{
				if( htiParent == m_hitemDrag ) return;
		}

		Expand( m_hitemDrop, TVE_EXPAND ) ;

        HTREEITEM htiNew = CopyBranch(m_hitemDrag, m_hitemDrop, TVI_LAST ); 
        DeleteItem(m_hitemDrag);
        SelectItem( htiNew );
		*/
     }

	CFormView::OnLButtonUp(nFlags, point);
}

BOOL CFamilyMaintDlg::OnDrop(COleDataObject* pDataObject, DROPEFFECT dropEffect, CPoint point) 
{
	
	AfxMessageBox("Dropped");	
	return CFormView::OnDrop(pDataObject, dropEffect, point);
}

void CFamilyMaintDlg::OnMouseMove(UINT nFlags, CPoint point) 
{
	HTREEITEM hitem;
    UINT flags;

    if (m_bLDragging)
    {
		POINT pt = point;
        ClientToScreen( &pt );
        CImageList::DragMove(pt);
        if ((hitem = m_Tree.HitTest(point, &flags)) != NULL) //was point
        {
			CImageList::DragShowNolock(FALSE);
            m_hitemDrop = GetDropTarget(hitem);
            m_Tree.SelectDropTarget(m_hitemDrop);
            CImageList::DragShowNolock(TRUE);
		}
        else
			m_hitemDrop = NULL;

        if (m_hitemDrop)
			SetCursor(m_dropCursor);
        else
			SetCursor(m_noDropCursor);
                             }
	CFormView::OnMouseMove(nFlags, point);
}

BOOL CFamilyMaintDlg::IsDropSource(HTREEITEM hItem)
{
	TV_ITEM item;
	memset( &item, 0, sizeof( item ) );
	item.hItem = hItem;
	item.mask = TVIF_PARAM;
	m_Tree.GetItem( &item );	
	return item.lParam;
}

HTREEITEM CFamilyMaintDlg::GetDropTarget(HTREEITEM hItem)
{
	CPhone* Phone;
	
	if (hItem == m_hitemDrag || hItem == m_Tree.GetParentItem(m_hitemDrag))
		return NULL;

	TV_ITEM sitem;
	memset( &sitem, 0, sizeof( sitem ) );
	sitem.hItem = m_hitemDrag;
	sitem.mask = TVIF_PARAM;
	m_Tree.GetItem( &sitem );
	CDataObject* Source = (CDataObject*)sitem.lParam;

	TV_ITEM ditem;
	memset( &ditem, 0, sizeof( ditem ) );
	ditem.hItem = hItem;
	ditem.mask = TVIF_PARAM | TVIF_TEXT;
	m_Tree.GetItem( &ditem );

	if( ditem.lParam == NULL ) //List label (no data)
		return NULL;
	CDataObject* Target = (CDataObject*)ditem.lParam;

	if( Target->ObjectType == "Address" )
	{
		if( Source->ObjectType == "Phone" )
		{
			Phone = (CPhone*)Source;
			if( Phone->IsStationary() )
				return hItem;
		}
	}

	if( Target->ObjectType == "Person" )
	{
		if( Source->ObjectType == "Phone" )
		{
			Phone = (CPhone*)Source;
			if( !Phone->IsStationary() )
				if( Target != Phone->AssignedTo() ) //Make sure that target person is not same as source person
					return hItem;
		}
		else if( Source->ObjectType == "Address" )
				return hItem;
		else if( Source->ObjectType == "Action" )
				return hItem;
		else if( Source->ObjectType == "Resource" )
				return hItem;
	}
	return NULL;
}

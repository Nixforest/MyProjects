﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JTest
{
    public class Constant
    {
        public static string DBPassWord = "jcd_n4";
        public static string strVocabulary="Từ vựng";
        public static string strGrammer = "Ngữ pháp";
        public static string strN1 = "N1";
        public static string strN2_N3 = "N2/N3";
        public static string strN4 = "N4"; 
        public static string strN5 = "N5";
        public static string strDefaultLang = "Vietnamese";
        public static string strEnglish = "English";
        public static string strJapanese = "Japanese";
        public static string strVietnamese = "Vietnamese";
        public static string Sentence = "Câu";
        public static int intWaitForAns = 10;

        // for ListenPractice
        public static string listenSentence = "Câu";
        public static string MediaPath = AppDomain.CurrentDomain.BaseDirectory + "Media\\";
        public static string WithImage = "With_Image";
        public static string WithoutImage = "Without_Image";
    }
}

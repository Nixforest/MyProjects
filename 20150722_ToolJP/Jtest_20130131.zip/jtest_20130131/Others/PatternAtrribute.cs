﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JTest.Others
{
    class PatternAtrribute : Attribute
    {
        string _pattern;

        public PatternAtrribute(string p)
        {
            _pattern = p;
        }

        public string Pattern
        {
            get
            {
                return _pattern;
            }
            set
            {
                _pattern = value;
            }
        }
    }
}

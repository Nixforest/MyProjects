﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;

namespace JTest
{
    public class MultiLang
    {
        public string loadLangSetting()
        {
            string path = AppDomain.CurrentDomain.BaseDirectory;
            //path = path.Substring(0, path.Length - 10);
            path += "Lang/setting.xml";
            //label1.Text = path;
            string lang = string.Empty;
            try
            {
                XmlTextReader reader = new XmlTextReader(path);
                while (reader.Read())
                {
                    switch (reader.NodeType)
                    {
                        case XmlNodeType.Text:
                            lang = reader.Value;
                            break;
                    }
                }
                reader.Close();
                return lang;
            }
            catch (Exception ex)
            { return "error"; }
        }

        public XmlDocument loadLangData(string src)
        {
            string path = AppDomain.CurrentDomain.BaseDirectory;
            path = path + "Lang/" + src + ".xml";
            
            XmlDocument xml = new XmlDocument();
            xml.Load(path);
            return xml;
        }
        //public static 
    }

    public class ComboBoxItem
    {
        private string display;
        private string value;

        public ComboBoxItem(string display, string value)
        {
            this.display = display;
            this.value = value;
        }

        public string Display
        {
            set { display = value; }
            get { return display; }
        }

        public string Value
        {
            set { this.value = value; }
            get { return value; }
        }
    }
}

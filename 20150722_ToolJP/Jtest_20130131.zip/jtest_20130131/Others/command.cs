﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Data;
using System.Text.RegularExpressions;
using System.IO;
using System.Reflection;
using JTest.DTO;

namespace JTest
{
    public class command
    {
        /// Created by ToanNN
        /// <summary>
        /// Lấy danh sách các cấp độ có trong database hiện tại
        /// </summary>
        /// <returns>Danh sách các lavel có trong database hiện tại</returns>
        public static List<string> getLevelList()

        {
            try
            {
                OleDbConnection cn = DataProvider.ConnectionData();
                DataTable schemaTable = cn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });
//              cn.Close();     //DEL, 14/01/2012, KYNX
                List<string> items = new List<string>();
////{{DEL_HEAD, 14/01/2012, KYNX
                ////List the table name from each row in the schema table.
                //for (int i = 0; i < schemaTable.Rows.Count; i++)
                //{
                //    string strtemp = schemaTable.Rows[i].ItemArray[2].ToString();
                //    // lisTablesName.Add(strtemp);
                //    string pattern = @"[1-9]";
                //    Regex myRegex = new Regex(pattern);
                //    Match m = myRegex.Match(strtemp);
                //    if (m.ToString() == "1")
                //    {
                //        strtemp = Constant.strN1;
                //    }
                //    else if (m.ToString() == "2")
                //    {
                //        strtemp = Constant.strN2_N3;
                //    }
                //    else if (m.ToString() == "3")
                //    {
                //        strtemp = Constant.strN4;
                //    }
                //    else
                //    {
                //        strtemp = Constant.strN5;
                //    }
                //    if (!items.Contains(strtemp))
                //    {
                //        items.Add(strtemp);
                //    }
                //}
////}}DEL_TAIL, 14/01/2012, KYNX

////{{ADD_HEAD, 14/01/2012, KYNX
                List<string> lsTbl = new List<string> { };
                for (int i = 0; i < schemaTable.Rows.Count; i++)
                {
                    lsTbl.Add(schemaTable.Rows[i].ItemArray[2].ToString());
                }

                for (int i = 0; i < lsTbl.Count; i++)
                {
                    string query = "Select count(*) from " + lsTbl[i];
                    OleDbCommand cmd = new OleDbCommand(query, cn);
                    int nRows = (int)cmd.ExecuteScalar();
                    OleDbDataReader dr = cmd.ExecuteReader();
                    if (nRows > 0)
                    {
                        string pattern = @"[1-9]";
                        string strtemp = lsTbl[i];
                        Regex myRegex = new Regex(pattern);
                        Match m = myRegex.Match(strtemp);
                        if (m.ToString() == "1")
                        {
                            strtemp = Constant.strN1;
                            if (!items.Contains(strtemp))
                            {
                                items.Add(strtemp);
                            }
                        }
                        else if (m.ToString() == "2")
                        {
                            strtemp = Constant.strN2_N3;
                            if (!items.Contains(strtemp))
                            {
                                items.Add(strtemp);
                            }
                        }
                        else if (m.ToString() == "3")
                        {
                            strtemp = Constant.strN4;
                            if (!items.Contains(strtemp))
                            {
                                items.Add(strtemp);
                            }
                        }
                        else if (m.ToString() == "4")
                        {
                            strtemp = Constant.strN5;
                            if (!items.Contains(strtemp))
                            {
                                items.Add(strtemp);
                            }
                        }
                    }
                }
                cn.Close();
////}}ADD_TAIL, 14/01/2012, KYNX

                return items;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
    }
        /// Created by ToanNN
        /// <summary>
        /// lấy danh sách kiểu trong database hiện tại
        /// </summary>
        /// <param name="strSelectedLevel">Cấp độ được chọn</param>
        /// <returns>Danh sách các kiểu có trong database hiện tại</returns>
        public static List<string> getTypeList(string strSelectedLevel)
        {
            try
            {
                if (strSelectedLevel == Constant.strN1)
                {
                    strSelectedLevel = "1";
                }
                else if (strSelectedLevel == Constant.strN2_N3)
                {
                    strSelectedLevel = "2";
                }
                else if (strSelectedLevel == Constant.strN4)
                {
                    strSelectedLevel = "3";
                }
                else
                {
                    strSelectedLevel = "4";
                }

                OleDbConnection cn = DataProvider.ConnectionData();
                DataTable schemaTable = cn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });
                cn.Close();
                List<string> items = new List<string>();

                //List the table name from each row in the schema table.
                for (int i = 0; i < schemaTable.Rows.Count; i++)
                {
                    string strtemp = schemaTable.Rows[i].ItemArray[2].ToString();
                    if (strtemp.Contains(strSelectedLevel))
                    {
                        if (strtemp.Contains("grammar"))
                        {
                            string strtype = Constant.strGrammer;
                            if (!items.Contains(strtype))
                            {
                                items.Add(strtype);
                            }
                        }
                        else if (strtemp.Contains("vocabulary"))
                        {
                            string strtype = Constant.strVocabulary;
                            if (!items.Contains(strtype))
                            {
                                items.Add(strtype);
                            }
                        }
                    }
                }
                return items;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        /// /// Created by ToanNN
        /// <summary>
        /// tạo một thư mục tạm để chứa file data
        /// </summary>
        /// <returns>trả về đường dẫn đầy đủ của thư mục vừa tạo</returns>
        public static string GetTempDirectory()
        {

            string DirName = Path.GetRandomFileName();

            Directory.CreateDirectory(Path.Combine(Path.GetTempPath(), DirName));
            string fullpath = Path.GetTempPath() + DirName;

            return fullpath;

        }
        /// /// Created by ToanNN
        /// <summary>
        /// Extract database từ resource
        /// </summary>
        /// <param name="path">Đường dẫn để tạo file extract</param>
        public static void extractDB(string path)
        {

            Assembly assembly = Assembly.GetExecutingAssembly();
            string[] arrResources = assembly.GetManifestResourceNames();
            Stream file = assembly.GetManifestResourceStream("JTest.Resources.Default.mdb"); // my resource 
            BinaryReader bReader = new BinaryReader(file);
            FileStream fStream = new FileStream(path + "\\data.dat", FileMode.Create);  // where i want to copy the resource 
            using (BinaryWriter bWriter = new BinaryWriter(fStream))
            {

                bWriter.Write(bReader.ReadBytes((
                int)file.Length));
                bReader.Close();
                bWriter.Close();
            }

            file.Close();
        }
        /// Created by ToanNN
        /// <summary>
        /// Creates the ramdom list.
        /// </summary>
        /// <param name="maxValue">The max value.</param>
        /// <param name="listCount">The list count.</param>
        /// <param name="excludedList">The excluded list.</param>
        /// <returns>RandomList or null if can't create List</returns>
        public static List<int> createRamdomList(int maxValue, int listCount, List<int> excludedList)
        {
            try
            {
                if (excludedList != null)
                    if ((excludedList.Count + listCount) > maxValue)
                        return null; // trong list ko còn đủ giá trị.
                List<int> List = new List<int>();
                List<int> TempList = new List<int>();
                int intCount = 0;
                int intTemp;
                for (int i =0; i < maxValue; i++)
                {
                    if (excludedList != null)
                        if (!excludedList.Contains(i))
                            TempList.Add(i);
                    TempList.Add(i);
                }

                while (intCount < listCount)
                {
                    Random Rd = new Random();
                    intTemp = Rd.Next(TempList.Count - 1);
                    List.Add(TempList[intTemp]);
                    TempList.RemoveAt(intTemp);
                    intCount++;
                }
                return List;
            }
            catch
            {
                return null;
            }
        }
        /// Created by ToanNN
        /// <summary>
        /// Gets the list files in dir.
        /// </summary>
        /// <param name="dirPath">The dir path.</param>
        /// <param name="pattern">The pattern.</param>
        /// <param name="option">The option.</param>
        /// <returns>List of files in dir or null if can't get list of file.</returns>
        public static List<string> getListFilesInDir(string dirPath, string pattern, SearchOption option)
        {
            try
            {
                List<string> List = new List<string>();
                DirectoryInfo dirInfo = new DirectoryInfo(dirPath);
                FileInfo[] files = dirInfo.GetFiles(pattern, option);
                foreach (FileInfo file in files)
                {
                    List.Add(file.FullName);
                }
                if (List.Count > 0)
                    return List;
                else
                    return null;
            }
            catch
            {
                return null; // không lấy được danh sách file
            }
        }

        /// <summary>
        /// Converts the level.
        /// </summary>
        /// <param name="level">The level.</param>
        /// <returns></returns>
        public static int convertLevel(string level)
        {
            switch (level)
            {
                case "N1": return 1;
                case "N2/N3": return 2;
                case "N4": return 3;
                case "N5": return 4;
                default:   return 0;
            }
            
        }
        /// <summary>
        /// Converts the type.
        /// </summary>
        /// <param name="type">The type.</param>
        /// <returns></returns>
        public static string convertType(string type)
        {
            switch (type)
            {
                case "Vocabulary": return "vocabulary";
                case "Từ vựng": return "vocabulary";
                case "語彙": return "vocabulary";

                case "Grammar": return "grammar";
                case "Ngữ pháp": return "grammar";
                case "文法": return "grammar";
                default: return "";
            }

        }

        /// <summary>
        /// Swaps 2 strings.
        /// </summary>
        /// <param name="S1">The s1.</param>
        /// <param name="S2">The s2.</param>
        /// <returns></returns>
        public static bool SwapString(ref string S1, ref string S2)
        {
            try
            {
                string S = S1;
                S1 = S2;
                S2 = S;
                return true;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// Unscramblers the specified q.
        /// </summary>
        /// <param name="q">The q.</param>
        /// <returns></returns>
        public static QuestionDTO unscrambler(QuestionDTO qold)
    {
        QuestionDTO q=new QuestionDTO();
        q=qold;
        int intRightAns;
        Random random=new Random();
        int intRandom;
        if (q.Answer == 'A')
        {
            intRightAns = 1;
        }
        else if (q.Answer == 'B')
        {
            intRightAns = 2;
        }
        else if (q.Answer == 'C')
        {
            intRightAns = 3;
        }
        else
        {
            intRightAns = 4;
        }
        intRandom = random.Next(5);
        string a = q.AnswerA;
        string b = q.AnswerB;
        string c = q.AnswerC;
        string d = q.AnswerD;

        if (q.Answer == 'A')
        {
            if (intRandom == 2)
            {
                command.SwapString(ref a, ref b);
                q.Answer = 'B';
            }
            else if (intRandom == 3)
            {
                command.SwapString(ref a, ref c);
                q.Answer = 'C';
            }
            else if (intRandom == 4)
            {
                command.SwapString(ref a, ref d);
                q.Answer = 'D';
            }
        }
        else if (q.Answer == 'B')
        {
            if (intRandom == 1)
            {
                command.SwapString(ref a, ref b);
                q.Answer = 'A';
            }
            else if (intRandom == 3)
            {
                command.SwapString(ref b, ref c);
                q.Answer = 'C';
            }
            else if (intRandom == 4)
            {
                command.SwapString(ref b, ref d);
                q.Answer = 'D';
            }
        }
        else if (q.Answer == 'C')
        {
            if (intRandom == 1)
            {
                command.SwapString(ref a, ref c);
                q.Answer = 'A';
            }
            else if (intRandom == 2)
            {
                command.SwapString(ref b, ref c);
                q.Answer = 'B';
            }
            else if (intRandom == 4)
            {
                command.SwapString(ref c, ref d);
                q.Answer = 'D';
            }
        }
        else if (q.Answer == 'D')
        {
            if (intRandom == 2)
            {
                command.SwapString(ref d, ref b);
                q.Answer = 'B';
            }
            else if (intRandom == 3)
            {
                command.SwapString(ref d, ref c);
                q.Answer = 'C';
            }
            else if (intRandom == 1)
            {
                command.SwapString(ref a, ref d);
                q.Answer = 'A';
            }
        }

        q.AnswerA = a;
        q.AnswerB = b;
        q.AnswerC = c;
        q.AnswerD = d;
        return q;
    }
    }
}

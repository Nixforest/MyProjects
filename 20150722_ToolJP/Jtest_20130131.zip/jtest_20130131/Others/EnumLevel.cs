using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;

namespace JTest.Others
{
    public enum EnumLevel
    {
        [DescriptionAttribute("N1")]
        N1 = 1,
        [DescriptionAttribute("N2/N3")]
        N2_N3 ,
        [DescriptionAttribute("N4")]
        N4,
        [DescriptionAttribute("N5")]
        N5
    }
}

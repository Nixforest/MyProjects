using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using System.ComponentModel;
using System.Collections;

namespace JTest.Others
{
    public class EnumHelper
    {
        public static string getDescription(Enum value)
        {
            if (value == null)
            {
                throw new ArgumentException("value");
            }

            string description = value.ToString();
            FieldInfo fieldInfo = value.GetType().GetField(description);
            DescriptionAttribute[] attrs = (DescriptionAttribute[])fieldInfo.GetCustomAttributes(typeof(DescriptionAttribute), false);

            if (attrs != null && attrs.Length > 0)
            {
                description = attrs[0].Description;
            }

            return description;
        }

        public static string getPattern(Enum value)
        {
            if (value == null)
            {
                throw new ArgumentException("value");
            }

            string pattern = value.ToString();
            FieldInfo fieldInfo = value.GetType().GetField(pattern);
            PatternAtrribute[] attrs = (PatternAtrribute[])fieldInfo.GetCustomAttributes(typeof(PatternAtrribute), false);

            if (attrs != null && attrs.Length > 0)
            {
                pattern = attrs[0].Pattern;
            }

            return pattern;
        }

        public static IList ToList(Type type)
        {
            if (type == null)
            {
                throw new ArgumentException("type");
            }

            ArrayList list = new ArrayList();
            Array enumValues = Enum.GetValues(type);

            foreach (Enum value in enumValues)
            {
                list.Add(new KeyValuePair<string, string>(getDescription(value), value.ToString()));
            }

            return list;
        }

    }
}

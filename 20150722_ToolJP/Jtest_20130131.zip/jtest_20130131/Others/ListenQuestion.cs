﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JTest.Others
{
    class ListenQuestion
    {
          public string strfileName;
        public string strKey;
        public string strAnswer;

        /// <summary>
        /// Initializes a new instance of the <see cref="Listen"/> class.
        /// </summary>
        public ListenQuestion()
        {
            strfileName = String.Empty;
            strKey = String.Empty;
            strAnswer = String.Empty;
        }

        /// <summary>
        /// Created by ToanNN
        /// Determines whether this instance is true.
        /// </summary>
        /// <returns>0:donot answer yet; 1:true; -1:false</returns>
        public int isTrue()
        {
            if (String.Compare(strAnswer,String.Empty)==0) // donot answer yet
                return 0;
            if (String.Compare(strKey,strAnswer)==0) // answer is true
                return 1;
            return -1; // answer is false
        }

        /// <summary>
        /// Created by ToanNN
        /// Gets the key from file name
        /// </summary>
        public bool getKey()
        {
            try
            {
                int index = strfileName.LastIndexOf("_");
                if (index != -1)
                {
                    strKey = strfileName.Substring(index + 1, 1);
                }
                return true;
            }
            catch (Exception ex) 
            {
                //throw new Exception(ex.Message); // Todo: need to update when use multiLang
                return false;
            }
        }

      
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Xml;
using System.IO;

namespace JTest.GUI
{
    public partial class frmListenSetting : Form
    {
        public int QuestionCount = 0;
        public int PrQuestionCount = 0;
        public int NumOfTest = 0;
        public int NumOfWithimangeTest = 0;
        public int NumOfWithoutimangeTest = 0;
        public int AllSelectedQue = 0;
        public int WithImageQue = 0;
        public int WithoutImageQue = 0;

        List<string> WithImageList = new List<string>();
        List<string> WithoutImageList = new List<string>();

        private string hienco = "";
        private string ari = "";
        public frmListenSetting()
        {
            try
            {
                InitializeComponent();
                controlLang();
                List<string> LevelList = JTest.BUS.ListenBUS.GetSubDirList(Constant.MediaPath);
                List<string> numOfTestList = new List<string>();
                cmbLevel.DataSource = LevelList;
                cmbPraLevel.DataSource = LevelList;
            }
            catch { }
        }

        /// <summary>
        /// @nhannc
        /// </summary>
        private void controlLang()
        {
            try
            {
                XmlNodeList xnList = frmMain.xml.SelectNodes("lang/listenSetting");
                foreach (XmlNode xn in xnList)
                {
                    this.Text = xn["title"].InnerText;
                    tabTest.Text = xn["tabthi"].InnerText;                    
                    labLevel.Text = xn["capdo"].InnerText;
                    labelTopic.Text = xn["chonchude"].InnerText;
                    dataGridViewX1.Columns[1].HeaderText = xn["chude"].InnerText;
                    dataGridViewX1.Columns[2].HeaderText = xn["socau"].InnerText;
                    labNumOfQue.Text = xn["tongsocau"].InnerText;
                    labelWithImage.Text = xn["cotranh"].InnerText;
                    labelWithoutImage.Text = xn["khongtranh"].InnerText;
                    butStart.Text = xn["batdau"].InnerText;

                    tabPractice.Text = xn["tabluyentap"].InnerText;
                    labPraLevel.Text = xn["capdo"].InnerText;
                    labPraTopic.Text = xn["DB"].InnerText;
                    butPractice.Text = xn["batdau"].InnerText;
                    
                    hienco = xn["hienco"].InnerText;
                    ari = xn["ari"].InnerText;
                }
            }
            catch 
            { 
            }
        }
        private void picClose_MouseClick(object sender, MouseEventArgs e)
        {
            this.Close();
        }


        void child_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Show();
        }

        private void cmbLevel_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                QuestionCount = 0;
                PrQuestionCount = 0;
                NumOfTest = 0;
                AllSelectedQue = 0;
                WithImageQue = 0;
                WithoutImageQue = 0;
                allQuestion1.Text = String.Empty;
                dataGridViewX1.Rows.Clear();
                setComboboxStatus();

                QuestionCount = command.getListFilesInDir(Constant.MediaPath + cmbLevel.Text.Trim(), "*.mp3", System.IO.SearchOption.AllDirectories).Count;
                allQuestion1.Text = hienco + QuestionCount.ToString() + " " + Constant.Sentence+ari;

                DirectoryInfo LevelDir = new DirectoryInfo(Constant.MediaPath + cmbLevel.Text);
                DirectoryInfo[] Topics = LevelDir.GetDirectories();
                foreach (DirectoryInfo item in Topics)
                {
                    List<string> ListOfQueInTopic = command.getListFilesInDir(Constant.MediaPath + cmbLevel.Text + @"\" + item.Name, @"*.mp3", SearchOption.AllDirectories);
                    if (ListOfQueInTopic != null)
                    {
                        DataGridViewCell cell1;
                        cell1 = new DataGridViewTextBoxCell();
                        cell1.Value = item.Name;

                        DataGridViewCheckBoxCell cell0;
                        cell0 = new DataGridViewCheckBoxCell();
                        cell0.Value = false;
                        DataGridViewCell cell2;
                        cell2 = new DataGridViewTextBoxCell();
                        cell2.Value = ListOfQueInTopic.Count;

                        DataGridViewRow row = new DataGridViewRow();
                        row.Cells.Add(cell0);
                        row.Cells.Add(cell1);
                        row.Cells.Add(cell2);

                        dataGridViewX1.Rows.Add(row);
                    }
                }
            }
            catch
            {

            }
        }

        private void butStart_Click(object sender, EventArgs e)
        {
            try
            {
                #region<>
                NumOfWithimangeTest = 0;
                NumOfWithoutimangeTest = 0;
                NumOfTest = Int32.Parse(cmbNumOfQue.Text);
                if (cmbWithImage.Text != "")
                {
                    NumOfWithimangeTest = Int32.Parse(cmbWithImage.Text);
                }
                if (cmbWithoutImage.Text != "")
                {
                    NumOfWithoutimangeTest = Int32.Parse(cmbWithoutImage.Text);
                    NumOfWithimangeTest = NumOfTest - NumOfWithoutimangeTest;
                    cmbWithImage.Text = NumOfWithimangeTest.ToString();
                }
                if (NumOfWithimangeTest == 0)
                    if (NumOfWithoutimangeTest == 0)
                    {
                        int min = Math.Min(WithImageQue, NumOfTest);
                        {
                            Random Rd = new Random();
                            NumOfWithimangeTest = Rd.Next(min - 1);
                            cmbWithImage.Text = NumOfWithimangeTest.ToString();
                        }
                    }
                    else
                        NumOfWithimangeTest = NumOfTest - NumOfWithoutimangeTest;
                else
                    NumOfWithoutimangeTest = NumOfTest - NumOfWithimangeTest;

                if (cmbWithImage.Text != "")
                    NumOfWithimangeTest = Int32.Parse(cmbWithImage.Text);
                if (cmbWithoutImage.Text != "")
                    NumOfWithoutimangeTest = Int32.Parse(cmbWithoutImage.Text);
                #endregion

                List<JTest.Others.ListenQuestion> TestList = new List<Others.ListenQuestion>();
                frmListenTest frmTest = new frmListenTest(cmbLevel.Text.Trim(), WithImageList, WithoutImageList, WithImageQue, NumOfWithimangeTest, WithoutImageQue, NumOfWithoutimangeTest);
                frmTest.FormClosed += new FormClosedEventHandler(child_FormClosed);
                frmTest.Show();
                this.Hide();
            }
            catch { }
        }

        private void butNewPractice_Click(object sender, EventArgs e)
        {
            try
            {
                frmListenPractice practice = new frmListenPractice(cmbPraLevel.Text, cmbPraTopic.Text);
                practice.FormClosed += new FormClosedEventHandler(child_FormClosed);
                practice.Show();
                this.Hide();
            }
            catch { }
        }

        private void cmbPraLevel_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                List<string> topicList = JTest.BUS.ListenBUS.GetSubDirList(Constant.MediaPath + cmbPraLevel.Text);
                topicList.Add("All topic");
                cmbPraTopic.DataSource = topicList;
                if (topicList != null)
                {
                    butPractice.Enabled = true;
                }
                else
                {
                    butPractice.Enabled = false;
                }
            }
            catch { }
        }

        private void frmListenSetting_Load(object sender, EventArgs e)
        {
            try
            {
                dataGridViewX1.RowsDefaultCellStyle.BackColor = Color.LightBlue;
                dataGridViewX1.AlternatingRowsDefaultCellStyle.BackColor = Color.LightSkyBlue;
                this.Width = 315;
                this.Height= 460;
            }
            catch { }
        }

        private void cmbPraTopic_SelectedIndexChanged(object sender, EventArgs e)
        {

            try
            {
                if (cmbPraTopic.Text.Trim() == "All topic")
                {
                    PrQuestionCount = command.getListFilesInDir(Constant.MediaPath + cmbPraLevel.Text.Trim() , "*.mp3", System.IO.SearchOption.AllDirectories).Count;
                }
                else
                PrQuestionCount = command.getListFilesInDir(Constant.MediaPath + cmbPraLevel.Text.Trim() + @"\" + cmbPraTopic.Text.Trim(), "*.mp3", System.IO.SearchOption.AllDirectories).Count;
                // allQuestion.Text = PrQuestionCount.ToString() + " " + Constant.Sentence;
                if (PrQuestionCount < 1)
                    butPractice.Enabled = false;
                else
                    butPractice.Enabled = true;
            }
            catch
            {
                QuestionCount = 0;
                butPractice.Enabled = false;
            }

        }

        private void dataGridViewX1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                WithImageQue = 0;
                WithoutImageQue = 0;
                cmbNumOfQue.Text = "";
                cmbWithImage.Text = "";
                cmbWithoutImage.Text = "";
                WithImageList.Clear();
                WithoutImageList.Clear();
                string s = ((DataGridViewCheckBoxCell)dataGridViewX1.CurrentCell).Value.ToString();
                if (s == "True")
                {
                    dataGridViewX1.CurrentCell.Value = false;
                }
                else
                {
                    dataGridViewX1.CurrentCell.Value = true;
                }
                string checkedTopic = String.Empty;
                List<string> tempList = new List<string>();
                for (int i = 0; i < dataGridViewX1.Rows.Count; i++)
                {
                    if (((DataGridViewCheckBoxCell)dataGridViewX1.Rows[i].Cells[0]).Value.ToString() == "True")
                    {
                        checkedTopic = dataGridViewX1.Rows[i].Cells[1].Value.ToString();
                        tempList = command.getListFilesInDir(Constant.MediaPath + cmbLevel.Text + @"\" + checkedTopic + @"\" + Constant.WithImage, "*.mp3", SearchOption.TopDirectoryOnly);
                        if (tempList != null)
                            WithImageList.AddRange(tempList);

                        tempList = command.getListFilesInDir(Constant.MediaPath + cmbLevel.Text + @"\" + checkedTopic + @"\" + Constant.WithoutImage, "*.mp3", SearchOption.TopDirectoryOnly);
                        if (tempList != null)
                            WithoutImageList.AddRange(tempList);
                    }
                }
                WithImageQue = WithImageList.Count;
                WithoutImageQue = WithoutImageList.Count;
                AllSelectedQue = WithImageQue + WithoutImageQue;
                setComboboxStatus();
            }
            catch
            {

            }
        }
        private void dataGridViewX1_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            dataGridViewX1_CellContentClick(sender, e);
        }
        private void setComboboxStatus()
        {
            try
            {
                cmbWithImage.Items.Clear();
                cmbWithoutImage.Items.Clear();
                cmbNumOfQue.Items.Clear();
                int i = 5;
                while (i <= AllSelectedQue && i <= 30)
                {
                    cmbNumOfQue.Items.Add(i);
                    i += 5;
                }
                labelSumOfWithImage.Text = WithImageQue.ToString() + " " + Constant.Sentence+ari;
                labelSumOfWithoutImage.Text = WithoutImageQue.ToString() + " " + Constant.Sentence + ari;
                labelSumOfQue.Text = AllSelectedQue.ToString() + " " + Constant.Sentence + ari;

                if (AllSelectedQue > 0)
                    cmbNumOfQue.Enabled = true;
                else
                    cmbNumOfQue.Enabled = false;

                if (WithImageQue > 0)
                    cmbWithImage.Enabled = true;
                else
                    cmbWithImage.Enabled = false;

                if (WithoutImageQue > 0)
                    cmbWithoutImage.Enabled = true;
                else
                    cmbWithoutImage.Enabled = false;
            }
            catch { }
        }

        private void cmbNumOfQue_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && !Char.IsControl(e.KeyChar))
                e.Handled = true;
        }

        private void cmbWithImage_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && !Char.IsControl(e.KeyChar))
                e.Handled = true;
        }

        private void cmbWithoutImage_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && !Char.IsControl(e.KeyChar))
                e.Handled = true;
        }

        private void cmbNumOfQue_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (cmbNumOfQue.Text != "")
                {
                    if (Int32.Parse(cmbNumOfQue.Text) > AllSelectedQue)
                    {
                        cmbNumOfQue.Text = AllSelectedQue.ToString();
                    }
                    cmbWithoutImage.Text = "";
                    cmbWithoutImage.Enabled = true;
                    cmbWithImage.Text = "";
                    cmbWithImage.Enabled = true;

                    int i = 5;
                    cmbWithImage.Items.Clear();
                    i = 5;
                    while (i <= Int32.Parse(cmbNumOfQue.Text) && i <= WithImageQue)
                    {
                        cmbWithImage.Items.Add(i);
                        i += 5;
                    }

                    cmbWithoutImage.Items.Clear();
                    i = 5;
                    while (i <= Int32.Parse(cmbNumOfQue.Text) && i <= WithoutImageQue)
                    {
                        cmbWithoutImage.Items.Add(i);
                        i += 5;
                    }

                    butStart.Enabled = true;
                }
                else
                {
                    cmbWithoutImage.Text = "";
                    cmbWithoutImage.Enabled = false;
                    cmbWithImage.Text = "";
                    cmbWithImage.Enabled = false;
                }
            }
            catch { }
        }

        private void cmbWithImage_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (cmbWithImage.Text != "")
                {
                    int min = Math.Min(Int32.Parse(cmbNumOfQue.Text), WithImageQue);
                    if (Int32.Parse(cmbWithImage.Text) > min)
                    {
                        cmbWithImage.Text = min.ToString();
                    }
                    cmbWithoutImage.Text = (Int32.Parse(cmbNumOfQue.Text) - Int32.Parse(cmbWithImage.Text)).ToString();
                }
            }
            catch { }
        }

        private void cmbWithoutImage_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (cmbWithoutImage.Text != "")
                {
                    int min = Math.Min(Int32.Parse(cmbNumOfQue.Text), WithoutImageQue);
                    if (Int32.Parse(cmbWithoutImage.Text) > min)
                    {
                        cmbWithoutImage.Text = min.ToString();
                    }
                  //  cmbWithImage.Text = (Int32.Parse(cmbNumOfQue.Text) - Int32.Parse(cmbWithoutImage.Text)).ToString();
                }
            }
            catch { }
        }
        private void cmbWithoutImage_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (cmbWithoutImage.Text != "")
                {
                    int min = Math.Min(Int32.Parse(cmbNumOfQue.Text), WithoutImageQue);
                    if (Int32.Parse(cmbWithoutImage.Text) > min)
                    {
                        cmbWithoutImage.Text = min.ToString();
                    }
                    cmbWithImage.Text = (Int32.Parse(cmbNumOfQue.Text) - Int32.Parse(cmbWithoutImage.Text)).ToString();
                }
            }
            catch { }
        }

        private void tabTest_Click(object sender, EventArgs e)
        {
            try
            {
                this.Width = 315;
                this.Height = 460;
            }
            catch { }
        }

        private void tabPractice_Click(object sender, EventArgs e)
        {
            try
            {
                this.Width = 315;
                this.Height = 190;
            }
            catch { }
        }

       
              
    }
}

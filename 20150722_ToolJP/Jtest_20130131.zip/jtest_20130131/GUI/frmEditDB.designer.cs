﻿namespace JTest.GUI
{
    partial class frmEditDB
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtQuestion = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.txtAnsA = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtAnsB = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtAnswer = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtAnsD = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtAnsC = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtHint = new System.Windows.Forms.TextBox();
            this.nmID = new System.Windows.Forms.NumericUpDown();
            this.cmbDB = new System.Windows.Forms.ComboBox();
            this.lblDatabase = new System.Windows.Forms.Label();
            this.lblID = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.cmbLevel = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.cmbType = new System.Windows.Forms.ComboBox();
            this.lblStatus = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.nmID)).BeginInit();
            this.SuspendLayout();
            // 
            // txtQuestion
            // 
            this.txtQuestion.Location = new System.Drawing.Point(121, 42);
            this.txtQuestion.Multiline = true;
            this.txtQuestion.Name = "txtQuestion";
            this.txtQuestion.Size = new System.Drawing.Size(441, 49);
            this.txtQuestion.TabIndex = 4;
            this.txtQuestion.TextChanged += new System.EventHandler(this.ChangeContent);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(45, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 13);
            this.label1.TabIndex = 17;
            this.label1.Text = "Question";
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(397, 323);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 11;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(487, 323);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 12;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(45, 117);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 18;
            this.label2.Text = "Ans A";
            // 
            // txtAnsA
            // 
            this.txtAnsA.Location = new System.Drawing.Point(121, 114);
            this.txtAnsA.Multiline = true;
            this.txtAnsA.Name = "txtAnsA";
            this.txtAnsA.Size = new System.Drawing.Size(441, 20);
            this.txtAnsA.TabIndex = 5;
            this.txtAnsA.TextChanged += new System.EventHandler(this.ChangeContent);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(45, 143);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 19;
            this.label3.Text = "Ans B";
            // 
            // txtAnsB
            // 
            this.txtAnsB.Location = new System.Drawing.Point(121, 140);
            this.txtAnsB.Multiline = true;
            this.txtAnsB.Name = "txtAnsB";
            this.txtAnsB.Size = new System.Drawing.Size(441, 20);
            this.txtAnsB.TabIndex = 6;
            this.txtAnsB.TextChanged += new System.EventHandler(this.ChangeContent);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(45, 233);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(42, 13);
            this.label4.TabIndex = 22;
            this.label4.Text = "Answer";
            // 
            // txtAnswer
            // 
            this.txtAnswer.Location = new System.Drawing.Point(121, 230);
            this.txtAnswer.Name = "txtAnswer";
            this.txtAnswer.Size = new System.Drawing.Size(100, 20);
            this.txtAnswer.TabIndex = 9;
            this.txtAnswer.TextChanged += new System.EventHandler(this.ChangeContent);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(45, 195);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(36, 13);
            this.label5.TabIndex = 21;
            this.label5.Text = "Ans D";
            // 
            // txtAnsD
            // 
            this.txtAnsD.Location = new System.Drawing.Point(121, 192);
            this.txtAnsD.Multiline = true;
            this.txtAnsD.Name = "txtAnsD";
            this.txtAnsD.Size = new System.Drawing.Size(441, 20);
            this.txtAnsD.TabIndex = 8;
            this.txtAnsD.TextChanged += new System.EventHandler(this.ChangeContent);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(45, 169);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(35, 13);
            this.label6.TabIndex = 20;
            this.label6.Text = "Ans C";
            // 
            // txtAnsC
            // 
            this.txtAnsC.Location = new System.Drawing.Point(121, 166);
            this.txtAnsC.Multiline = true;
            this.txtAnsC.Name = "txtAnsC";
            this.txtAnsC.Size = new System.Drawing.Size(441, 20);
            this.txtAnsC.TabIndex = 7;
            this.txtAnsC.TextChanged += new System.EventHandler(this.ChangeContent);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(45, 267);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(26, 13);
            this.label7.TabIndex = 23;
            this.label7.Text = "Hint";
            // 
            // txtHint
            // 
            this.txtHint.Location = new System.Drawing.Point(121, 267);
            this.txtHint.Multiline = true;
            this.txtHint.Name = "txtHint";
            this.txtHint.Size = new System.Drawing.Size(441, 44);
            this.txtHint.TabIndex = 10;
            this.txtHint.TextChanged += new System.EventHandler(this.ChangeContent);
            // 
            // nmID
            // 
            this.nmID.Location = new System.Drawing.Point(502, 12);
            this.nmID.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nmID.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nmID.Name = "nmID";
            this.nmID.Size = new System.Drawing.Size(60, 20);
            this.nmID.TabIndex = 3;
            this.nmID.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nmID.ValueChanged += new System.EventHandler(this.IDChange);
            // 
            // cmbDB
            // 
            this.cmbDB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbDB.FormattingEnabled = true;
            this.cmbDB.Location = new System.Drawing.Point(121, 12);
            this.cmbDB.Name = "cmbDB";
            this.cmbDB.Size = new System.Drawing.Size(100, 21);
            this.cmbDB.TabIndex = 0;
            this.cmbDB.SelectedIndexChanged += new System.EventHandler(this.ChangeDatabase);
            // 
            // lblDatabase
            // 
            this.lblDatabase.AutoSize = true;
            this.lblDatabase.Location = new System.Drawing.Point(45, 15);
            this.lblDatabase.Name = "lblDatabase";
            this.lblDatabase.Size = new System.Drawing.Size(53, 13);
            this.lblDatabase.TabIndex = 13;
            this.lblDatabase.Text = "Database";
            // 
            // lblID
            // 
            this.lblID.AutoSize = true;
            this.lblID.Location = new System.Drawing.Point(478, 15);
            this.lblID.Name = "lblID";
            this.lblID.Size = new System.Drawing.Size(18, 13);
            this.lblID.TabIndex = 16;
            this.lblID.Text = "ID";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(240, 18);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(33, 13);
            this.label8.TabIndex = 14;
            this.label8.Text = "Level";
            // 
            // cmbLevel
            // 
            this.cmbLevel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbLevel.FormattingEnabled = true;
            this.cmbLevel.Location = new System.Drawing.Point(280, 12);
            this.cmbLevel.Name = "cmbLevel";
            this.cmbLevel.Size = new System.Drawing.Size(61, 21);
            this.cmbLevel.TabIndex = 1;
            this.cmbLevel.SelectedIndexChanged += new System.EventHandler(this.ChangeTable);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(351, 18);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(31, 13);
            this.label9.TabIndex = 15;
            this.label9.Text = "Type";
            // 
            // cmbType
            // 
            this.cmbType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbType.FormattingEnabled = true;
            this.cmbType.Location = new System.Drawing.Point(387, 12);
            this.cmbType.Name = "cmbType";
            this.cmbType.Size = new System.Drawing.Size(73, 21);
            this.cmbType.TabIndex = 2;
            this.cmbType.SelectedIndexChanged += new System.EventHandler(this.ChangeTable);
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Location = new System.Drawing.Point(121, 328);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(0, 13);
            this.lblStatus.TabIndex = 24;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(45, 328);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(37, 13);
            this.label10.TabIndex = 25;
            this.label10.Text = "Status";
            // 
            // frmEditDB
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(586, 358);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.cmbType);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.cmbLevel);
            this.Controls.Add(this.lblID);
            this.Controls.Add(this.lblDatabase);
            this.Controls.Add(this.cmbDB);
            this.Controls.Add(this.nmID);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtHint);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtAnswer);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtAnsD);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtAnsC);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtAnsB);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtAnsA);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtQuestion);
            this.Name = "frmEditDB";
            this.Text = "Edit Database";
            ((System.ComponentModel.ISupportInitialize)(this.nmID)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtQuestion;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtAnsA;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtAnsB;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtAnswer;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtAnsD;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtAnsC;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtHint;
        private System.Windows.Forms.NumericUpDown nmID;
        private System.Windows.Forms.ComboBox cmbDB;
        private System.Windows.Forms.Label lblDatabase;
        private System.Windows.Forms.Label lblID;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cmbLevel;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cmbType;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Label label10;
    }
}
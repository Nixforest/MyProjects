﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace JTest.GUI
{
    public partial class frmWait : Form
    {

        public frmWait(Form parent)
        {
            InitializeComponent();
            this.Owner = parent;
        }

        public string InfoText { get { return lblInfo.Text; } set { lblInfo.Text = value; } }

        private void frmWait_Load(object sender, EventArgs e)
        {
            //int x = Owner.Width / 2 - this.Width / 2;
            //int y = Owner.Height / 2 - this.Height / 2;
            //this.Location = new Point(x, y) ;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

      
    }
}

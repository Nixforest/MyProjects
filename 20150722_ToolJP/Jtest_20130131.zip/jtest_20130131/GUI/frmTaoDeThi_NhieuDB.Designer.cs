﻿namespace JTest.GUI
{
    partial class frmTaoDeThi_NhieuDB
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmTaoDeThi_NhieuDB));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblDb8 = new System.Windows.Forms.Label();
            this.lblDb7 = new System.Windows.Forms.Label();
            this.lblDb6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblDb9 = new System.Windows.Forms.Label();
            this.lblDb10 = new System.Windows.Forms.Label();
            this.txtDb5 = new System.Windows.Forms.TextBox();
            this.txtDb2 = new System.Windows.Forms.TextBox();
            this.txtDb3 = new System.Windows.Forms.TextBox();
            this.txtDb4 = new System.Windows.Forms.TextBox();
            this.txtDb1 = new System.Windows.Forms.TextBox();
            this.txtDb6 = new System.Windows.Forms.TextBox();
            this.txtDb7 = new System.Windows.Forms.TextBox();
            this.txtDb8 = new System.Windows.Forms.TextBox();
            this.txtDb9 = new System.Windows.Forms.TextBox();
            this.txtDb10 = new System.Windows.Forms.TextBox();
            this.btnDb1 = new System.Windows.Forms.Button();
            this.btnDb2 = new System.Windows.Forms.Button();
            this.btnDb3 = new System.Windows.Forms.Button();
            this.btnDb4 = new System.Windows.Forms.Button();
            this.btnDb5 = new System.Windows.Forms.Button();
            this.btnDb6 = new System.Windows.Forms.Button();
            this.btnDb7 = new System.Windows.Forms.Button();
            this.btnDb9 = new System.Windows.Forms.Button();
            this.btnDb8 = new System.Windows.Forms.Button();
            this.btnDb10 = new System.Windows.Forms.Button();
            this.txtMoRong = new System.Windows.Forms.Button();
            this.btnTaoDeThi = new System.Windows.Forms.Button();
            this.btnThoat = new System.Windows.Forms.Button();
            this.lbldonvi10 = new System.Windows.Forms.Label();
            this.lbldonvi9 = new System.Windows.Forms.Label();
            this.lbldonvi8 = new System.Windows.Forms.Label();
            this.lbldonvi7 = new System.Windows.Forms.Label();
            this.lbldonvi6 = new System.Windows.Forms.Label();
            this.lbldonvi5 = new System.Windows.Forms.Label();
            this.lbldonvi4 = new System.Windows.Forms.Label();
            this.lbldonvi3 = new System.Windows.Forms.Label();
            this.lbldonvi2 = new System.Windows.Forms.Label();
            this.lbldonvi1 = new System.Windows.Forms.Label();
            this.nbrDb1 = new System.Windows.Forms.NumericUpDown();
            this.nbrDb2 = new System.Windows.Forms.NumericUpDown();
            this.nbrDb4 = new System.Windows.Forms.NumericUpDown();
            this.nbrDb3 = new System.Windows.Forms.NumericUpDown();
            this.nbrDb5 = new System.Windows.Forms.NumericUpDown();
            this.nbrDb10 = new System.Windows.Forms.NumericUpDown();
            this.nbrDb9 = new System.Windows.Forms.NumericUpDown();
            this.nbrDb8 = new System.Windows.Forms.NumericUpDown();
            this.nbrDb7 = new System.Windows.Forms.NumericUpDown();
            this.nbrDb6 = new System.Windows.Forms.NumericUpDown();
            this.lblTong = new System.Windows.Forms.Label();
            this.lblTongVal = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cmbCapDo = new System.Windows.Forms.ComboBox();
            this.cmbPhanLoai = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.nbrTongSoCau = new System.Windows.Forms.NumericUpDown();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.rdSoCau = new System.Windows.Forms.RadioButton();
            this.rdPhanTram = new System.Windows.Forms.RadioButton();
            this.label5 = new System.Windows.Forms.Label();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripProgressBar1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.tslStatus = new System.Windows.Forms.ToolStripStatusLabel();
            this.pgbTinhTrangExport = new System.Windows.Forms.ProgressBar();
            ((System.ComponentModel.ISupportInitialize)(this.nbrDb1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nbrDb2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nbrDb4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nbrDb3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nbrDb5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nbrDb10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nbrDb9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nbrDb8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nbrDb7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nbrDb6)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nbrTongSoCau)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.Name = "label3";
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.Name = "label4";
            // 
            // lblDb8
            // 
            resources.ApplyResources(this.lblDb8, "lblDb8");
            this.lblDb8.Name = "lblDb8";
            // 
            // lblDb7
            // 
            resources.ApplyResources(this.lblDb7, "lblDb7");
            this.lblDb7.Name = "lblDb7";
            // 
            // lblDb6
            // 
            resources.ApplyResources(this.lblDb6, "lblDb6");
            this.lblDb6.Name = "lblDb6";
            // 
            // label8
            // 
            resources.ApplyResources(this.label8, "label8");
            this.label8.Name = "label8";
            // 
            // lblDb9
            // 
            resources.ApplyResources(this.lblDb9, "lblDb9");
            this.lblDb9.Name = "lblDb9";
            // 
            // lblDb10
            // 
            resources.ApplyResources(this.lblDb10, "lblDb10");
            this.lblDb10.Name = "lblDb10";
            // 
            // txtDb5
            // 
            resources.ApplyResources(this.txtDb5, "txtDb5");
            this.txtDb5.Name = "txtDb5";
            
            // 
            // txtDb2
            // 
            resources.ApplyResources(this.txtDb2, "txtDb2");
            this.txtDb2.Name = "txtDb2";
            
            // 
            // txtDb3
            // 
            resources.ApplyResources(this.txtDb3, "txtDb3");
            this.txtDb3.Name = "txtDb3";
            
            // 
            // txtDb4
            // 
            resources.ApplyResources(this.txtDb4, "txtDb4");
            this.txtDb4.Name = "txtDb4";
           
            // 
            // txtDb1
            // 
            resources.ApplyResources(this.txtDb1, "txtDb1");
            this.txtDb1.Name = "txtDb1";
           
            // 
            // txtDb6
            // 
            resources.ApplyResources(this.txtDb6, "txtDb6");
            this.txtDb6.Name = "txtDb6";
           
            // 
            // txtDb7
            // 
            resources.ApplyResources(this.txtDb7, "txtDb7");
            this.txtDb7.Name = "txtDb7";
           
            // 
            // txtDb8
            // 
            resources.ApplyResources(this.txtDb8, "txtDb8");
            this.txtDb8.Name = "txtDb8";
           
            // 
            // txtDb9
            // 
            resources.ApplyResources(this.txtDb9, "txtDb9");
            this.txtDb9.Name = "txtDb9";
           
            // 
            // txtDb10
            // 
            resources.ApplyResources(this.txtDb10, "txtDb10");
            this.txtDb10.Name = "txtDb10";
           
            // 
            // btnDb1
            // 
            resources.ApplyResources(this.btnDb1, "btnDb1");
            this.btnDb1.Name = "btnDb1";
            this.btnDb1.UseVisualStyleBackColor = true;
            this.btnDb1.Click += new System.EventHandler(this.btnDb1_Click);
            // 
            // btnDb2
            // 
            resources.ApplyResources(this.btnDb2, "btnDb2");
            this.btnDb2.Name = "btnDb2";
            this.btnDb2.UseVisualStyleBackColor = true;
            this.btnDb2.Click += new System.EventHandler(this.btnDb2_Click);
            // 
            // btnDb3
            // 
            resources.ApplyResources(this.btnDb3, "btnDb3");
            this.btnDb3.Name = "btnDb3";
            this.btnDb3.UseVisualStyleBackColor = true;
            this.btnDb3.Click += new System.EventHandler(this.btnDb3_Click);
            // 
            // btnDb4
            // 
            resources.ApplyResources(this.btnDb4, "btnDb4");
            this.btnDb4.Name = "btnDb4";
            this.btnDb4.UseVisualStyleBackColor = true;
            this.btnDb4.Click += new System.EventHandler(this.btnDb4_Click);
            // 
            // btnDb5
            // 
            resources.ApplyResources(this.btnDb5, "btnDb5");
            this.btnDb5.Name = "btnDb5";
            this.btnDb5.UseVisualStyleBackColor = true;
            this.btnDb5.Click += new System.EventHandler(this.btnDb5_Click);
            // 
            // btnDb6
            // 
            resources.ApplyResources(this.btnDb6, "btnDb6");
            this.btnDb6.Name = "btnDb6";
            this.btnDb6.UseVisualStyleBackColor = true;
            this.btnDb6.Click += new System.EventHandler(this.btnDb6_Click);
            // 
            // btnDb7
            // 
            resources.ApplyResources(this.btnDb7, "btnDb7");
            this.btnDb7.Name = "btnDb7";
            this.btnDb7.UseVisualStyleBackColor = true;
            this.btnDb7.Click += new System.EventHandler(this.btnDb7_Click);
            // 
            // btnDb9
            // 
            resources.ApplyResources(this.btnDb9, "btnDb9");
            this.btnDb9.Name = "btnDb9";
            this.btnDb9.UseVisualStyleBackColor = true;
            this.btnDb9.Click += new System.EventHandler(this.btnDb9_Click);
            // 
            // btnDb8
            // 
            resources.ApplyResources(this.btnDb8, "btnDb8");
            this.btnDb8.Name = "btnDb8";
            this.btnDb8.UseVisualStyleBackColor = true;
            this.btnDb8.Click += new System.EventHandler(this.btnDb8_Click);
            // 
            // btnDb10
            // 
            resources.ApplyResources(this.btnDb10, "btnDb10");
            this.btnDb10.Name = "btnDb10";
            this.btnDb10.UseVisualStyleBackColor = true;
            this.btnDb10.Click += new System.EventHandler(this.btnDb10_Click);
            // 
            // txtMoRong
            // 
            resources.ApplyResources(this.txtMoRong, "txtMoRong");
            this.txtMoRong.Name = "txtMoRong";
            this.txtMoRong.UseVisualStyleBackColor = true;
            this.txtMoRong.Click += new System.EventHandler(this.txtMoRong_Click);
            // 
            // btnTaoDeThi
            // 
            resources.ApplyResources(this.btnTaoDeThi, "btnTaoDeThi");
            this.btnTaoDeThi.Name = "btnTaoDeThi";
            this.btnTaoDeThi.UseVisualStyleBackColor = true;
            this.btnTaoDeThi.Click += new System.EventHandler(this.btnTaoDeThi_Click);
            // 
            // btnThoat
            // 
            resources.ApplyResources(this.btnThoat, "btnThoat");
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.UseVisualStyleBackColor = true;
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
            // 
            // lbldonvi10
            // 
            resources.ApplyResources(this.lbldonvi10, "lbldonvi10");
            this.lbldonvi10.Name = "lbldonvi10";
            // 
            // lbldonvi9
            // 
            resources.ApplyResources(this.lbldonvi9, "lbldonvi9");
            this.lbldonvi9.Name = "lbldonvi9";
            // 
            // lbldonvi8
            // 
            resources.ApplyResources(this.lbldonvi8, "lbldonvi8");
            this.lbldonvi8.Name = "lbldonvi8";
            // 
            // lbldonvi7
            // 
            resources.ApplyResources(this.lbldonvi7, "lbldonvi7");
            this.lbldonvi7.Name = "lbldonvi7";
            // 
            // lbldonvi6
            // 
            resources.ApplyResources(this.lbldonvi6, "lbldonvi6");
            this.lbldonvi6.Name = "lbldonvi6";
            // 
            // lbldonvi5
            // 
            resources.ApplyResources(this.lbldonvi5, "lbldonvi5");
            this.lbldonvi5.Name = "lbldonvi5";
            // 
            // lbldonvi4
            // 
            resources.ApplyResources(this.lbldonvi4, "lbldonvi4");
            this.lbldonvi4.Name = "lbldonvi4";
            // 
            // lbldonvi3
            // 
            resources.ApplyResources(this.lbldonvi3, "lbldonvi3");
            this.lbldonvi3.Name = "lbldonvi3";
            // 
            // lbldonvi2
            // 
            resources.ApplyResources(this.lbldonvi2, "lbldonvi2");
            this.lbldonvi2.Name = "lbldonvi2";
            // 
            // lbldonvi1
            // 
            resources.ApplyResources(this.lbldonvi1, "lbldonvi1");
            this.lbldonvi1.Name = "lbldonvi1";
            // 
            // nbrDb1
            // 
            resources.ApplyResources(this.nbrDb1, "nbrDb1");
            this.nbrDb1.Name = "nbrDb1";
            this.nbrDb1.ValueChanged += new System.EventHandler(this.nbrDb1_ValueChanged);
            // 
            // nbrDb2
            // 
            resources.ApplyResources(this.nbrDb2, "nbrDb2");
            this.nbrDb2.Name = "nbrDb2";
            this.nbrDb2.ValueChanged += new System.EventHandler(this.nbrDb2_ValueChanged);
            // 
            // nbrDb4
            // 
            resources.ApplyResources(this.nbrDb4, "nbrDb4");
            this.nbrDb4.Name = "nbrDb4";
            this.nbrDb4.ValueChanged += new System.EventHandler(this.nbrDb4_ValueChanged);
            // 
            // nbrDb3
            // 
            resources.ApplyResources(this.nbrDb3, "nbrDb3");
            this.nbrDb3.Name = "nbrDb3";
            this.nbrDb3.ValueChanged += new System.EventHandler(this.nbrDb3_ValueChanged);
            // 
            // nbrDb5
            // 
            resources.ApplyResources(this.nbrDb5, "nbrDb5");
            this.nbrDb5.Name = "nbrDb5";
            this.nbrDb5.ValueChanged += new System.EventHandler(this.nbrDb5_ValueChanged);
            // 
            // nbrDb10
            // 
            resources.ApplyResources(this.nbrDb10, "nbrDb10");
            this.nbrDb10.Name = "nbrDb10";
            this.nbrDb10.ValueChanged += new System.EventHandler(this.nbrDb10_ValueChanged);
            // 
            // nbrDb9
            // 
            resources.ApplyResources(this.nbrDb9, "nbrDb9");
            this.nbrDb9.Name = "nbrDb9";
            this.nbrDb9.ValueChanged += new System.EventHandler(this.nbrDb9_ValueChanged);
            // 
            // nbrDb8
            // 
            resources.ApplyResources(this.nbrDb8, "nbrDb8");
            this.nbrDb8.Name = "nbrDb8";
            this.nbrDb8.ValueChanged += new System.EventHandler(this.nbrDb8_ValueChanged);
            // 
            // nbrDb7
            // 
            resources.ApplyResources(this.nbrDb7, "nbrDb7");
            this.nbrDb7.Name = "nbrDb7";
            this.nbrDb7.ValueChanged += new System.EventHandler(this.nbrDb7_ValueChanged);
            // 
            // nbrDb6
            // 
            resources.ApplyResources(this.nbrDb6, "nbrDb6");
            this.nbrDb6.Name = "nbrDb6";
            this.nbrDb6.ValueChanged += new System.EventHandler(this.nbrDb6_ValueChanged);
            // 
            // lblTong
            // 
            resources.ApplyResources(this.lblTong, "lblTong");
            this.lblTong.Name = "lblTong";
            // 
            // lblTongVal
            // 
            resources.ApplyResources(this.lblTongVal, "lblTongVal");
            this.lblTongVal.Name = "lblTongVal";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cmbCapDo);
            this.groupBox1.Controls.Add(this.cmbPhanLoai);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.nbrTongSoCau);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.label5);
            resources.ApplyResources(this.groupBox1, "groupBox1");
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.TabStop = false;
            // 
            // cmbCapDo
            // 
            this.cmbCapDo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbCapDo, "cmbCapDo");
            this.cmbCapDo.FormattingEnabled = true;
            this.cmbCapDo.Name = "cmbCapDo";
            this.cmbCapDo.Sorted = true;
            this.cmbCapDo.SelectedIndexChanged += new System.EventHandler(this.cmbCapDo_SelectedIndexChanged);
            // 
            // cmbPhanLoai
            // 
            this.cmbPhanLoai.AccessibleRole = System.Windows.Forms.AccessibleRole.ScrollBar;
            this.cmbPhanLoai.Cursor = System.Windows.Forms.Cursors.Default;
            this.cmbPhanLoai.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cmbPhanLoai, "cmbPhanLoai");
            this.cmbPhanLoai.FormattingEnabled = true;
            this.cmbPhanLoai.Name = "cmbPhanLoai";
            this.cmbPhanLoai.Sorted = true;
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.Name = "label6";
            // 
            // label7
            // 
            resources.ApplyResources(this.label7, "label7");
            this.label7.Name = "label7";
            // 
            // nbrTongSoCau
            // 
            resources.ApplyResources(this.nbrTongSoCau, "nbrTongSoCau");
            this.nbrTongSoCau.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.nbrTongSoCau.Name = "nbrTongSoCau";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.rdSoCau);
            this.groupBox2.Controls.Add(this.rdPhanTram);
            resources.ApplyResources(this.groupBox2, "groupBox2");
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.TabStop = false;
            // 
            // rdSoCau
            // 
            resources.ApplyResources(this.rdSoCau, "rdSoCau");
            this.rdSoCau.Name = "rdSoCau";
            this.rdSoCau.TabStop = true;
            this.rdSoCau.UseVisualStyleBackColor = true;
            this.rdSoCau.CheckedChanged += new System.EventHandler(this.rdSoCau_CheckedChanged);
            // 
            // rdPhanTram
            // 
            resources.ApplyResources(this.rdPhanTram, "rdPhanTram");
            this.rdPhanTram.Name = "rdPhanTram";
            this.rdPhanTram.TabStop = true;
            this.rdPhanTram.UseVisualStyleBackColor = true;
            this.rdPhanTram.CheckedChanged += new System.EventHandler(this.rdPhanTram_CheckedChanged);
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.Name = "label5";
            // 
            // openFileDialog
            // 
            this.openFileDialog.FileName = "openFileDialog1";
            // 
            // statusStrip1
            // 
            resources.ApplyResources(this.statusStrip1, "statusStrip1");
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripProgressBar1,
            this.tslStatus});
            this.statusStrip1.Name = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            resources.ApplyResources(this.toolStripStatusLabel1, "toolStripStatusLabel1");
            // 
            // toolStripProgressBar1
            // 
            this.toolStripProgressBar1.Name = "toolStripProgressBar1";
            resources.ApplyResources(this.toolStripProgressBar1, "toolStripProgressBar1");
            // 
            // tslStatus
            // 
            this.tslStatus.Name = "tslStatus";
            resources.ApplyResources(this.tslStatus, "tslStatus");
            // 
            // pgbTinhTrangExport
            // 
            this.pgbTinhTrangExport.Cursor = System.Windows.Forms.Cursors.AppStarting;
            resources.ApplyResources(this.pgbTinhTrangExport, "pgbTinhTrangExport");
            this.pgbTinhTrangExport.Name = "pgbTinhTrangExport";
            // 
            // frmTaoDeThi_NhieuDB
            // 
            this.AcceptButton = this.btnDb1;
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pgbTinhTrangExport);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.lblTongVal);
            this.Controls.Add(this.lblTong);
            this.Controls.Add(this.nbrDb10);
            this.Controls.Add(this.nbrDb9);
            this.Controls.Add(this.nbrDb8);
            this.Controls.Add(this.nbrDb7);
            this.Controls.Add(this.nbrDb6);
            this.Controls.Add(this.nbrDb5);
            this.Controls.Add(this.nbrDb4);
            this.Controls.Add(this.nbrDb3);
            this.Controls.Add(this.nbrDb2);
            this.Controls.Add(this.nbrDb1);
            this.Controls.Add(this.lbldonvi10);
            this.Controls.Add(this.lbldonvi9);
            this.Controls.Add(this.lbldonvi8);
            this.Controls.Add(this.lbldonvi7);
            this.Controls.Add(this.lbldonvi6);
            this.Controls.Add(this.lbldonvi5);
            this.Controls.Add(this.lbldonvi4);
            this.Controls.Add(this.lbldonvi3);
            this.Controls.Add(this.lbldonvi2);
            this.Controls.Add(this.lbldonvi1);
            this.Controls.Add(this.btnThoat);
            this.Controls.Add(this.btnTaoDeThi);
            this.Controls.Add(this.btnDb10);
            this.Controls.Add(this.btnDb8);
            this.Controls.Add(this.txtMoRong);
            this.Controls.Add(this.btnDb5);
            this.Controls.Add(this.btnDb9);
            this.Controls.Add(this.btnDb3);
            this.Controls.Add(this.btnDb7);
            this.Controls.Add(this.btnDb4);
            this.Controls.Add(this.btnDb6);
            this.Controls.Add(this.btnDb2);
            this.Controls.Add(this.btnDb1);
            this.Controls.Add(this.txtDb10);
            this.Controls.Add(this.txtDb9);
            this.Controls.Add(this.txtDb1);
            this.Controls.Add(this.txtDb8);
            this.Controls.Add(this.txtDb4);
            this.Controls.Add(this.txtDb7);
            this.Controls.Add(this.txtDb3);
            this.Controls.Add(this.txtDb6);
            this.Controls.Add(this.txtDb2);
            this.Controls.Add(this.txtDb5);
            this.Controls.Add(this.lblDb10);
            this.Controls.Add(this.lblDb9);
            this.Controls.Add(this.lblDb8);
            this.Controls.Add(this.lblDb7);
            this.Controls.Add(this.lblDb6);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmTaoDeThi_NhieuDB";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.Load += new System.EventHandler(this.frmTaoDeThi_NhieuDB_Load);
            ((System.ComponentModel.ISupportInitialize)(this.nbrDb1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nbrDb2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nbrDb4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nbrDb3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nbrDb5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nbrDb10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nbrDb9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nbrDb8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nbrDb7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nbrDb6)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nbrTongSoCau)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblDb8;
        private System.Windows.Forms.Label lblDb7;
        private System.Windows.Forms.Label lblDb6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblDb9;
        private System.Windows.Forms.Label lblDb10;
        private System.Windows.Forms.TextBox txtDb5;
        private System.Windows.Forms.TextBox txtDb2;
        private System.Windows.Forms.TextBox txtDb3;
        private System.Windows.Forms.TextBox txtDb4;
        private System.Windows.Forms.TextBox txtDb1;
        private System.Windows.Forms.TextBox txtDb6;
        private System.Windows.Forms.TextBox txtDb7;
        private System.Windows.Forms.TextBox txtDb8;
        private System.Windows.Forms.TextBox txtDb9;
        private System.Windows.Forms.TextBox txtDb10;
        private System.Windows.Forms.Button btnDb1;
        private System.Windows.Forms.Button btnDb2;
        private System.Windows.Forms.Button btnDb3;
        private System.Windows.Forms.Button btnDb4;
        private System.Windows.Forms.Button btnDb5;
        private System.Windows.Forms.Button btnDb6;
        private System.Windows.Forms.Button btnDb7;
        private System.Windows.Forms.Button btnDb9;
        private System.Windows.Forms.Button btnDb8;
        private System.Windows.Forms.Button btnDb10;
        private System.Windows.Forms.Button txtMoRong;
        private System.Windows.Forms.Button btnTaoDeThi;
        private System.Windows.Forms.Button btnThoat;
        private System.Windows.Forms.Label lbldonvi10;
        private System.Windows.Forms.Label lbldonvi9;
        private System.Windows.Forms.Label lbldonvi8;
        private System.Windows.Forms.Label lbldonvi7;
        private System.Windows.Forms.Label lbldonvi6;
        private System.Windows.Forms.Label lbldonvi5;
        private System.Windows.Forms.Label lbldonvi4;
        private System.Windows.Forms.Label lbldonvi3;
        private System.Windows.Forms.Label lbldonvi2;
        private System.Windows.Forms.Label lbldonvi1;
        private System.Windows.Forms.NumericUpDown nbrDb1;
        private System.Windows.Forms.NumericUpDown nbrDb2;
        private System.Windows.Forms.NumericUpDown nbrDb4;
        private System.Windows.Forms.NumericUpDown nbrDb3;
        private System.Windows.Forms.NumericUpDown nbrDb5;
        private System.Windows.Forms.NumericUpDown nbrDb10;
        private System.Windows.Forms.NumericUpDown nbrDb9;
        private System.Windows.Forms.NumericUpDown nbrDb8;
        private System.Windows.Forms.NumericUpDown nbrDb7;
        private System.Windows.Forms.NumericUpDown nbrDb6;
        private System.Windows.Forms.Label lblTong;
        private System.Windows.Forms.Label lblTongVal;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.RadioButton rdSoCau;
        private System.Windows.Forms.RadioButton rdPhanTram;
        private System.Windows.Forms.OpenFileDialog openFileDialog;
        private System.Windows.Forms.NumericUpDown nbrTongSoCau;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cmbCapDo;
        public System.Windows.Forms.ComboBox cmbPhanLoai;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripProgressBar1;
        private System.Windows.Forms.ToolStripStatusLabel tslStatus;
        private System.Windows.Forms.ProgressBar pgbTinhTrangExport;


    }
}
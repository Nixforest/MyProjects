﻿namespace JTest.GUI
{
    partial class frmListenTest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmListenTest));
            this.groupPanelImage = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.labelXNoImageMess = new DevComponents.DotNetBar.LabelX();
            this.axWMP = new AxWMPLib.AxWindowsMediaPlayer();
            this.listBoxQuestion = new System.Windows.Forms.ListBox();
            this.picQuestion = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupPanelInfo = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.textCountDown = new DevComponents.DotNetBar.LabelX();
            this.butFinish = new DevComponents.DotNetBar.ButtonX();
            this.labQuestion = new DevComponents.DotNetBar.LabelX();
            this.textCurrentQue = new DevComponents.DotNetBar.LabelX();
            this.labLevel = new DevComponents.DotNetBar.LabelX();
            this.textLevel = new DevComponents.DotNetBar.LabelX();
            this.groupPanelAnswer = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.sliderVol = new DevComponents.DotNetBar.Controls.Slider();
            this.radAnswer4 = new System.Windows.Forms.RadioButton();
            this.radAnswer3 = new System.Windows.Forms.RadioButton();
            this.radAnswer2 = new System.Windows.Forms.RadioButton();
            this.radAnswer1 = new System.Windows.Forms.RadioButton();
            this.timerCountDown = new System.Windows.Forms.Timer(this.components);
            this.saveFileDialogListenTested = new System.Windows.Forms.SaveFileDialog();
            this.groupPanelImage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.axWMP)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picQuestion)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupPanelInfo.SuspendLayout();
            this.groupPanelAnswer.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupPanelImage
            // 
            this.groupPanelImage.CanvasColor = System.Drawing.SystemColors.Control;
            this.groupPanelImage.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.groupPanelImage.Controls.Add(this.labelXNoImageMess);
            this.groupPanelImage.Controls.Add(this.axWMP);
            this.groupPanelImage.Controls.Add(this.listBoxQuestion);
            this.groupPanelImage.Controls.Add(this.picQuestion);
            this.groupPanelImage.Location = new System.Drawing.Point(7, 7);
            this.groupPanelImage.Name = "groupPanelImage";
            this.groupPanelImage.Size = new System.Drawing.Size(557, 450);
            // 
            // 
            // 
            this.groupPanelImage.Style.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.groupPanelImage.Style.BackColorGradientAngle = 90;
            this.groupPanelImage.Style.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.groupPanelImage.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanelImage.Style.BorderBottomWidth = 1;
            this.groupPanelImage.Style.BorderColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.groupPanelImage.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanelImage.Style.BorderLeftWidth = 1;
            this.groupPanelImage.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanelImage.Style.BorderRightWidth = 1;
            this.groupPanelImage.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanelImage.Style.BorderTopWidth = 1;
            this.groupPanelImage.Style.CornerDiameter = 4;
            this.groupPanelImage.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.groupPanelImage.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.groupPanelImage.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.groupPanelImage.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            this.groupPanelImage.TabIndex = 0;
            // 
            // labelXNoImageMess
            // 
            this.labelXNoImageMess.BackColor = System.Drawing.Color.Transparent;
            this.labelXNoImageMess.BackgroundImage = global::JTest.Properties.Resources.BK;
            this.labelXNoImageMess.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelXNoImageMess.Location = new System.Drawing.Point(19, 275);
            this.labelXNoImageMess.Name = "labelXNoImageMess";
            this.labelXNoImageMess.Size = new System.Drawing.Size(513, 52);
            this.labelXNoImageMess.TabIndex = 3;
            this.labelXNoImageMess.Text = "Câu hỏi không có tranh...";
            this.labelXNoImageMess.TextAlignment = System.Drawing.StringAlignment.Center;
            this.labelXNoImageMess.Visible = false;
            // 
            // axWMP
            // 
            this.axWMP.Enabled = true;
            this.axWMP.Location = new System.Drawing.Point(6, 350);
            this.axWMP.Name = "axWMP";
            this.axWMP.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axWMP.OcxState")));
            this.axWMP.Size = new System.Drawing.Size(401, 82);
            this.axWMP.TabIndex = 2;
            this.axWMP.Visible = false;
            this.axWMP.OpenStateChange += new AxWMPLib._WMPOCXEvents_OpenStateChangeEventHandler(this.axWMP_OpenStateChange);
            this.axWMP.PlayStateChange += new AxWMPLib._WMPOCXEvents_PlayStateChangeEventHandler(this.axWMP_PlayStateChange);
            // 
            // listBoxQuestion
            // 
            this.listBoxQuestion.FormattingEnabled = true;
            this.listBoxQuestion.Location = new System.Drawing.Point(442, 3);
            this.listBoxQuestion.Name = "listBoxQuestion";
            this.listBoxQuestion.Size = new System.Drawing.Size(106, 160);
            this.listBoxQuestion.TabIndex = 1;
            this.listBoxQuestion.Visible = false;
            this.listBoxQuestion.SelectedIndexChanged += new System.EventHandler(this.listBoxQuestion_SelectedIndexChanged);
            // 
            // picQuestion
            // 
            this.picQuestion.BackColor = System.Drawing.Color.White;
            this.picQuestion.BackgroundImage = global::JTest.Properties.Resources.ListenBK;
            this.picQuestion.Dock = System.Windows.Forms.DockStyle.Fill;
            this.picQuestion.Location = new System.Drawing.Point(0, 0);
            this.picQuestion.Name = "picQuestion";
            this.picQuestion.Size = new System.Drawing.Size(551, 444);
            this.picQuestion.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picQuestion.TabIndex = 0;
            this.picQuestion.TabStop = false;
            this.picQuestion.MouseDown += new System.Windows.Forms.MouseEventHandler(this.picQuestion_MouseDown);
            this.picQuestion.MouseMove += new System.Windows.Forms.MouseEventHandler(this.picQuestion_MouseMove);
            this.picQuestion.MouseUp += new System.Windows.Forms.MouseEventHandler(this.picQuestion_MouseUp);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(572, 550);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseDown);
            this.pictureBox1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseMove);
            this.pictureBox1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseUp);
            // 
            // groupPanelInfo
            // 
            this.groupPanelInfo.BackColor = System.Drawing.Color.Transparent;
            this.groupPanelInfo.CanvasColor = System.Drawing.SystemColors.Control;
            this.groupPanelInfo.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2000;
            this.groupPanelInfo.Controls.Add(this.textCountDown);
            this.groupPanelInfo.Controls.Add(this.butFinish);
            this.groupPanelInfo.Controls.Add(this.labQuestion);
            this.groupPanelInfo.Controls.Add(this.textCurrentQue);
            this.groupPanelInfo.Controls.Add(this.labLevel);
            this.groupPanelInfo.Controls.Add(this.textLevel);
            this.groupPanelInfo.Location = new System.Drawing.Point(7, 462);
            this.groupPanelInfo.Name = "groupPanelInfo";
            this.groupPanelInfo.Size = new System.Drawing.Size(277, 80);
            // 
            // 
            // 
            this.groupPanelInfo.Style.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.groupPanelInfo.Style.BackColorGradientAngle = 90;
            this.groupPanelInfo.Style.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.groupPanelInfo.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanelInfo.Style.BorderBottomWidth = 1;
            this.groupPanelInfo.Style.BorderColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.groupPanelInfo.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanelInfo.Style.BorderLeftWidth = 1;
            this.groupPanelInfo.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanelInfo.Style.BorderRightWidth = 1;
            this.groupPanelInfo.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanelInfo.Style.BorderTopWidth = 1;
            this.groupPanelInfo.Style.CornerDiameter = 4;
            this.groupPanelInfo.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.groupPanelInfo.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.groupPanelInfo.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.groupPanelInfo.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            this.groupPanelInfo.TabIndex = 4;
            this.groupPanelInfo.Text = "Thông tin";
            // 
            // textCountDown
            // 
            this.textCountDown.BackColor = System.Drawing.Color.Transparent;
            this.textCountDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textCountDown.ForeColor = System.Drawing.Color.Red;
            this.textCountDown.Location = new System.Drawing.Point(0, -5);
            this.textCountDown.Name = "textCountDown";
            this.textCountDown.Size = new System.Drawing.Size(82, 63);
            this.textCountDown.TabIndex = 3;
            this.textCountDown.Text = "10";
            this.textCountDown.TextAlignment = System.Drawing.StringAlignment.Center;
            this.textCountDown.Visible = false;
            // 
            // butFinish
            // 
            this.butFinish.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.butFinish.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.butFinish.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butFinish.Location = new System.Drawing.Point(185, 16);
            this.butFinish.Name = "butFinish";
            this.butFinish.Size = new System.Drawing.Size(78, 29);
            this.butFinish.TabIndex = 1;
            this.butFinish.Text = "Kết thúc";
            this.butFinish.Click += new System.EventHandler(this.butFinish_Click);
            // 
            // labQuestion
            // 
            this.labQuestion.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labQuestion.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labQuestion.Location = new System.Drawing.Point(81, -5);
            this.labQuestion.Name = "labQuestion";
            this.labQuestion.Size = new System.Drawing.Size(103, 35);
            this.labQuestion.TabIndex = 0;
            this.labQuestion.Text = "Câu hỏi";
            this.labQuestion.TextAlignment = System.Drawing.StringAlignment.Center;
            // 
            // textCurrentQue
            // 
            this.textCurrentQue.Font = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textCurrentQue.ForeColor = System.Drawing.Color.White;
            this.textCurrentQue.Location = new System.Drawing.Point(81, 28);
            this.textCurrentQue.Name = "textCurrentQue";
            this.textCurrentQue.Size = new System.Drawing.Size(103, 35);
            this.textCurrentQue.TabIndex = 0;
            this.textCurrentQue.Text = "1/10";
            this.textCurrentQue.TextAlignment = System.Drawing.StringAlignment.Center;
            // 
            // labLevel
            // 
            this.labLevel.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labLevel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labLevel.Location = new System.Drawing.Point(6, -5);
            this.labLevel.Name = "labLevel";
            this.labLevel.Size = new System.Drawing.Size(76, 35);
            this.labLevel.TabIndex = 0;
            this.labLevel.Text = "Cấp độ";
            this.labLevel.TextAlignment = System.Drawing.StringAlignment.Center;
            // 
            // textLevel
            // 
            this.textLevel.Font = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textLevel.ForeColor = System.Drawing.Color.White;
            this.textLevel.Location = new System.Drawing.Point(6, 28);
            this.textLevel.Name = "textLevel";
            this.textLevel.Size = new System.Drawing.Size(76, 35);
            this.textLevel.TabIndex = 0;
            this.textLevel.Text = "N4";
            this.textLevel.TextAlignment = System.Drawing.StringAlignment.Center;
            // 
            // groupPanelAnswer
            // 
            this.groupPanelAnswer.BackColor = System.Drawing.Color.Transparent;
            this.groupPanelAnswer.CanvasColor = System.Drawing.SystemColors.Control;
            this.groupPanelAnswer.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2000;
            this.groupPanelAnswer.Controls.Add(this.sliderVol);
            this.groupPanelAnswer.Controls.Add(this.radAnswer4);
            this.groupPanelAnswer.Controls.Add(this.radAnswer3);
            this.groupPanelAnswer.Controls.Add(this.radAnswer2);
            this.groupPanelAnswer.Controls.Add(this.radAnswer1);
            this.groupPanelAnswer.Location = new System.Drawing.Point(287, 462);
            this.groupPanelAnswer.Name = "groupPanelAnswer";
            this.groupPanelAnswer.Size = new System.Drawing.Size(277, 80);
            // 
            // 
            // 
            this.groupPanelAnswer.Style.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.groupPanelAnswer.Style.BackColorGradientAngle = 90;
            this.groupPanelAnswer.Style.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.groupPanelAnswer.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanelAnswer.Style.BorderBottomWidth = 1;
            this.groupPanelAnswer.Style.BorderColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.groupPanelAnswer.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanelAnswer.Style.BorderLeftWidth = 1;
            this.groupPanelAnswer.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanelAnswer.Style.BorderRightWidth = 1;
            this.groupPanelAnswer.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanelAnswer.Style.BorderTopWidth = 1;
            this.groupPanelAnswer.Style.CornerDiameter = 4;
            this.groupPanelAnswer.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.groupPanelAnswer.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.groupPanelAnswer.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.groupPanelAnswer.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            this.groupPanelAnswer.TabIndex = 5;
            this.groupPanelAnswer.Text = "Chọn câu trả lời";
            // 
            // sliderVol
            // 
            this.sliderVol.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F);
            this.sliderVol.Location = new System.Drawing.Point(29, 33);
            this.sliderVol.Name = "sliderVol";
            this.sliderVol.Size = new System.Drawing.Size(175, 29);
            this.sliderVol.TabIndex = 2;
            this.sliderVol.TextColor = System.Drawing.Color.White;
            this.sliderVol.Value = 0;
            this.sliderVol.ValueChanged += new System.EventHandler(this.sliderVol_ValueChanged);
            // 
            // radAnswer4
            // 
            this.radAnswer4.AutoSize = true;
            this.radAnswer4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radAnswer4.ForeColor = System.Drawing.Color.White;
            this.radAnswer4.Location = new System.Drawing.Point(210, 3);
            this.radAnswer4.Name = "radAnswer4";
            this.radAnswer4.Size = new System.Drawing.Size(39, 28);
            this.radAnswer4.TabIndex = 1;
            this.radAnswer4.TabStop = true;
            this.radAnswer4.Text = "4";
            this.radAnswer4.UseVisualStyleBackColor = true;
            this.radAnswer4.CheckedChanged += new System.EventHandler(this.radAnswer4_CheckedChanged);
            // 
            // radAnswer3
            // 
            this.radAnswer3.AutoSize = true;
            this.radAnswer3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radAnswer3.ForeColor = System.Drawing.Color.White;
            this.radAnswer3.Location = new System.Drawing.Point(155, 3);
            this.radAnswer3.Name = "radAnswer3";
            this.radAnswer3.Size = new System.Drawing.Size(39, 28);
            this.radAnswer3.TabIndex = 1;
            this.radAnswer3.TabStop = true;
            this.radAnswer3.Text = "3";
            this.radAnswer3.UseVisualStyleBackColor = true;
            this.radAnswer3.CheckedChanged += new System.EventHandler(this.radAnswer3_CheckedChanged);
            // 
            // radAnswer2
            // 
            this.radAnswer2.AutoSize = true;
            this.radAnswer2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radAnswer2.ForeColor = System.Drawing.Color.White;
            this.radAnswer2.Location = new System.Drawing.Point(92, 3);
            this.radAnswer2.Name = "radAnswer2";
            this.radAnswer2.Size = new System.Drawing.Size(39, 28);
            this.radAnswer2.TabIndex = 1;
            this.radAnswer2.TabStop = true;
            this.radAnswer2.Text = "2";
            this.radAnswer2.UseVisualStyleBackColor = true;
            this.radAnswer2.CheckedChanged += new System.EventHandler(this.radAnswer2_CheckedChanged);
            // 
            // radAnswer1
            // 
            this.radAnswer1.AutoSize = true;
            this.radAnswer1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radAnswer1.ForeColor = System.Drawing.Color.White;
            this.radAnswer1.Location = new System.Drawing.Point(29, 3);
            this.radAnswer1.Name = "radAnswer1";
            this.radAnswer1.Size = new System.Drawing.Size(39, 28);
            this.radAnswer1.TabIndex = 1;
            this.radAnswer1.TabStop = true;
            this.radAnswer1.Text = "1";
            this.radAnswer1.UseVisualStyleBackColor = true;
            this.radAnswer1.CheckedChanged += new System.EventHandler(this.radAnswer1_CheckedChanged);
            // 
            // timerCountDown
            // 
            this.timerCountDown.Interval = 1000;
            this.timerCountDown.Tick += new System.EventHandler(this.timerCountDown_Tick);
            // 
            // frmListenTest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(572, 550);
            this.Controls.Add(this.groupPanelAnswer);
            this.Controls.Add(this.groupPanelImage);
            this.Controls.Add(this.groupPanelInfo);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmListenTest";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmListenTest";
            this.TransparencyKey = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.groupPanelImage.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.axWMP)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picQuestion)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupPanelInfo.ResumeLayout(false);
            this.groupPanelAnswer.ResumeLayout(false);
            this.groupPanelAnswer.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevComponents.DotNetBar.Controls.GroupPanel groupPanelImage;
        private System.Windows.Forms.PictureBox picQuestion;
        private System.Windows.Forms.PictureBox pictureBox1;
        private DevComponents.DotNetBar.Controls.GroupPanel groupPanelInfo;
        private DevComponents.DotNetBar.Controls.GroupPanel groupPanelAnswer;
        private DevComponents.DotNetBar.ButtonX butFinish;
        private DevComponents.DotNetBar.LabelX labQuestion;
        private DevComponents.DotNetBar.LabelX textCurrentQue;
        private DevComponents.DotNetBar.LabelX labLevel;
        private DevComponents.DotNetBar.LabelX textLevel;
        private System.Windows.Forms.RadioButton radAnswer4;
        private System.Windows.Forms.RadioButton radAnswer3;
        private System.Windows.Forms.RadioButton radAnswer2;
        private System.Windows.Forms.RadioButton radAnswer1;
        private AxWMPLib.AxWindowsMediaPlayer axWMP;
        private System.Windows.Forms.ListBox listBoxQuestion;
        private System.Windows.Forms.Timer timerCountDown;
        private DevComponents.DotNetBar.LabelX textCountDown;
        private System.Windows.Forms.SaveFileDialog saveFileDialogListenTested;
        private DevComponents.DotNetBar.Controls.Slider sliderVol;
        private DevComponents.DotNetBar.LabelX labelXNoImageMess;

    }
}
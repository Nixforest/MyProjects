﻿using System.Drawing;
using System.Windows.Forms;
namespace JTest.GUI
{
    partial class frmListenPractice
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmListenPractice));
            this.dotNetBarMan = new DevComponents.DotNetBar.DotNetBarManager(this.components);
            this.dockSite4 = new DevComponents.DotNetBar.DockSite();
            this.bar1 = new DevComponents.DotNetBar.Bar();
            this.panelDockContainer2 = new DevComponents.DotNetBar.PanelDockContainer();
            this.richTextBoxScript = new System.Windows.Forms.RichTextBox();
            this.dockContainerItem2 = new DevComponents.DotNetBar.DockContainerItem();
            this.dockSite1 = new DevComponents.DotNetBar.DockSite();
            this.barControl = new DevComponents.DotNetBar.Bar();
            this.panelDockContainer1 = new DevComponents.DotNetBar.PanelDockContainer();
            this.textTrueAns = new DevComponents.DotNetBar.LabelX();
            this.labTrueAns = new DevComponents.DotNetBar.LabelX();
            this.textNumOfQue = new DevComponents.DotNetBar.LabelX();
            this.labelNumOfQue = new DevComponents.DotNetBar.LabelX();
            this.groupPanelAnswer = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.checkBoxShowKey = new DevComponents.DotNetBar.Controls.CheckBoxX();
            this.butExits = new DevComponents.DotNetBar.ButtonX();
            this.butShowAnswer = new DevComponents.DotNetBar.ButtonX();
            this.radAnswer4 = new System.Windows.Forms.RadioButton();
            this.radAnswer3 = new System.Windows.Forms.RadioButton();
            this.radAnswer2 = new System.Windows.Forms.RadioButton();
            this.radAnswer1 = new System.Windows.Forms.RadioButton();
            this.textTopic = new DevComponents.DotNetBar.LabelX();
            this.labTopic = new DevComponents.DotNetBar.LabelX();
            this.textLevel = new DevComponents.DotNetBar.LabelX();
            this.labLevel = new DevComponents.DotNetBar.LabelX();
            this.expandablePanel1 = new DevComponents.DotNetBar.ExpandablePanel();
            this.checkedListBoxYeard = new System.Windows.Forms.CheckedListBox();
            this.groupPanelMondai = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.rad3 = new System.Windows.Forms.RadioButton();
            this.rad2 = new System.Windows.Forms.RadioButton();
            this.rad1 = new System.Windows.Forms.RadioButton();
            this.butStart = new DevComponents.DotNetBar.ButtonX();
            this.dockContainerItem1 = new DevComponents.DotNetBar.DockContainerItem();
            this.dockSite2 = new DevComponents.DotNetBar.DockSite();
            this.bar2 = new DevComponents.DotNetBar.Bar();
            this.panelDockContainer3 = new DevComponents.DotNetBar.PanelDockContainer();
            this.listBoxQuestion = new System.Windows.Forms.ListBox();
            this.dockContainerItem3 = new DevComponents.DotNetBar.DockContainerItem();
            this.dockSite8 = new DevComponents.DotNetBar.DockSite();
            this.dockSite5 = new DevComponents.DotNetBar.DockSite();
            this.dockSite6 = new DevComponents.DotNetBar.DockSite();
            this.dockSite7 = new DevComponents.DotNetBar.DockSite();
            this.dockSite3 = new DevComponents.DotNetBar.DockSite();
            this.groupPanel1 = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.labelXNoImageMess = new DevComponents.DotNetBar.LabelX();
            this.picBack = new System.Windows.Forms.PictureBox();
            this.picNext = new System.Windows.Forms.PictureBox();
            this.picQuestion = new System.Windows.Forms.PictureBox();
            this.axWMP = new AxWMPLib.AxWindowsMediaPlayer();
            this.saveFileDialogListenPractice = new System.Windows.Forms.SaveFileDialog();
            this.dockSite4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bar1)).BeginInit();
            this.bar1.SuspendLayout();
            this.panelDockContainer2.SuspendLayout();
            this.dockSite1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.barControl)).BeginInit();
            this.barControl.SuspendLayout();
            this.panelDockContainer1.SuspendLayout();
            this.groupPanelAnswer.SuspendLayout();
            this.expandablePanel1.SuspendLayout();
            this.groupPanelMondai.SuspendLayout();
            this.dockSite2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bar2)).BeginInit();
            this.bar2.SuspendLayout();
            this.panelDockContainer3.SuspendLayout();
            this.groupPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBack)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picNext)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picQuestion)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axWMP)).BeginInit();
            this.SuspendLayout();
            // 
            // dotNetBarMan
            // 
            this.dotNetBarMan.AutoDispatchShortcuts.Add(DevComponents.DotNetBar.eShortcut.F1);
            this.dotNetBarMan.AutoDispatchShortcuts.Add(DevComponents.DotNetBar.eShortcut.CtrlC);
            this.dotNetBarMan.AutoDispatchShortcuts.Add(DevComponents.DotNetBar.eShortcut.CtrlA);
            this.dotNetBarMan.AutoDispatchShortcuts.Add(DevComponents.DotNetBar.eShortcut.CtrlV);
            this.dotNetBarMan.AutoDispatchShortcuts.Add(DevComponents.DotNetBar.eShortcut.CtrlX);
            this.dotNetBarMan.AutoDispatchShortcuts.Add(DevComponents.DotNetBar.eShortcut.CtrlZ);
            this.dotNetBarMan.AutoDispatchShortcuts.Add(DevComponents.DotNetBar.eShortcut.CtrlY);
            this.dotNetBarMan.AutoDispatchShortcuts.Add(DevComponents.DotNetBar.eShortcut.Del);
            this.dotNetBarMan.AutoDispatchShortcuts.Add(DevComponents.DotNetBar.eShortcut.Ins);
            this.dotNetBarMan.BottomDockSite = this.dockSite4;
            this.dotNetBarMan.EnableFullSizeDock = false;
            this.dotNetBarMan.LeftDockSite = this.dockSite1;
            this.dotNetBarMan.ParentForm = this;
            this.dotNetBarMan.RightDockSite = this.dockSite2;
            this.dotNetBarMan.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2010;
            this.dotNetBarMan.ToolbarBottomDockSite = this.dockSite8;
            this.dotNetBarMan.ToolbarLeftDockSite = this.dockSite5;
            this.dotNetBarMan.ToolbarRightDockSite = this.dockSite6;
            this.dotNetBarMan.ToolbarTopDockSite = this.dockSite7;
            this.dotNetBarMan.TopDockSite = this.dockSite3;
            // 
            // dockSite4
            // 
            this.dockSite4.AccessibleRole = System.Windows.Forms.AccessibleRole.Window;
            this.dockSite4.Controls.Add(this.bar1);
            this.dockSite4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dockSite4.DocumentDockContainer = new DevComponents.DotNetBar.DocumentDockContainer(new DevComponents.DotNetBar.DocumentBaseContainer[] {
            ((DevComponents.DotNetBar.DocumentBaseContainer)(new DevComponents.DotNetBar.DocumentBarContainer(this.bar1, 764, 139)))}, DevComponents.DotNetBar.eOrientation.Vertical);
            this.dockSite4.Location = new System.Drawing.Point(0, 410);
            this.dockSite4.Name = "dockSite4";
            this.dockSite4.Size = new System.Drawing.Size(764, 142);
            this.dockSite4.TabIndex = 3;
            this.dockSite4.TabStop = false;
            // 
            // bar1
            // 
            this.bar1.AccessibleDescription = "DotNetBar Bar (bar1)";
            this.bar1.AccessibleName = "DotNetBar Bar";
            this.bar1.AccessibleRole = System.Windows.Forms.AccessibleRole.ToolBar;
            this.bar1.AutoSyncBarCaption = true;
            this.bar1.CloseSingleTab = true;
            this.bar1.Controls.Add(this.panelDockContainer2);
            this.bar1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bar1.GrabHandleStyle = DevComponents.DotNetBar.eGrabHandleStyle.Caption;
            this.bar1.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.dockContainerItem2});
            this.bar1.LayoutType = DevComponents.DotNetBar.eLayoutType.DockContainer;
            this.bar1.Location = new System.Drawing.Point(0, 3);
            this.bar1.Name = "bar1";
            this.bar1.Size = new System.Drawing.Size(764, 139);
            this.bar1.Stretch = true;
            this.bar1.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2010;
            this.bar1.TabIndex = 0;
            this.bar1.TabStop = false;
            this.bar1.Text = "Lời thoại";
            // 
            // panelDockContainer2
            // 
            this.panelDockContainer2.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2010;
            this.panelDockContainer2.Controls.Add(this.richTextBoxScript);
            this.panelDockContainer2.Location = new System.Drawing.Point(3, 23);
            this.panelDockContainer2.Name = "panelDockContainer2";
            this.panelDockContainer2.Size = new System.Drawing.Size(758, 113);
            this.panelDockContainer2.Style.Alignment = System.Drawing.StringAlignment.Center;
            this.panelDockContainer2.Style.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarBackground;
            this.panelDockContainer2.Style.BackColor2.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarBackground2;
            this.panelDockContainer2.Style.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarDockedBorder;
            this.panelDockContainer2.Style.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.ItemText;
            this.panelDockContainer2.Style.GradientAngle = 90;
            this.panelDockContainer2.TabIndex = 0;
            this.panelDockContainer2.Visible = true;
            // 
            // richTextBoxScript
            // 
            this.richTextBoxScript.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(177)))), ((int)(((byte)(211)))), ((int)(((byte)(255)))));
            this.richTextBoxScript.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBoxScript.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBoxScript.Location = new System.Drawing.Point(0, 0);
            this.richTextBoxScript.Name = "richTextBoxScript";
            this.richTextBoxScript.Size = new System.Drawing.Size(758, 113);
            this.richTextBoxScript.TabIndex = 0;
            this.richTextBoxScript.Text = "";
            // 
            // dockContainerItem2
            // 
            this.dockContainerItem2.Control = this.panelDockContainer2;
            this.dockContainerItem2.Name = "dockContainerItem2";
            this.dockContainerItem2.Text = "Lời thoại";
            // 
            // dockSite1
            // 
            this.dockSite1.AccessibleRole = System.Windows.Forms.AccessibleRole.Window;
            this.dockSite1.Controls.Add(this.barControl);
            this.dockSite1.Dock = System.Windows.Forms.DockStyle.Left;
            this.dockSite1.DocumentDockContainer = new DevComponents.DotNetBar.DocumentDockContainer(new DevComponents.DotNetBar.DocumentBaseContainer[] {
            ((DevComponents.DotNetBar.DocumentBaseContainer)(new DevComponents.DotNetBar.DocumentBarContainer(this.barControl, 117, 410)))}, DevComponents.DotNetBar.eOrientation.Horizontal);
            this.dockSite1.Location = new System.Drawing.Point(0, 0);
            this.dockSite1.MaximumSize = new System.Drawing.Size(120, 0);
            this.dockSite1.Name = "dockSite1";
            this.dockSite1.Size = new System.Drawing.Size(120, 410);
            this.dockSite1.TabIndex = 0;
            this.dockSite1.TabStop = false;
            // 
            // barControl
            // 
            this.barControl.AccessibleDescription = "DotNetBar Bar (barControl)";
            this.barControl.AccessibleName = "DotNetBar Bar";
            this.barControl.AccessibleRole = System.Windows.Forms.AccessibleRole.ToolBar;
            this.barControl.AutoSyncBarCaption = true;
            this.barControl.CloseSingleTab = true;
            this.barControl.Controls.Add(this.panelDockContainer1);
            this.barControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.barControl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.barControl.GrabHandleStyle = DevComponents.DotNetBar.eGrabHandleStyle.Caption;
            this.barControl.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.dockContainerItem1});
            this.barControl.LayoutType = DevComponents.DotNetBar.eLayoutType.DockContainer;
            this.barControl.Location = new System.Drawing.Point(0, 0);
            this.barControl.MaximumSize = new System.Drawing.Size(120, 0);
            this.barControl.MinimumSize = new System.Drawing.Size(120, 0);
            this.barControl.Name = "barControl";
            this.barControl.Size = new System.Drawing.Size(120, 410);
            this.barControl.Stretch = true;
            this.barControl.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2010;
            this.barControl.TabIndex = 0;
            this.barControl.TabStop = false;
            this.barControl.Text = "Bản điều khiển";
            // 
            // panelDockContainer1
            // 
            this.panelDockContainer1.AutoScroll = true;
            this.panelDockContainer1.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2010;
            this.panelDockContainer1.Controls.Add(this.textTrueAns);
            this.panelDockContainer1.Controls.Add(this.labTrueAns);
            this.panelDockContainer1.Controls.Add(this.textNumOfQue);
            this.panelDockContainer1.Controls.Add(this.labelNumOfQue);
            this.panelDockContainer1.Controls.Add(this.groupPanelAnswer);
            this.panelDockContainer1.Controls.Add(this.textTopic);
            this.panelDockContainer1.Controls.Add(this.labTopic);
            this.panelDockContainer1.Controls.Add(this.textLevel);
            this.panelDockContainer1.Controls.Add(this.labLevel);
            this.panelDockContainer1.Controls.Add(this.expandablePanel1);
            this.panelDockContainer1.Location = new System.Drawing.Point(-1, 23);
            this.panelDockContainer1.MaximumSize = new System.Drawing.Size(120, 0);
            this.panelDockContainer1.MinimumSize = new System.Drawing.Size(120, 0);
            this.panelDockContainer1.Name = "panelDockContainer1";
            this.panelDockContainer1.Size = new System.Drawing.Size(120, 384);
            this.panelDockContainer1.Style.Alignment = System.Drawing.StringAlignment.Center;
            this.panelDockContainer1.Style.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.panelDockContainer1.Style.BackColor2.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.panelDockContainer1.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.panelDockContainer1.Style.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.panelDockContainer1.Style.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.panelDockContainer1.Style.GradientAngle = 90;
            this.panelDockContainer1.TabIndex = 0;
            this.panelDockContainer1.Visible = true;
            // 
            // textTrueAns
            // 
            this.textTrueAns.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.textTrueAns.BackgroundStyle.Class = "";
            this.textTrueAns.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textTrueAns.Dock = System.Windows.Forms.DockStyle.Top;
            this.textTrueAns.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textTrueAns.ForeColor = System.Drawing.Color.Maroon;
            this.textTrueAns.Location = new System.Drawing.Point(0, 390);
            this.textTrueAns.Name = "textTrueAns";
            this.textTrueAns.Size = new System.Drawing.Size(103, 35);
            this.textTrueAns.TabIndex = 6;
            this.textTrueAns.Text = "10";
            this.textTrueAns.TextAlignment = System.Drawing.StringAlignment.Center;
            // 
            // labTrueAns
            // 
            this.labTrueAns.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labTrueAns.BackgroundStyle.Class = "";
            this.labTrueAns.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labTrueAns.Dock = System.Windows.Forms.DockStyle.Top;
            this.labTrueAns.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labTrueAns.ForeColor = System.Drawing.Color.Gray;
            this.labTrueAns.Location = new System.Drawing.Point(0, 364);
            this.labTrueAns.Name = "labTrueAns";
            this.labTrueAns.Size = new System.Drawing.Size(103, 26);
            this.labTrueAns.TabIndex = 5;
            this.labTrueAns.Text = "Trả lời đúng";
            this.labTrueAns.TextAlignment = System.Drawing.StringAlignment.Center;
            // 
            // textNumOfQue
            // 
            this.textNumOfQue.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.textNumOfQue.BackgroundStyle.Class = "";
            this.textNumOfQue.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textNumOfQue.Dock = System.Windows.Forms.DockStyle.Top;
            this.textNumOfQue.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textNumOfQue.ForeColor = System.Drawing.Color.Black;
            this.textNumOfQue.Location = new System.Drawing.Point(0, 345);
            this.textNumOfQue.Name = "textNumOfQue";
            this.textNumOfQue.Size = new System.Drawing.Size(103, 19);
            this.textNumOfQue.TabIndex = 6;
            this.textNumOfQue.Text = "10";
            this.textNumOfQue.TextAlignment = System.Drawing.StringAlignment.Center;
            // 
            // labelNumOfQue
            // 
            this.labelNumOfQue.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelNumOfQue.BackgroundStyle.Class = "";
            this.labelNumOfQue.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelNumOfQue.Dock = System.Windows.Forms.DockStyle.Top;
            this.labelNumOfQue.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNumOfQue.ForeColor = System.Drawing.Color.Gray;
            this.labelNumOfQue.Location = new System.Drawing.Point(0, 312);
            this.labelNumOfQue.Name = "labelNumOfQue";
            this.labelNumOfQue.Size = new System.Drawing.Size(103, 33);
            this.labelNumOfQue.TabIndex = 5;
            this.labelNumOfQue.Text = "Số câu hỏi";
            this.labelNumOfQue.TextAlignment = System.Drawing.StringAlignment.Center;
            // 
            // groupPanelAnswer
            // 
            this.groupPanelAnswer.BackColor = System.Drawing.Color.Transparent;
            this.groupPanelAnswer.CanvasColor = System.Drawing.SystemColors.Control;
            this.groupPanelAnswer.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.groupPanelAnswer.Controls.Add(this.checkBoxShowKey);
            this.groupPanelAnswer.Controls.Add(this.butExits);
            this.groupPanelAnswer.Controls.Add(this.butShowAnswer);
            this.groupPanelAnswer.Controls.Add(this.radAnswer4);
            this.groupPanelAnswer.Controls.Add(this.radAnswer3);
            this.groupPanelAnswer.Controls.Add(this.radAnswer2);
            this.groupPanelAnswer.Controls.Add(this.radAnswer1);
            this.groupPanelAnswer.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupPanelAnswer.Location = new System.Drawing.Point(0, 425);
            this.groupPanelAnswer.Name = "groupPanelAnswer";
            this.groupPanelAnswer.Size = new System.Drawing.Size(103, 165);
            // 
            // 
            // 
            this.groupPanelAnswer.Style.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.groupPanelAnswer.Style.BackColorGradientAngle = 90;
            this.groupPanelAnswer.Style.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.groupPanelAnswer.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanelAnswer.Style.BorderBottomWidth = 1;
            this.groupPanelAnswer.Style.BorderColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.groupPanelAnswer.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanelAnswer.Style.BorderLeftWidth = 1;
            this.groupPanelAnswer.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanelAnswer.Style.BorderRightWidth = 1;
            this.groupPanelAnswer.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanelAnswer.Style.BorderTopWidth = 1;
            this.groupPanelAnswer.Style.Class = "";
            this.groupPanelAnswer.Style.CornerDiameter = 4;
            this.groupPanelAnswer.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.groupPanelAnswer.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.groupPanelAnswer.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.groupPanelAnswer.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            // 
            // 
            // 
            this.groupPanelAnswer.StyleMouseDown.Class = "";
            this.groupPanelAnswer.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.groupPanelAnswer.StyleMouseOver.Class = "";
            this.groupPanelAnswer.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.groupPanelAnswer.TabIndex = 4;
            this.groupPanelAnswer.Text = "Câu trả lời";
            this.groupPanelAnswer.Visible = false;
            // 
            // checkBoxShowKey
            // 
            // 
            // 
            // 
            this.checkBoxShowKey.BackgroundStyle.Class = "";
            this.checkBoxShowKey.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.checkBoxShowKey.Location = new System.Drawing.Point(0, 56);
            this.checkBoxShowKey.Name = "checkBoxShowKey";
            this.checkBoxShowKey.Size = new System.Drawing.Size(114, 24);
            this.checkBoxShowKey.TabIndex = 8;
            this.checkBoxShowKey.Text = "Tự hiện đáp án";
            // 
            // butExits
            // 
            this.butExits.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.butExits.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.butExits.Location = new System.Drawing.Point(9, 115);
            this.butExits.Name = "butExits";
            this.butExits.Size = new System.Drawing.Size(97, 25);
            this.butExits.TabIndex = 7;
            this.butExits.Text = "Thoát";
            this.butExits.Click += new System.EventHandler(this.butExits_Click);
            // 
            // butShowAnswer
            // 
            this.butShowAnswer.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.butShowAnswer.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.butShowAnswer.Location = new System.Drawing.Point(8, 84);
            this.butShowAnswer.Name = "butShowAnswer";
            this.butShowAnswer.Size = new System.Drawing.Size(97, 25);
            this.butShowAnswer.TabIndex = 6;
            this.butShowAnswer.Text = "Đáp án";
            this.butShowAnswer.Click += new System.EventHandler(this.butShowAnswer_Click);
            // 
            // radAnswer4
            // 
            this.radAnswer4.AutoSize = true;
            this.radAnswer4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radAnswer4.ForeColor = System.Drawing.Color.Black;
            this.radAnswer4.Location = new System.Drawing.Point(63, 30);
            this.radAnswer4.Name = "radAnswer4";
            this.radAnswer4.Size = new System.Drawing.Size(39, 28);
            this.radAnswer4.TabIndex = 4;
            this.radAnswer4.Text = "4";
            this.radAnswer4.UseVisualStyleBackColor = true;
            this.radAnswer4.CheckedChanged += new System.EventHandler(this.radAnswer4_CheckedChanged);
            // 
            // radAnswer3
            // 
            this.radAnswer3.AutoSize = true;
            this.radAnswer3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radAnswer3.ForeColor = System.Drawing.Color.Black;
            this.radAnswer3.Location = new System.Drawing.Point(5, 30);
            this.radAnswer3.Name = "radAnswer3";
            this.radAnswer3.Size = new System.Drawing.Size(39, 28);
            this.radAnswer3.TabIndex = 5;
            this.radAnswer3.Text = "3";
            this.radAnswer3.UseVisualStyleBackColor = true;
            this.radAnswer3.CheckedChanged += new System.EventHandler(this.radAnswer3_CheckedChanged);
            // 
            // radAnswer2
            // 
            this.radAnswer2.AutoSize = true;
            this.radAnswer2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radAnswer2.ForeColor = System.Drawing.Color.Black;
            this.radAnswer2.Location = new System.Drawing.Point(63, -4);
            this.radAnswer2.Name = "radAnswer2";
            this.radAnswer2.Size = new System.Drawing.Size(39, 28);
            this.radAnswer2.TabIndex = 2;
            this.radAnswer2.Text = "2";
            this.radAnswer2.UseVisualStyleBackColor = true;
            this.radAnswer2.CheckedChanged += new System.EventHandler(this.radAnswer2_CheckedChanged);
            // 
            // radAnswer1
            // 
            this.radAnswer1.AutoSize = true;
            this.radAnswer1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radAnswer1.ForeColor = System.Drawing.Color.Black;
            this.radAnswer1.Location = new System.Drawing.Point(5, -4);
            this.radAnswer1.Name = "radAnswer1";
            this.radAnswer1.Size = new System.Drawing.Size(39, 28);
            this.radAnswer1.TabIndex = 3;
            this.radAnswer1.Text = "1";
            this.radAnswer1.UseVisualStyleBackColor = true;
            this.radAnswer1.CheckedChanged += new System.EventHandler(this.radAnswer1_CheckedChanged);
            // 
            // textTopic
            // 
            this.textTopic.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.textTopic.BackgroundStyle.Class = "";
            this.textTopic.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textTopic.Dock = System.Windows.Forms.DockStyle.Top;
            this.textTopic.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textTopic.ForeColor = System.Drawing.Color.Black;
            this.textTopic.Location = new System.Drawing.Point(0, 287);
            this.textTopic.Name = "textTopic";
            this.textTopic.Size = new System.Drawing.Size(103, 25);
            this.textTopic.TabIndex = 3;
            this.textTopic.Text = "Weather";
            this.textTopic.TextAlignment = System.Drawing.StringAlignment.Center;
            // 
            // labTopic
            // 
            this.labTopic.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labTopic.BackgroundStyle.Class = "";
            this.labTopic.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labTopic.Dock = System.Windows.Forms.DockStyle.Top;
            this.labTopic.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labTopic.ForeColor = System.Drawing.Color.Gray;
            this.labTopic.Location = new System.Drawing.Point(0, 261);
            this.labTopic.Name = "labTopic";
            this.labTopic.Size = new System.Drawing.Size(103, 26);
            this.labTopic.TabIndex = 2;
            this.labTopic.Text = "Chủ đề";
            this.labTopic.TextAlignment = System.Drawing.StringAlignment.Center;
            // 
            // textLevel
            // 
            this.textLevel.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.textLevel.BackgroundStyle.Class = "";
            this.textLevel.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textLevel.Dock = System.Windows.Forms.DockStyle.Top;
            this.textLevel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textLevel.ForeColor = System.Drawing.Color.Black;
            this.textLevel.Location = new System.Drawing.Point(0, 243);
            this.textLevel.Name = "textLevel";
            this.textLevel.Size = new System.Drawing.Size(103, 18);
            this.textLevel.TabIndex = 1;
            this.textLevel.Text = "N1";
            this.textLevel.TextAlignment = System.Drawing.StringAlignment.Center;
            // 
            // labLevel
            // 
            this.labLevel.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labLevel.BackgroundStyle.Class = "";
            this.labLevel.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labLevel.Dock = System.Windows.Forms.DockStyle.Top;
            this.labLevel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labLevel.ForeColor = System.Drawing.Color.Gray;
            this.labLevel.Location = new System.Drawing.Point(0, 219);
            this.labLevel.Name = "labLevel";
            this.labLevel.Size = new System.Drawing.Size(103, 24);
            this.labLevel.TabIndex = 0;
            this.labLevel.Text = "Cấp độ";
            this.labLevel.TextAlignment = System.Drawing.StringAlignment.Center;
            // 
            // expandablePanel1
            // 
            this.expandablePanel1.CanvasColor = System.Drawing.SystemColors.Control;
            this.expandablePanel1.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.expandablePanel1.Controls.Add(this.checkedListBoxYeard);
            this.expandablePanel1.Controls.Add(this.groupPanelMondai);
            this.expandablePanel1.Controls.Add(this.butStart);
            this.expandablePanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.expandablePanel1.Location = new System.Drawing.Point(0, 0);
            this.expandablePanel1.Name = "expandablePanel1";
            this.expandablePanel1.Size = new System.Drawing.Size(103, 219);
            this.expandablePanel1.Style.Alignment = System.Drawing.StringAlignment.Center;
            this.expandablePanel1.Style.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.expandablePanel1.Style.BackColor2.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.expandablePanel1.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.expandablePanel1.Style.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.expandablePanel1.Style.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.expandablePanel1.Style.GradientAngle = 90;
            this.expandablePanel1.TabIndex = 7;
            this.expandablePanel1.TitleStyle.Alignment = System.Drawing.StringAlignment.Center;
            this.expandablePanel1.TitleStyle.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.expandablePanel1.TitleStyle.BackColor2.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.expandablePanel1.TitleStyle.Border = DevComponents.DotNetBar.eBorderType.RaisedInner;
            this.expandablePanel1.TitleStyle.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.expandablePanel1.TitleStyle.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.expandablePanel1.TitleStyle.GradientAngle = 90;
            this.expandablePanel1.TitleText = "Catalô";
            this.expandablePanel1.ExpandedChanged += new DevComponents.DotNetBar.ExpandChangeEventHandler(this.expandablePanel1_ExpandedChanged);
            // 
            // checkedListBoxYeard
            // 
            this.checkedListBoxYeard.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(177)))), ((int)(((byte)(211)))), ((int)(((byte)(255)))));
            this.checkedListBoxYeard.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.checkedListBoxYeard.CheckOnClick = true;
            this.checkedListBoxYeard.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkedListBoxYeard.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkedListBoxYeard.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.checkedListBoxYeard.FormattingEnabled = true;
            this.checkedListBoxYeard.Location = new System.Drawing.Point(0, 26);
            this.checkedListBoxYeard.Name = "checkedListBoxYeard";
            this.checkedListBoxYeard.Size = new System.Drawing.Size(103, 110);
            this.checkedListBoxYeard.Sorted = true;
            this.checkedListBoxYeard.TabIndex = 6;
            this.checkedListBoxYeard.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.checkedListBoxYeard_ItemCheck);
            // 
            // groupPanelMondai
            // 
            this.groupPanelMondai.CanvasColor = System.Drawing.SystemColors.Control;
            this.groupPanelMondai.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.groupPanelMondai.Controls.Add(this.rad3);
            this.groupPanelMondai.Controls.Add(this.rad2);
            this.groupPanelMondai.Controls.Add(this.rad1);
            this.groupPanelMondai.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupPanelMondai.Location = new System.Drawing.Point(0, 136);
            this.groupPanelMondai.Name = "groupPanelMondai";
            this.groupPanelMondai.Size = new System.Drawing.Size(103, 49);
            // 
            // 
            // 
            this.groupPanelMondai.Style.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.groupPanelMondai.Style.BackColorGradientAngle = 90;
            this.groupPanelMondai.Style.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.groupPanelMondai.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanelMondai.Style.BorderBottomWidth = 1;
            this.groupPanelMondai.Style.BorderColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.groupPanelMondai.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanelMondai.Style.BorderLeftWidth = 1;
            this.groupPanelMondai.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanelMondai.Style.BorderRightWidth = 1;
            this.groupPanelMondai.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanelMondai.Style.BorderTopWidth = 1;
            this.groupPanelMondai.Style.Class = "";
            this.groupPanelMondai.Style.CornerDiameter = 4;
            this.groupPanelMondai.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.groupPanelMondai.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.groupPanelMondai.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.groupPanelMondai.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            // 
            // 
            // 
            this.groupPanelMondai.StyleMouseDown.Class = "";
            this.groupPanelMondai.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.groupPanelMondai.StyleMouseOver.Class = "";
            this.groupPanelMondai.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.groupPanelMondai.TabIndex = 2;
            this.groupPanelMondai.Text = "Loại câu hỏi";
            // 
            // rad3
            // 
            this.rad3.AutoSize = true;
            this.rad3.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rad3.Location = new System.Drawing.Point(74, 6);
            this.rad3.Name = "rad3";
            this.rad3.Size = new System.Drawing.Size(33, 21);
            this.rad3.TabIndex = 9;
            this.rad3.Text = "3";
            this.rad3.UseVisualStyleBackColor = true;
            // 
            // rad2
            // 
            this.rad2.AutoSize = true;
            this.rad2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rad2.Location = new System.Drawing.Point(40, 6);
            this.rad2.Name = "rad2";
            this.rad2.Size = new System.Drawing.Size(33, 21);
            this.rad2.TabIndex = 10;
            this.rad2.Text = "2";
            this.rad2.UseVisualStyleBackColor = true;
            // 
            // rad1
            // 
            this.rad1.AutoSize = true;
            this.rad1.Checked = true;
            this.rad1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rad1.Location = new System.Drawing.Point(8, 6);
            this.rad1.Name = "rad1";
            this.rad1.Size = new System.Drawing.Size(33, 21);
            this.rad1.TabIndex = 8;
            this.rad1.TabStop = true;
            this.rad1.Text = "1";
            this.rad1.UseVisualStyleBackColor = true;
            // 
            // butStart
            // 
            this.butStart.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.butStart.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.butStart.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.butStart.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butStart.Location = new System.Drawing.Point(0, 185);
            this.butStart.Name = "butStart";
            this.butStart.Size = new System.Drawing.Size(103, 34);
            this.butStart.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2010;
            this.butStart.TabIndex = 11;
            this.butStart.Text = "Bắt đầu";
            this.butStart.Click += new System.EventHandler(this.butStart_Click);
            // 
            // dockContainerItem1
            // 
            this.dockContainerItem1.Control = this.panelDockContainer1;
            this.dockContainerItem1.Name = "dockContainerItem1";
            this.dockContainerItem1.Text = "Bản điều khiển";
            // 
            // dockSite2
            // 
            this.dockSite2.AccessibleRole = System.Windows.Forms.AccessibleRole.Window;
            this.dockSite2.Controls.Add(this.bar2);
            this.dockSite2.Dock = System.Windows.Forms.DockStyle.Right;
            this.dockSite2.DocumentDockContainer = new DevComponents.DotNetBar.DocumentDockContainer(new DevComponents.DotNetBar.DocumentBaseContainer[] {
            ((DevComponents.DotNetBar.DocumentBaseContainer)(new DevComponents.DotNetBar.DocumentBarContainer(this.bar2, 87, 410)))}, DevComponents.DotNetBar.eOrientation.Horizontal);
            this.dockSite2.Location = new System.Drawing.Point(674, 0);
            this.dockSite2.MaximumSize = new System.Drawing.Size(90, 0);
            this.dockSite2.Name = "dockSite2";
            this.dockSite2.Size = new System.Drawing.Size(90, 410);
            this.dockSite2.TabIndex = 1;
            this.dockSite2.TabStop = false;
            // 
            // bar2
            // 
            this.bar2.AccessibleDescription = "DotNetBar Bar (bar2)";
            this.bar2.AccessibleName = "DotNetBar Bar";
            this.bar2.AccessibleRole = System.Windows.Forms.AccessibleRole.ToolBar;
            this.bar2.AutoSyncBarCaption = true;
            this.bar2.CloseSingleTab = true;
            this.bar2.Controls.Add(this.panelDockContainer3);
            this.bar2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bar2.GrabHandleStyle = DevComponents.DotNetBar.eGrabHandleStyle.Caption;
            this.bar2.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.dockContainerItem3});
            this.bar2.LayoutType = DevComponents.DotNetBar.eLayoutType.DockContainer;
            this.bar2.Location = new System.Drawing.Point(3, 0);
            this.bar2.Name = "bar2";
            this.bar2.Size = new System.Drawing.Size(87, 410);
            this.bar2.Stretch = true;
            this.bar2.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2010;
            this.bar2.TabIndex = 0;
            this.bar2.TabStop = false;
            this.bar2.Text = "Câu hỏi";
            // 
            // panelDockContainer3
            // 
            this.panelDockContainer3.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2010;
            this.panelDockContainer3.Controls.Add(this.listBoxQuestion);
            this.panelDockContainer3.Location = new System.Drawing.Point(3, 23);
            this.panelDockContainer3.Name = "panelDockContainer3";
            this.panelDockContainer3.Size = new System.Drawing.Size(81, 384);
            this.panelDockContainer3.Style.Alignment = System.Drawing.StringAlignment.Center;
            this.panelDockContainer3.Style.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarBackground;
            this.panelDockContainer3.Style.BackColor2.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarBackground2;
            this.panelDockContainer3.Style.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarDockedBorder;
            this.panelDockContainer3.Style.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.ItemText;
            this.panelDockContainer3.Style.GradientAngle = 90;
            this.panelDockContainer3.TabIndex = 0;
            this.panelDockContainer3.Visible = true;
            // 
            // listBoxQuestion
            // 
            this.listBoxQuestion.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(177)))), ((int)(((byte)(211)))), ((int)(((byte)(255)))));
            this.listBoxQuestion.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listBoxQuestion.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listBoxQuestion.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBoxQuestion.FormattingEnabled = true;
            this.listBoxQuestion.ItemHeight = 15;
            this.listBoxQuestion.Location = new System.Drawing.Point(0, 0);
            this.listBoxQuestion.Name = "listBoxQuestion";
            this.listBoxQuestion.Size = new System.Drawing.Size(81, 384);
            this.listBoxQuestion.TabIndex = 0;
            this.listBoxQuestion.SelectedIndexChanged += new System.EventHandler(this.listBoxQuestion_SelectedIndexChanged);
            // 
            // dockContainerItem3
            // 
            this.dockContainerItem3.Control = this.panelDockContainer3;
            this.dockContainerItem3.Name = "dockContainerItem3";
            this.dockContainerItem3.Text = "Câu hỏi";
            // 
            // dockSite8
            // 
            this.dockSite8.AccessibleRole = System.Windows.Forms.AccessibleRole.Window;
            this.dockSite8.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dockSite8.Location = new System.Drawing.Point(0, 552);
            this.dockSite8.Name = "dockSite8";
            this.dockSite8.Size = new System.Drawing.Size(764, 0);
            this.dockSite8.TabIndex = 7;
            this.dockSite8.TabStop = false;
            // 
            // dockSite5
            // 
            this.dockSite5.AccessibleRole = System.Windows.Forms.AccessibleRole.Window;
            this.dockSite5.Dock = System.Windows.Forms.DockStyle.Left;
            this.dockSite5.Location = new System.Drawing.Point(0, 0);
            this.dockSite5.Name = "dockSite5";
            this.dockSite5.Size = new System.Drawing.Size(0, 552);
            this.dockSite5.TabIndex = 4;
            this.dockSite5.TabStop = false;
            // 
            // dockSite6
            // 
            this.dockSite6.AccessibleRole = System.Windows.Forms.AccessibleRole.Window;
            this.dockSite6.Dock = System.Windows.Forms.DockStyle.Right;
            this.dockSite6.Location = new System.Drawing.Point(764, 0);
            this.dockSite6.Name = "dockSite6";
            this.dockSite6.Size = new System.Drawing.Size(0, 552);
            this.dockSite6.TabIndex = 5;
            this.dockSite6.TabStop = false;
            // 
            // dockSite7
            // 
            this.dockSite7.AccessibleRole = System.Windows.Forms.AccessibleRole.Window;
            this.dockSite7.Dock = System.Windows.Forms.DockStyle.Top;
            this.dockSite7.Location = new System.Drawing.Point(0, 0);
            this.dockSite7.Name = "dockSite7";
            this.dockSite7.Size = new System.Drawing.Size(764, 0);
            this.dockSite7.TabIndex = 6;
            this.dockSite7.TabStop = false;
            // 
            // dockSite3
            // 
            this.dockSite3.AccessibleRole = System.Windows.Forms.AccessibleRole.Window;
            this.dockSite3.Dock = System.Windows.Forms.DockStyle.Top;
            this.dockSite3.DocumentDockContainer = new DevComponents.DotNetBar.DocumentDockContainer();
            this.dockSite3.Location = new System.Drawing.Point(0, 0);
            this.dockSite3.Name = "dockSite3";
            this.dockSite3.Size = new System.Drawing.Size(764, 0);
            this.dockSite3.TabIndex = 2;
            this.dockSite3.TabStop = false;
            // 
            // groupPanel1
            // 
            this.groupPanel1.CanvasColor = System.Drawing.SystemColors.Control;
            this.groupPanel1.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.groupPanel1.Controls.Add(this.labelXNoImageMess);
            this.groupPanel1.Controls.Add(this.picBack);
            this.groupPanel1.Controls.Add(this.picNext);
            this.groupPanel1.Controls.Add(this.picQuestion);
            this.groupPanel1.Controls.Add(this.axWMP);
            this.groupPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupPanel1.Location = new System.Drawing.Point(120, 0);
            this.groupPanel1.Name = "groupPanel1";
            this.groupPanel1.Size = new System.Drawing.Size(554, 410);
            // 
            // 
            // 
            this.groupPanel1.Style.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.groupPanel1.Style.BackColorGradientAngle = 90;
            this.groupPanel1.Style.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.groupPanel1.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel1.Style.BorderBottomWidth = 1;
            this.groupPanel1.Style.BorderColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.groupPanel1.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel1.Style.BorderLeftWidth = 1;
            this.groupPanel1.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel1.Style.BorderRightWidth = 1;
            this.groupPanel1.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel1.Style.BorderTopWidth = 1;
            this.groupPanel1.Style.Class = "";
            this.groupPanel1.Style.CornerDiameter = 4;
            this.groupPanel1.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.groupPanel1.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.groupPanel1.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.groupPanel1.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            // 
            // 
            // 
            this.groupPanel1.StyleMouseDown.Class = "";
            this.groupPanel1.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.groupPanel1.StyleMouseOver.Class = "";
            this.groupPanel1.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.groupPanel1.TabIndex = 8;
            this.groupPanel1.SizeChanged += new System.EventHandler(this.groupPanel1_SizeChanged);
            // 
            // labelXNoImageMess
            // 
            this.labelXNoImageMess.BackColor = System.Drawing.Color.Transparent;
            this.labelXNoImageMess.BackgroundImage = global::JTest.Properties.Resources.BK;
            // 
            // 
            // 
            this.labelXNoImageMess.BackgroundStyle.Class = "";
            this.labelXNoImageMess.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelXNoImageMess.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelXNoImageMess.Location = new System.Drawing.Point(3, 228);
            this.labelXNoImageMess.Name = "labelXNoImageMess";
            this.labelXNoImageMess.Size = new System.Drawing.Size(542, 52);
            this.labelXNoImageMess.TabIndex = 4;
            this.labelXNoImageMess.Text = "Câu hỏi không có tranh...";
            this.labelXNoImageMess.TextAlignment = System.Drawing.StringAlignment.Center;
            this.labelXNoImageMess.Visible = false;
            // 
            // picBack
            // 
            this.picBack.Image = global::JTest.Properties.Resources.back;
            this.picBack.Location = new System.Drawing.Point(59, 375);
            this.picBack.Name = "picBack";
            this.picBack.Size = new System.Drawing.Size(20, 23);
            this.picBack.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picBack.TabIndex = 3;
            this.picBack.TabStop = false;
            this.picBack.Click += new System.EventHandler(this.picBack_Click);
            this.picBack.MouseLeave += new System.EventHandler(this.picBack_MouseLeave);
            this.picBack.MouseHover += new System.EventHandler(this.picBack_MouseHover);
            // 
            // picNext
            // 
            this.picNext.Image = global::JTest.Properties.Resources.Next;
            this.picNext.Location = new System.Drawing.Point(86, 377);
            this.picNext.Name = "picNext";
            this.picNext.Size = new System.Drawing.Size(19, 22);
            this.picNext.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picNext.TabIndex = 2;
            this.picNext.TabStop = false;
            this.picNext.Click += new System.EventHandler(this.picNext_Click);
            this.picNext.MouseLeave += new System.EventHandler(this.picNext_MouseLeave);
            this.picNext.MouseHover += new System.EventHandler(this.picNext_MouseHover);
            // 
            // picQuestion
            // 
            this.picQuestion.BackgroundImage = global::JTest.Properties.Resources.ListenBK;
            this.picQuestion.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picQuestion.Dock = System.Windows.Forms.DockStyle.Fill;
            this.picQuestion.Location = new System.Drawing.Point(0, 0);
            this.picQuestion.Name = "picQuestion";
            this.picQuestion.Size = new System.Drawing.Size(548, 359);
            this.picQuestion.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picQuestion.TabIndex = 1;
            this.picQuestion.TabStop = false;
            // 
            // axWMP
            // 
            this.axWMP.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.axWMP.Enabled = true;
            this.axWMP.Location = new System.Drawing.Point(0, 359);
            this.axWMP.Name = "axWMP";
            this.axWMP.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axWMP.OcxState")));
            this.axWMP.Size = new System.Drawing.Size(548, 45);
            this.axWMP.TabIndex = 0;
            // 
            // frmListenPractice
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(764, 552);
            this.Controls.Add(this.groupPanel1);
            this.Controls.Add(this.dockSite2);
            this.Controls.Add(this.dockSite1);
            this.Controls.Add(this.dockSite3);
            this.Controls.Add(this.dockSite4);
            this.Controls.Add(this.dockSite5);
            this.Controls.Add(this.dockSite6);
            this.Controls.Add(this.dockSite7);
            this.Controls.Add(this.dockSite8);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(780, 590);
            this.Name = "frmListenPractice";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Listen - Practice";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmListenPractice_FormClosing);
            this.Load += new System.EventHandler(this.frmListenPractice_Load);
            this.dockSite4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.bar1)).EndInit();
            this.bar1.ResumeLayout(false);
            this.panelDockContainer2.ResumeLayout(false);
            this.dockSite1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.barControl)).EndInit();
            this.barControl.ResumeLayout(false);
            this.panelDockContainer1.ResumeLayout(false);
            this.groupPanelAnswer.ResumeLayout(false);
            this.groupPanelAnswer.PerformLayout();
            this.expandablePanel1.ResumeLayout(false);
            this.groupPanelMondai.ResumeLayout(false);
            this.groupPanelMondai.PerformLayout();
            this.dockSite2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.bar2)).EndInit();
            this.bar2.ResumeLayout(false);
            this.panelDockContainer3.ResumeLayout(false);
            this.groupPanel1.ResumeLayout(false);
            this.groupPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBack)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picNext)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picQuestion)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axWMP)).EndInit();
            this.ResumeLayout(false);

        }


        #endregion

        private DevComponents.DotNetBar.DotNetBarManager dotNetBarMan;
        private DevComponents.DotNetBar.DockSite dockSite4;
        private DevComponents.DotNetBar.DockSite dockSite1;
        private DevComponents.DotNetBar.DockSite dockSite2;
        private DevComponents.DotNetBar.DockSite dockSite3;
        private DevComponents.DotNetBar.DockSite dockSite5;
        private DevComponents.DotNetBar.DockSite dockSite6;
        private DevComponents.DotNetBar.DockSite dockSite7;
        private DevComponents.DotNetBar.DockSite dockSite8;
        private DevComponents.DotNetBar.Bar bar1;
        private DevComponents.DotNetBar.PanelDockContainer panelDockContainer2;
        private DevComponents.DotNetBar.DockContainerItem dockContainerItem2;
        private DevComponents.DotNetBar.Bar barControl;
        private DevComponents.DotNetBar.PanelDockContainer panelDockContainer1;
        private DevComponents.DotNetBar.DockContainerItem dockContainerItem1;
        private DevComponents.DotNetBar.Controls.GroupPanel groupPanel1;
        private System.Windows.Forms.RichTextBox richTextBoxScript;
        private DevComponents.DotNetBar.Bar bar2;
        private DevComponents.DotNetBar.PanelDockContainer panelDockContainer3;
        private DevComponents.DotNetBar.DockContainerItem dockContainerItem3;
        private AxWMPLib.AxWindowsMediaPlayer axWMP;
        private DevComponents.DotNetBar.Controls.GroupPanel groupPanelAnswer;
        private DevComponents.DotNetBar.LabelX textTopic;
        private DevComponents.DotNetBar.LabelX labTopic;
        private DevComponents.DotNetBar.LabelX textLevel;
        private DevComponents.DotNetBar.LabelX labLevel;
        private System.Windows.Forms.PictureBox picQuestion;
        private System.Windows.Forms.ListBox listBoxQuestion;
        private System.Windows.Forms.RadioButton radAnswer4;
        private System.Windows.Forms.RadioButton radAnswer3;
        private System.Windows.Forms.RadioButton radAnswer2;
        private System.Windows.Forms.RadioButton radAnswer1;
        private DevComponents.DotNetBar.ButtonX butShowAnswer;
        private DevComponents.DotNetBar.ButtonX butExits;
        private DevComponents.DotNetBar.LabelX textTrueAns;
        private DevComponents.DotNetBar.LabelX labTrueAns;
        private DevComponents.DotNetBar.Controls.CheckBoxX checkBoxShowKey;
        private SaveFileDialog saveFileDialogListenPractice;
        private PictureBox picNext;
        private PictureBox picBack;
        private DevComponents.DotNetBar.LabelX textNumOfQue;
        private DevComponents.DotNetBar.LabelX labelNumOfQue;
        private DevComponents.DotNetBar.LabelX labelXNoImageMess;
        private DevComponents.DotNetBar.ExpandablePanel expandablePanel1;
        private CheckedListBox checkedListBoxYeard;
        private DevComponents.DotNetBar.Controls.GroupPanel groupPanelMondai;
        private RadioButton rad3;
        private RadioButton rad2;
        private RadioButton rad1;
        private DevComponents.DotNetBar.ButtonX butStart;
    }
}
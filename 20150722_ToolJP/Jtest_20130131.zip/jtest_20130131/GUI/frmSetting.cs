using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using JTest.BUS;
using System.Xml;

namespace JTest.GUI
{
    public partial class frmSetting : Form
    {
        static SettingsDTO s;

        public frmSetting()
        {
            InitializeComponent();
            s = SettingsBUS.loadSettingInfoFromFile();
            nudSoCau.Value = s.NumberOfQuestion;
            dtpThoiGian.Value = new DateTime(2000,1,1,s.Hour,s.Minute,s.Second);
            // @LuongGV
            cmbDbase.DataSource = SettingsBUS.loadDbaseSources();
            cmbDbase.SelectedItem = s.Database;

            //@nhannc
            controlLang();

            //
        }

        private void nudSoCau_Enter(object sender, EventArgs e)
        {
            nudSoCau.Select(0, nudSoCau.Value.ToString().Length);
        }

        private void btCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btOK_Click(object sender, EventArgs e)
        {
            //lay info tu form
            s.NumberOfQuestion = Int32.Parse(nudSoCau.Value.ToString());
            s.Hour = dtpThoiGian.Value.Hour;
            s.Minute = dtpThoiGian.Value.Minute;
            s.Second = dtpThoiGian.Value.Second;
            s.Database = cmbDbase.SelectedItem.ToString();// @LuongGV
            //end lay info
            
            //save setting ra file
            SettingsBUS.saveSettingInfoToFile(s);
            //end save setting ra file

            //send thong tin setting qua main form
            //end send thong tin setting qua main form
            //
            //@nhannc
            //            


            //close form
            this.Close();
        }


        /// <summary>
        /// Ham bat su kien value cua nudSoCau thay doi
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void nudSoCau_ValueChanged(object sender, EventArgs e)
        {
            if (nudSoCau.Value < 1)
            {
                nudSoCau.Value = 1;
            }
        }


        //nhannc load language cho  cmbLang
        private void controlLang()
        {
            //MessageBox.Show("controlLang");
            //MultiLang mul = new MultiLang();
            try
            {
                //XmlDocument xml = mul.loadLangData(src);
                XmlNodeList xnList = frmMain.xml.SelectNodes("lang/tuychon");
                foreach (XmlNode xn in xnList)
                {
                    this.Text = xn["title"].InnerText;
                    groupBox1.Text = xn["cauhinh"].InnerText;
                    label1.Text = xn["socau"].InnerText;
                    label2.Text = xn["thoigian"].InnerText;
                    label3.Text = xn["cosodulieu"].InnerText;
                }
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message);
            }
        }

        

    }
}
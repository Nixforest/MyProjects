﻿namespace JTest.GUI
{
    partial class frmListenSetting
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmListenSetting));
            this.tabCtr = new DevComponents.DotNetBar.TabControl();
            this.tabControlPanel1 = new DevComponents.DotNetBar.TabControlPanel();
            this.dataGridViewX1 = new DevComponents.DotNetBar.Controls.DataGridViewX();
            this.Checker = new ComponentFactory.Krypton.Toolkit.KryptonDataGridViewCheckBoxColumn();
            this.Topic = new ComponentFactory.Krypton.Toolkit.KryptonDataGridViewTextBoxColumn();
            this.NumOfQue = new ComponentFactory.Krypton.Toolkit.KryptonDataGridViewTextBoxColumn();
            this.cmbWithoutImage = new DevComponents.DotNetBar.Controls.ComboBoxEx();
            this.cmbWithImage = new DevComponents.DotNetBar.Controls.ComboBoxEx();
            this.cmbNumOfQue = new DevComponents.DotNetBar.Controls.ComboBoxEx();
            this.labelWithoutImage = new DevComponents.DotNetBar.LabelX();
            this.labelWithImage = new DevComponents.DotNetBar.LabelX();
            this.labNumOfQue = new DevComponents.DotNetBar.LabelX();
            this.cmbLevel = new DevComponents.DotNetBar.Controls.ComboBoxEx();
            this.labelSumOfWithoutImage = new DevComponents.DotNetBar.LabelX();
            this.labelSumOfWithImage = new DevComponents.DotNetBar.LabelX();
            this.labelSumOfQue = new DevComponents.DotNetBar.LabelX();
            this.allQuestion1 = new DevComponents.DotNetBar.LabelX();
            this.labelTopic = new DevComponents.DotNetBar.LabelX();
            this.labLevel = new DevComponents.DotNetBar.LabelX();
            this.butStart = new DevComponents.DotNetBar.ButtonX();
            this.tabTest = new DevComponents.DotNetBar.TabItem(this.components);
            this.tabControlPanel2 = new DevComponents.DotNetBar.TabControlPanel();
            this.cmbPraTopic = new DevComponents.DotNetBar.Controls.ComboBoxEx();
            this.cmbPraLevel = new DevComponents.DotNetBar.Controls.ComboBoxEx();
            this.labPraTopic = new DevComponents.DotNetBar.LabelX();
            this.labPraLevel = new DevComponents.DotNetBar.LabelX();
            this.butPractice = new DevComponents.DotNetBar.ButtonX();
            this.tabPractice = new DevComponents.DotNetBar.TabItem(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.tabCtr)).BeginInit();
            this.tabCtr.SuspendLayout();
            this.tabControlPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewX1)).BeginInit();
            this.tabControlPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabCtr
            // 
            this.tabCtr.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.tabCtr.CanReorderTabs = true;
            this.tabCtr.Controls.Add(this.tabControlPanel1);
            this.tabCtr.Controls.Add(this.tabControlPanel2);
            this.tabCtr.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabCtr.Location = new System.Drawing.Point(0, 0);
            this.tabCtr.Name = "tabCtr";
            this.tabCtr.SelectedTabFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.tabCtr.SelectedTabIndex = 0;
            this.tabCtr.Size = new System.Drawing.Size(309, 436);
            this.tabCtr.TabIndex = 0;
            this.tabCtr.TabLayoutType = DevComponents.DotNetBar.eTabLayoutType.FixedWithNavigationBox;
            this.tabCtr.Tabs.Add(this.tabTest);
            this.tabCtr.Tabs.Add(this.tabPractice);
            this.tabCtr.Text = "tabControl1";
            // 
            // tabControlPanel1
            // 
            this.tabControlPanel1.Controls.Add(this.dataGridViewX1);
            this.tabControlPanel1.Controls.Add(this.cmbWithoutImage);
            this.tabControlPanel1.Controls.Add(this.cmbWithImage);
            this.tabControlPanel1.Controls.Add(this.cmbNumOfQue);
            this.tabControlPanel1.Controls.Add(this.labelWithoutImage);
            this.tabControlPanel1.Controls.Add(this.labelWithImage);
            this.tabControlPanel1.Controls.Add(this.labNumOfQue);
            this.tabControlPanel1.Controls.Add(this.cmbLevel);
            this.tabControlPanel1.Controls.Add(this.labelSumOfWithoutImage);
            this.tabControlPanel1.Controls.Add(this.labelSumOfWithImage);
            this.tabControlPanel1.Controls.Add(this.labelSumOfQue);
            this.tabControlPanel1.Controls.Add(this.allQuestion1);
            this.tabControlPanel1.Controls.Add(this.labelTopic);
            this.tabControlPanel1.Controls.Add(this.labLevel);
            this.tabControlPanel1.Controls.Add(this.butStart);
            this.tabControlPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlPanel1.Location = new System.Drawing.Point(0, 26);
            this.tabControlPanel1.Name = "tabControlPanel1";
            this.tabControlPanel1.Padding = new System.Windows.Forms.Padding(1);
            this.tabControlPanel1.Size = new System.Drawing.Size(309, 410);
            this.tabControlPanel1.Style.BackColor1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(179)))), ((int)(((byte)(231)))));
            this.tabControlPanel1.Style.BackColor2.Color = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(237)))), ((int)(((byte)(254)))));
            this.tabControlPanel1.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.tabControlPanel1.Style.BorderColor.Color = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(97)))), ((int)(((byte)(156)))));
            this.tabControlPanel1.Style.BorderSide = ((DevComponents.DotNetBar.eBorderSide)(((DevComponents.DotNetBar.eBorderSide.Left | DevComponents.DotNetBar.eBorderSide.Right)
                        | DevComponents.DotNetBar.eBorderSide.Bottom)));
            this.tabControlPanel1.Style.GradientAngle = 90;
            this.tabControlPanel1.TabIndex = 1;
            this.tabControlPanel1.TabItem = this.tabTest;
            // 
            // dataGridViewX1
            // 
            this.dataGridViewX1.AllowUserToAddRows = false;
            this.dataGridViewX1.AllowUserToDeleteRows = false;
            this.dataGridViewX1.AllowUserToOrderColumns = true;
            this.dataGridViewX1.AllowUserToResizeRows = false;
            this.dataGridViewX1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewX1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(177)))), ((int)(((byte)(211)))), ((int)(((byte)(255)))));
            this.dataGridViewX1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Checker,
            this.Topic,
            this.NumOfQue});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewX1.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewX1.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(215)))), ((int)(((byte)(229)))));
            this.dataGridViewX1.Location = new System.Drawing.Point(30, 76);
            this.dataGridViewX1.Name = "dataGridViewX1";
            this.dataGridViewX1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dataGridViewX1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dataGridViewX1.Size = new System.Drawing.Size(241, 138);
            this.dataGridViewX1.TabIndex = 3;
            this.dataGridViewX1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewX1_CellContentClick);
            this.dataGridViewX1.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewX1_CellContentDoubleClick);
            // 
            // Checker
            // 
            this.Checker.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.NullValue = false;
            this.Checker.DefaultCellStyle = dataGridViewCellStyle1;
            this.Checker.FalseValue = null;
            this.Checker.Frozen = true;
            this.Checker.HeaderText = "";
            this.Checker.IndeterminateValue = null;
            this.Checker.Name = "Checker";
            this.Checker.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Checker.TrueValue = null;
            this.Checker.Width = 20;
            // 
            // Topic
            // 
            this.Topic.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.Topic.Frozen = true;
            this.Topic.HeaderText = "Chủ đề";
            this.Topic.Name = "Topic";
            this.Topic.ReadOnly = true;
            this.Topic.Width = 100;
            // 
            // NumOfQue
            // 
            this.NumOfQue.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.NumOfQue.HeaderText = "Số câu";
            this.NumOfQue.Name = "NumOfQue";
            this.NumOfQue.ReadOnly = true;
            this.NumOfQue.Width = 78;
            // 
            // cmbWithoutImage
            // 
            this.cmbWithoutImage.DisplayMember = "Text";
            this.cmbWithoutImage.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbWithoutImage.Enabled = false;
            this.cmbWithoutImage.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.cmbWithoutImage.FormattingEnabled = true;
            this.cmbWithoutImage.ItemHeight = 23;
            this.cmbWithoutImage.Location = new System.Drawing.Point(160, 291);
            this.cmbWithoutImage.Name = "cmbWithoutImage";
            this.cmbWithoutImage.Size = new System.Drawing.Size(54, 29);
            this.cmbWithoutImage.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2010;
            this.cmbWithoutImage.TabIndex = 2;
            this.cmbWithoutImage.SelectedIndexChanged += new System.EventHandler(this.cmbWithoutImage_SelectedIndexChanged);
            this.cmbWithoutImage.TextChanged += new System.EventHandler(this.cmbWithoutImage_TextChanged);
            this.cmbWithoutImage.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbWithoutImage_KeyPress);
            // 
            // cmbWithImage
            // 
            this.cmbWithImage.DisplayMember = "Text";
            this.cmbWithImage.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbWithImage.Enabled = false;
            this.cmbWithImage.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.cmbWithImage.FormattingEnabled = true;
            this.cmbWithImage.ItemHeight = 23;
            this.cmbWithImage.Location = new System.Drawing.Point(160, 255);
            this.cmbWithImage.Name = "cmbWithImage";
            this.cmbWithImage.Size = new System.Drawing.Size(54, 29);
            this.cmbWithImage.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2010;
            this.cmbWithImage.TabIndex = 2;
            this.cmbWithImage.TextChanged += new System.EventHandler(this.cmbWithImage_TextChanged);
            this.cmbWithImage.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbWithImage_KeyPress);
            // 
            // cmbNumOfQue
            // 
            this.cmbNumOfQue.DisplayMember = "Text";
            this.cmbNumOfQue.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbNumOfQue.Enabled = false;
            this.cmbNumOfQue.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.cmbNumOfQue.FormattingEnabled = true;
            this.cmbNumOfQue.ItemHeight = 23;
            this.cmbNumOfQue.Location = new System.Drawing.Point(160, 219);
            this.cmbNumOfQue.Name = "cmbNumOfQue";
            this.cmbNumOfQue.Size = new System.Drawing.Size(54, 29);
            this.cmbNumOfQue.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2010;
            this.cmbNumOfQue.TabIndex = 2;
            this.cmbNumOfQue.TextChanged += new System.EventHandler(this.cmbNumOfQue_TextChanged);
            this.cmbNumOfQue.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbNumOfQue_KeyPress);
            // 
            // labelWithoutImage
            // 
            this.labelWithoutImage.BackColor = System.Drawing.Color.Transparent;
            this.labelWithoutImage.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelWithoutImage.ForeColor = System.Drawing.Color.Black;
            this.labelWithoutImage.Location = new System.Drawing.Point(3, 291);
            this.labelWithoutImage.Name = "labelWithoutImage";
            this.labelWithoutImage.Size = new System.Drawing.Size(155, 30);
            this.labelWithoutImage.TabIndex = 1;
            this.labelWithoutImage.Text = "Không tranh:";
            this.labelWithoutImage.TextAlignment = System.Drawing.StringAlignment.Far;
            // 
            // labelWithImage
            // 
            this.labelWithImage.BackColor = System.Drawing.Color.Transparent;
            this.labelWithImage.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelWithImage.ForeColor = System.Drawing.Color.Black;
            this.labelWithImage.Location = new System.Drawing.Point(0, 255);
            this.labelWithImage.Name = "labelWithImage";
            this.labelWithImage.Size = new System.Drawing.Size(158, 30);
            this.labelWithImage.TabIndex = 1;
            this.labelWithImage.Text = "Có tranh:";
            this.labelWithImage.TextAlignment = System.Drawing.StringAlignment.Far;
            // 
            // labNumOfQue
            // 
            this.labNumOfQue.BackColor = System.Drawing.Color.Transparent;
            this.labNumOfQue.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labNumOfQue.ForeColor = System.Drawing.Color.Black;
            this.labNumOfQue.Location = new System.Drawing.Point(0, 219);
            this.labNumOfQue.Name = "labNumOfQue";
            this.labNumOfQue.Size = new System.Drawing.Size(158, 30);
            this.labNumOfQue.TabIndex = 1;
            this.labNumOfQue.Text = "Tổng số câu hỏi:";
            this.labNumOfQue.TextAlignment = System.Drawing.StringAlignment.Far;
            // 
            // cmbLevel
            // 
            this.cmbLevel.DisplayMember = "Text";
            this.cmbLevel.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbLevel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbLevel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbLevel.FormattingEnabled = true;
            this.cmbLevel.ItemHeight = 23;
            this.cmbLevel.Location = new System.Drawing.Point(104, 4);
            this.cmbLevel.Name = "cmbLevel";
            this.cmbLevel.Size = new System.Drawing.Size(67, 29);
            this.cmbLevel.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2010;
            this.cmbLevel.TabIndex = 2;
            this.cmbLevel.SelectedIndexChanged += new System.EventHandler(this.cmbLevel_SelectedIndexChanged);
            // 
            // labelSumOfWithoutImage
            // 
            this.labelSumOfWithoutImage.BackColor = System.Drawing.Color.Transparent;
            this.labelSumOfWithoutImage.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSumOfWithoutImage.ForeColor = System.Drawing.Color.Black;
            this.labelSumOfWithoutImage.Location = new System.Drawing.Point(216, 290);
            this.labelSumOfWithoutImage.Name = "labelSumOfWithoutImage";
            this.labelSumOfWithoutImage.Size = new System.Drawing.Size(98, 30);
            this.labelSumOfWithoutImage.TabIndex = 1;
            this.labelSumOfWithoutImage.Text = "0";
            // 
            // labelSumOfWithImage
            // 
            this.labelSumOfWithImage.BackColor = System.Drawing.Color.Transparent;
            this.labelSumOfWithImage.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSumOfWithImage.ForeColor = System.Drawing.Color.Black;
            this.labelSumOfWithImage.Location = new System.Drawing.Point(216, 257);
            this.labelSumOfWithImage.Name = "labelSumOfWithImage";
            this.labelSumOfWithImage.Size = new System.Drawing.Size(98, 30);
            this.labelSumOfWithImage.TabIndex = 1;
            this.labelSumOfWithImage.Text = "0";
            // 
            // labelSumOfQue
            // 
            this.labelSumOfQue.BackColor = System.Drawing.Color.Transparent;
            this.labelSumOfQue.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSumOfQue.ForeColor = System.Drawing.Color.Black;
            this.labelSumOfQue.Location = new System.Drawing.Point(216, 220);
            this.labelSumOfQue.Name = "labelSumOfQue";
            this.labelSumOfQue.Size = new System.Drawing.Size(98, 30);
            this.labelSumOfQue.TabIndex = 1;
            this.labelSumOfQue.Text = "0";
            // 
            // allQuestion1
            // 
            this.allQuestion1.BackColor = System.Drawing.Color.Transparent;
            this.allQuestion1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.allQuestion1.ForeColor = System.Drawing.Color.Black;
            this.allQuestion1.Location = new System.Drawing.Point(177, 3);
            this.allQuestion1.Name = "allQuestion1";
            this.allQuestion1.Size = new System.Drawing.Size(129, 30);
            this.allQuestion1.TabIndex = 1;
            this.allQuestion1.Text = "0";
            // 
            // labelTopic
            // 
            this.labelTopic.BackColor = System.Drawing.Color.Transparent;
            this.labelTopic.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.labelTopic.ForeColor = System.Drawing.Color.Black;
            this.labelTopic.Location = new System.Drawing.Point(12, 44);
            this.labelTopic.Name = "labelTopic";
            this.labelTopic.Size = new System.Drawing.Size(285, 30);
            this.labelTopic.TabIndex = 1;
            this.labelTopic.Text = "Chọn chủ đề";
            // 
            // labLevel
            // 
            this.labLevel.BackColor = System.Drawing.Color.Transparent;
            this.labLevel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.labLevel.ForeColor = System.Drawing.Color.Black;
            this.labLevel.Location = new System.Drawing.Point(12, 3);
            this.labLevel.Name = "labLevel";
            this.labLevel.Size = new System.Drawing.Size(121, 30);
            this.labLevel.TabIndex = 1;
            this.labLevel.Text = "Cấp độ:";
            // 
            // butStart
            // 
            this.butStart.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.butStart.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.butStart.Enabled = false;
            this.butStart.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butStart.Location = new System.Drawing.Point(110, 342);
            this.butStart.Name = "butStart";
            this.butStart.Size = new System.Drawing.Size(89, 42);
            this.butStart.TabIndex = 0;
            this.butStart.Text = "Bắt đầu";
            this.butStart.Click += new System.EventHandler(this.butStart_Click);
            // 
            // tabTest
            // 
            this.tabTest.AttachedControl = this.tabControlPanel1;
            this.tabTest.Name = "tabTest";
            this.tabTest.Text = "Thi";
            this.tabTest.Click += new System.EventHandler(this.tabTest_Click);
            // 
            // tabControlPanel2
            // 
            this.tabControlPanel2.Controls.Add(this.cmbPraTopic);
            this.tabControlPanel2.Controls.Add(this.cmbPraLevel);
            this.tabControlPanel2.Controls.Add(this.labPraTopic);
            this.tabControlPanel2.Controls.Add(this.labPraLevel);
            this.tabControlPanel2.Controls.Add(this.butPractice);
            this.tabControlPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlPanel2.Location = new System.Drawing.Point(0, 26);
            this.tabControlPanel2.Name = "tabControlPanel2";
            this.tabControlPanel2.Padding = new System.Windows.Forms.Padding(1);
            this.tabControlPanel2.Size = new System.Drawing.Size(309, 410);
            this.tabControlPanel2.Style.BackColor1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(179)))), ((int)(((byte)(231)))));
            this.tabControlPanel2.Style.BackColor2.Color = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(237)))), ((int)(((byte)(254)))));
            this.tabControlPanel2.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.tabControlPanel2.Style.BorderColor.Color = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(97)))), ((int)(((byte)(156)))));
            this.tabControlPanel2.Style.BorderSide = ((DevComponents.DotNetBar.eBorderSide)(((DevComponents.DotNetBar.eBorderSide.Left | DevComponents.DotNetBar.eBorderSide.Right)
                        | DevComponents.DotNetBar.eBorderSide.Bottom)));
            this.tabControlPanel2.Style.GradientAngle = 90;
            this.tabControlPanel2.TabIndex = 2;
            this.tabControlPanel2.TabItem = this.tabPractice;
            // 
            // cmbPraTopic
            // 
            this.cmbPraTopic.DisplayMember = "Text";
            this.cmbPraTopic.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbPraTopic.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPraTopic.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbPraTopic.FormattingEnabled = true;
            this.cmbPraTopic.ItemHeight = 23;
            this.cmbPraTopic.Location = new System.Drawing.Point(151, 45);
            this.cmbPraTopic.Name = "cmbPraTopic";
            this.cmbPraTopic.Size = new System.Drawing.Size(108, 29);
            this.cmbPraTopic.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2010;
            this.cmbPraTopic.TabIndex = 3;
            this.cmbPraTopic.SelectedIndexChanged += new System.EventHandler(this.cmbPraTopic_SelectedIndexChanged);
            // 
            // cmbPraLevel
            // 
            this.cmbPraLevel.DisplayMember = "Text";
            this.cmbPraLevel.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbPraLevel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPraLevel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbPraLevel.FormattingEnabled = true;
            this.cmbPraLevel.ItemHeight = 23;
            this.cmbPraLevel.Location = new System.Drawing.Point(151, 9);
            this.cmbPraLevel.Name = "cmbPraLevel";
            this.cmbPraLevel.Size = new System.Drawing.Size(90, 29);
            this.cmbPraLevel.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2010;
            this.cmbPraLevel.TabIndex = 3;
            this.cmbPraLevel.SelectedIndexChanged += new System.EventHandler(this.cmbPraLevel_SelectedIndexChanged);
            // 
            // labPraTopic
            // 
            this.labPraTopic.BackColor = System.Drawing.Color.Transparent;
            this.labPraTopic.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labPraTopic.ForeColor = System.Drawing.Color.Black;
            this.labPraTopic.Location = new System.Drawing.Point(19, 44);
            this.labPraTopic.Name = "labPraTopic";
            this.labPraTopic.Size = new System.Drawing.Size(125, 30);
            this.labPraTopic.TabIndex = 2;
            this.labPraTopic.Text = "Chủ đề:";
            this.labPraTopic.TextAlignment = System.Drawing.StringAlignment.Far;
            // 
            // labPraLevel
            // 
            this.labPraLevel.BackColor = System.Drawing.Color.Transparent;
            this.labPraLevel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labPraLevel.ForeColor = System.Drawing.Color.Black;
            this.labPraLevel.Location = new System.Drawing.Point(19, 8);
            this.labPraLevel.Name = "labPraLevel";
            this.labPraLevel.Size = new System.Drawing.Size(125, 30);
            this.labPraLevel.TabIndex = 2;
            this.labPraLevel.Text = "Cấp độ:";
            this.labPraLevel.TextAlignment = System.Drawing.StringAlignment.Far;
            // 
            // butPractice
            // 
            this.butPractice.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.butPractice.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.butPractice.Location = new System.Drawing.Point(116, 92);
            this.butPractice.Name = "butPractice";
            this.butPractice.Size = new System.Drawing.Size(79, 30);
            this.butPractice.TabIndex = 0;
            this.butPractice.Text = "Bắt đầu";
            this.butPractice.Click += new System.EventHandler(this.butNewPractice_Click);
            // 
            // tabPractice
            // 
            this.tabPractice.AttachedControl = this.tabControlPanel2;
            this.tabPractice.Name = "tabPractice";
            this.tabPractice.Text = "Luyện tập";
            this.tabPractice.Click += new System.EventHandler(this.tabPractice_Click);
            // 
            // frmListenSetting
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(309, 436);
            this.Controls.Add(this.tabCtr);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(315, 460);
            this.Name = "frmListenSetting";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Thiết lập";
            this.TransparencyKey = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.Load += new System.EventHandler(this.frmListenSetting_Load);
            ((System.ComponentModel.ISupportInitialize)(this.tabCtr)).EndInit();
            this.tabCtr.ResumeLayout(false);
            this.tabControlPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewX1)).EndInit();
            this.tabControlPanel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private DevComponents.DotNetBar.TabControl tabCtr;
        private DevComponents.DotNetBar.TabControlPanel tabControlPanel1;
        private DevComponents.DotNetBar.TabItem tabTest;
        private DevComponents.DotNetBar.TabControlPanel tabControlPanel2;
        private DevComponents.DotNetBar.TabItem tabPractice;
        private DevComponents.DotNetBar.ButtonX butStart;
        private DevComponents.DotNetBar.Controls.ComboBoxEx cmbNumOfQue;
        private DevComponents.DotNetBar.LabelX labNumOfQue;
        private DevComponents.DotNetBar.Controls.ComboBoxEx cmbLevel;
        private DevComponents.DotNetBar.LabelX labLevel;
        private DevComponents.DotNetBar.LabelX allQuestion1;
        private DevComponents.DotNetBar.ButtonX butPractice;
        private DevComponents.DotNetBar.Controls.ComboBoxEx cmbPraTopic;
        private DevComponents.DotNetBar.Controls.ComboBoxEx cmbPraLevel;
        private DevComponents.DotNetBar.LabelX labPraTopic;
        private DevComponents.DotNetBar.LabelX labPraLevel;
        private DevComponents.DotNetBar.Controls.DataGridViewX dataGridViewX1;
        private DevComponents.DotNetBar.Controls.ComboBoxEx cmbWithoutImage;
        private DevComponents.DotNetBar.Controls.ComboBoxEx cmbWithImage;
        private DevComponents.DotNetBar.LabelX labelWithoutImage;
        private DevComponents.DotNetBar.LabelX labelWithImage;
        private DevComponents.DotNetBar.LabelX labelTopic;
        private DevComponents.DotNetBar.LabelX labelSumOfWithoutImage;
        private DevComponents.DotNetBar.LabelX labelSumOfWithImage;
        private DevComponents.DotNetBar.LabelX labelSumOfQue;
        private ComponentFactory.Krypton.Toolkit.KryptonDataGridViewCheckBoxColumn Checker;
        private ComponentFactory.Krypton.Toolkit.KryptonDataGridViewTextBoxColumn Topic;
        private ComponentFactory.Krypton.Toolkit.KryptonDataGridViewTextBoxColumn NumOfQue;
    }
}
﻿namespace JTest.GUI
{
    partial class frmImportDB
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmImportDB));
            this.label2 = new System.Windows.Forms.Label();
            this.cmbDbName = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblForCSDL = new System.Windows.Forms.Label();
            this.lblForName = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.rdNew = new System.Windows.Forms.RadioButton();
            this.rdExpand = new System.Windows.Forms.RadioButton();
            this.cmbType = new System.Windows.Forms.ComboBox();
            this.lblForType = new System.Windows.Forms.Label();
            this.cmbLevel = new System.Windows.Forms.ComboBox();
            this.lblForLevel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.ofdSource = new System.Windows.Forms.OpenFileDialog();
            this.txtFilePath = new System.Windows.Forms.TextBox();
            this.btnOpenFile = new System.Windows.Forms.Button();
            this.btnApply = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.bkWorker = new System.ComponentModel.BackgroundWorker();
            this.pnlContainer = new System.Windows.Forms.Panel();
            this.lblCSDL = new System.Windows.Forms.Label();
            this.rdAddComment = new System.Windows.Forms.RadioButton();
            this.cmbDbNameAddComment = new System.Windows.Forms.ComboBox();
            this.groupBox1.SuspendLayout();
            this.pnlContainer.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(2, 96);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Cách Thức :";
            // 
            // cmbDbName
            // 
            this.cmbDbName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbDbName.FormattingEnabled = true;
            this.cmbDbName.Location = new System.Drawing.Point(115, 45);
            this.cmbDbName.Name = "cmbDbName";
            this.cmbDbName.Size = new System.Drawing.Size(146, 21);
            this.cmbDbName.TabIndex = 5;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblCSDL);
            this.groupBox1.Controls.Add(this.rdAddComment);
            this.groupBox1.Controls.Add(this.cmbDbNameAddComment);
            this.groupBox1.Controls.Add(this.lblForCSDL);
            this.groupBox1.Controls.Add(this.lblForName);
            this.groupBox1.Controls.Add(this.txtName);
            this.groupBox1.Controls.Add(this.rdNew);
            this.groupBox1.Controls.Add(this.rdExpand);
            this.groupBox1.Controls.Add(this.cmbDbName);
            this.groupBox1.Location = new System.Drawing.Point(81, 88);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(302, 187);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            // 
            // lblForCSDL
            // 
            this.lblForCSDL.AutoSize = true;
            this.lblForCSDL.Location = new System.Drawing.Point(54, 48);
            this.lblForCSDL.Name = "lblForCSDL";
            this.lblForCSDL.Size = new System.Drawing.Size(44, 13);
            this.lblForCSDL.TabIndex = 14;
            this.lblForCSDL.Text = "CSDL : ";
            // 
            // lblForName
            // 
            this.lblForName.AutoSize = true;
            this.lblForName.Enabled = false;
            this.lblForName.Location = new System.Drawing.Point(32, 102);
            this.lblForName.Name = "lblForName";
            this.lblForName.Size = new System.Drawing.Size(66, 13);
            this.lblForName.TabIndex = 13;
            this.lblForName.Text = "Tên CSDL : ";
            // 
            // txtName
            // 
            this.txtName.Enabled = false;
            this.txtName.Location = new System.Drawing.Point(115, 99);
            this.txtName.MaxLength = 25;
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(146, 20);
            this.txtName.TabIndex = 6;
            // 
            // rdNew
            // 
            this.rdNew.AutoSize = true;
            this.rdNew.Location = new System.Drawing.Point(22, 70);
            this.rdNew.Name = "rdNew";
            this.rdNew.Size = new System.Drawing.Size(63, 17);
            this.rdNew.TabIndex = 1;
            this.rdNew.Text = "Tạo mới";
            this.rdNew.UseVisualStyleBackColor = true;
            this.rdNew.CheckedChanged += new System.EventHandler(this.rdNew_CheckedChanged);
            // 
            // rdExpand
            // 
            this.rdExpand.AutoSize = true;
            this.rdExpand.Checked = true;
            this.rdExpand.Location = new System.Drawing.Point(22, 19);
            this.rdExpand.Name = "rdExpand";
            this.rdExpand.Size = new System.Drawing.Size(64, 17);
            this.rdExpand.TabIndex = 0;
            this.rdExpand.Text = "Mở rộng";
            this.rdExpand.UseVisualStyleBackColor = true;
            this.rdExpand.CheckedChanged += new System.EventHandler(this.rdExpand_CheckedChanged);
            // 
            // cmbType
            // 
            this.cmbType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbType.FormattingEnabled = true;
            this.cmbType.Items.AddRange(new object[] {
            "Grammar",
            "Vocabulary"});
            this.cmbType.Location = new System.Drawing.Point(288, 54);
            this.cmbType.Name = "cmbType";
            this.cmbType.Size = new System.Drawing.Size(99, 21);
            this.cmbType.TabIndex = 7;
            // 
            // lblForType
            // 
            this.lblForType.AutoSize = true;
            this.lblForType.Location = new System.Drawing.Point(221, 57);
            this.lblForType.Name = "lblForType";
            this.lblForType.Size = new System.Drawing.Size(58, 13);
            this.lblForType.TabIndex = 6;
            this.lblForType.Text = "Nội Dung :";
            // 
            // cmbLevel
            // 
            this.cmbLevel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbLevel.FormattingEnabled = true;
            this.cmbLevel.Items.AddRange(new object[] {
            "N1",
            "N2",
            "N3",
            "N4",
            "N5"});
            this.cmbLevel.Location = new System.Drawing.Point(81, 54);
            this.cmbLevel.Name = "cmbLevel";
            this.cmbLevel.Size = new System.Drawing.Size(98, 21);
            this.cmbLevel.TabIndex = 5;
            this.cmbLevel.SelectedIndexChanged += new System.EventHandler(this.cmbLevel_SelectedIndexChanged);
            // 
            // lblForLevel
            // 
            this.lblForLevel.AutoSize = true;
            this.lblForLevel.Location = new System.Drawing.Point(20, 57);
            this.lblForLevel.Name = "lblForLevel";
            this.lblForLevel.Size = new System.Drawing.Size(48, 13);
            this.lblForLevel.TabIndex = 4;
            this.lblForLevel.Text = "Cấp độ :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(20, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Nguồn : ";
            // 
            // ofdSource
            // 
            this.ofdSource.Filter = "Data Source (*.xls)|*.xls| All Files|*.*";
            // 
            // txtFilePath
            // 
            this.txtFilePath.BackColor = System.Drawing.Color.White;
            this.txtFilePath.Location = new System.Drawing.Point(81, 15);
            this.txtFilePath.Name = "txtFilePath";
            this.txtFilePath.ReadOnly = true;
            this.txtFilePath.Size = new System.Drawing.Size(225, 20);
            this.txtFilePath.TabIndex = 9;
            this.txtFilePath.WordWrap = false;
            // 
            // btnOpenFile
            // 
            this.btnOpenFile.Location = new System.Drawing.Point(312, 13);
            this.btnOpenFile.Name = "btnOpenFile";
            this.btnOpenFile.Size = new System.Drawing.Size(75, 23);
            this.btnOpenFile.TabIndex = 10;
            this.btnOpenFile.Text = "Chọn tập tin";
            this.btnOpenFile.UseVisualStyleBackColor = true;
            this.btnOpenFile.Click += new System.EventHandler(this.btnOpenFile_Click);
            // 
            // btnApply
            // 
            this.btnApply.Location = new System.Drawing.Point(81, 281);
            this.btnApply.Name = "btnApply";
            this.btnApply.Size = new System.Drawing.Size(75, 23);
            this.btnApply.TabIndex = 11;
            this.btnApply.Text = "Áp dụng";
            this.btnApply.UseVisualStyleBackColor = true;
            this.btnApply.Click += new System.EventHandler(this.btnApply_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(308, 281);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 12;
            this.btnExit.Text = "Thoát";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // bkWorker
            // 
            this.bkWorker.DoWork += new System.ComponentModel.DoWorkEventHandler(this.bkWorker_DoWork);
            this.bkWorker.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.bkWorker_ProgressChanged);
            this.bkWorker.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.bkWorker_RunWorkerCompleted);
            // 
            // pnlContainer
            // 
            this.pnlContainer.Controls.Add(this.btnExit);
            this.pnlContainer.Controls.Add(this.groupBox1);
            this.pnlContainer.Controls.Add(this.btnApply);
            this.pnlContainer.Controls.Add(this.label2);
            this.pnlContainer.Controls.Add(this.btnOpenFile);
            this.pnlContainer.Controls.Add(this.lblForLevel);
            this.pnlContainer.Controls.Add(this.txtFilePath);
            this.pnlContainer.Controls.Add(this.cmbLevel);
            this.pnlContainer.Controls.Add(this.label1);
            this.pnlContainer.Controls.Add(this.lblForType);
            this.pnlContainer.Controls.Add(this.cmbType);
            this.pnlContainer.Location = new System.Drawing.Point(1, -1);
            this.pnlContainer.Name = "pnlContainer";
            this.pnlContainer.Size = new System.Drawing.Size(443, 325);
            this.pnlContainer.TabIndex = 13;
            // 
            // lblCSDL
            // 
            this.lblCSDL.AutoSize = true;
            this.lblCSDL.Location = new System.Drawing.Point(55, 157);
            this.lblCSDL.Name = "lblCSDL";
            this.lblCSDL.Size = new System.Drawing.Size(44, 13);
            this.lblCSDL.TabIndex = 17;
            this.lblCSDL.Text = "CSDL : ";
            // 
            // rdAddComment
            // 
            this.rdAddComment.Location = new System.Drawing.Point(23, 128);
            this.rdAddComment.Name = "rdAddComment";
            this.rdAddComment.Size = new System.Drawing.Size(114, 20);
            this.rdAddComment.TabIndex = 15;
            this.rdAddComment.Text = "Bổ sung giải thích";
            this.rdAddComment.UseVisualStyleBackColor = true;
            this.rdAddComment.CheckedChanged += new System.EventHandler(this.rdAddComment_CheckedChanged);
            // 
            // cmbDbNameAddComment
            // 
            this.cmbDbNameAddComment.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbDbNameAddComment.FormattingEnabled = true;
            this.cmbDbNameAddComment.Location = new System.Drawing.Point(116, 154);
            this.cmbDbNameAddComment.Name = "cmbDbNameAddComment";
            this.cmbDbNameAddComment.Size = new System.Drawing.Size(146, 21);
            this.cmbDbNameAddComment.TabIndex = 16;
            // 
            // frmImportDB
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(444, 325);
            this.Controls.Add(this.pnlContainer);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmImportDB";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Thêm câu hỏi";
            this.Load += new System.EventHandler(this.frmImportDB_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.pnlContainer.ResumeLayout(false);
            this.pnlContainer.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbDbName;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rdNew;
        private System.Windows.Forms.RadioButton rdExpand;
        private System.Windows.Forms.ComboBox cmbType;
        private System.Windows.Forms.Label lblForType;
        private System.Windows.Forms.ComboBox cmbLevel;
        private System.Windows.Forms.Label lblForLevel;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.OpenFileDialog ofdSource;
        private System.Windows.Forms.TextBox txtFilePath;
        private System.Windows.Forms.Button btnOpenFile;
        private System.Windows.Forms.Button btnApply;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblForName;
        private System.Windows.Forms.Label lblForCSDL;
        private System.ComponentModel.BackgroundWorker bkWorker;
        private System.Windows.Forms.Panel pnlContainer;
        private System.Windows.Forms.Label lblCSDL;
        private System.Windows.Forms.RadioButton rdAddComment;
        private System.Windows.Forms.ComboBox cmbDbNameAddComment;


    }
}
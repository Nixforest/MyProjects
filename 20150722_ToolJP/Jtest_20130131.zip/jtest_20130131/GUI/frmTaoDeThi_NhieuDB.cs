﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using Microsoft.Office.Interop.Excel;
using JTest.DTO;
using JTest.BUS;
using System.Threading;
using JTest.Others;
using System.Xml;
using System.IO;


namespace JTest.GUI
{

    public partial class frmTaoDeThi_NhieuDB : Form
    {        
        CreateTestBUS Bus = new CreateTestBUS();
        System.Collections.Hashtable myHashtable;//is used to kill excel process
        string thongbao = "";
        string taode = "";
        string message1 = "";
        string message2 = "";
        string message3 = "";
        string message4 = "";
        string message5 = "";
        string message6 = "";
        string message7 = "";
        string batdau = "";
        string dangxuat = "";
        // ToanNN
        string strNguPhap = String.Empty;
        string strTuVung = String.Empty;
        int Tong = 0;
        Int16 conlai = 0;
        bool CheckBoxClick = false;
        public frmTaoDeThi_NhieuDB()
        {

            InitializeComponent();
            LoadCombobox();
            if (frmMain.lang != "error")
            {
                controlLang();
            }
            else
            { //  bug here
                List<ComboBoxItem> items = new List<ComboBoxItem>();
                items.Add(new ComboBoxItem("Ngữ pháp", "Ngữ pháp"));
                items.Add(new ComboBoxItem("Từ vựng", "Từ vựng"));
                cmbPhanLoai.ValueMember = "Value";
                cmbPhanLoai.DisplayMember = "Display";
                cmbPhanLoai.DataSource = items;
            }
        }

        /// <summary>
        /// Controls the lang.
        /// </summary>
        /// @nhannc
        private void controlLang()
        {
            try
            {
                XmlNodeList xnList = frmMain.xml.SelectNodes("lang/taode");
                foreach (XmlNode xn in xnList)
                {                    
                    taode = xn["taode"].InnerText;
                    btnThoat.Text = xn["thoat"].InnerText;
                    thongbao = xn["thongbao"].InnerText;
                    message1 = xn["message1"].InnerText;
                    message2 = xn["message2"].InnerText;
                    message3 = xn["message3"].InnerText;
                    message4 = xn["message4"].InnerText;
                    message5 = xn["message5"].InnerText;
                    message6 = xn["message6"].InnerText;
                    message7 = xn["message7"].InnerText;
                    batdau = xn["batdau"].InnerText;
                    dangxuat = xn["dangxuat"].InnerText;
                    tslStatus.Text = xn["dangxuat"].InnerText;
                }
            }
            catch (Exception ex)
            { //MessageBox.Show(ex.Message); 
            }
        }


        //xu ly khi bam nut thu hep form
        private void thuhep()
        {
            //invible lbldb6->10
            this.lblDb6.Visible = false;
            this.lblDb7.Visible = false;
            this.lblDb8.Visible = false;
            this.lblDb9.Visible = false;
            this.lblDb10.Visible = false;

            //invisible txtdb6->10
            this.txtDb6.Visible = false;
            this.txtDb7.Visible = false;
            this.txtDb8.Visible = false;
            this.txtDb9.Visible = false;
            this.txtDb10.Visible = false;

            //invisbile btndb6->10
            this.btnDb6.Visible = false;
            this.btnDb7.Visible = false;
            this.btnDb8.Visible = false;
            this.btnDb9.Visible = false;
            this.btnDb10.Visible = false;

            //invisbile nbrdb6->10
            this.nbrDb6.Visible = false;
            this.nbrDb7.Visible = false;
            this.nbrDb8.Visible = false;
            this.nbrDb9.Visible = false;
            this.nbrDb10.Visible = false;

            //Change value nbrdb6->10  --> 0
            this.nbrDb6.Value = 0;
            this.nbrDb7.Value = 0;
            this.nbrDb8.Value = 0;
            this.nbrDb9.Value = 0;
            this.nbrDb10.Value = 0;

            //invisbile lblPhanTramb6->10
            this.lbldonvi6.Visible = false;
            this.lbldonvi7.Visible = false;
            this.lbldonvi8.Visible = false;
            this.lbldonvi9.Visible = false;
            this.lbldonvi10.Visible = false;

            //Change location btnTaodethi, btnThoat, TongphanTram
            this.btnTaoDeThi.Location = new System.Drawing.Point(this.btnTaoDeThi.Location.X, this.btnTaoDeThi.Location.Y - 180);
            this.btnThoat.Location = new System.Drawing.Point(this.btnThoat.Location.X, this.btnThoat.Location.Y - 180);
            this.lblTong.Location = new System.Drawing.Point(this.lblTong.Location.X, this.lblTong.Location.Y - 180);
            this.lblTongVal.Location = new System.Drawing.Point(this.lblTongVal.Location.X, this.lblTongVal.Location.Y - 180);
            this.statusStrip1.Location = new System.Drawing.Point(this.statusStrip1.Location.X, this.statusStrip1.Location.Y - 180);
            this.pgbTinhTrangExport.Location = new System.Drawing.Point(this.pgbTinhTrangExport.Location.X, this.pgbTinhTrangExport.Location.Y - 180);

            //Decrease size of form
            this.Size = new System.Drawing.Size(this.Size.Width, this.Size.Height - 180);
            //change text of button
            this.txtMoRong.Text = "Mở rộng";
        }

        //xu ly khi bam nut mo rong form
        private void morong()
        {
            //visible lbldb6->10
            this.lblDb10.Visible = true;
            this.lblDb6.Visible = true;
            this.lblDb7.Visible = true;
            this.lblDb8.Visible = true;
            this.lblDb9.Visible = true;

            //visible txtdb6->10
            this.txtDb6.Visible = true;
            this.txtDb7.Visible = true;
            this.txtDb8.Visible = true;
            this.txtDb9.Visible = true;
            this.txtDb10.Visible = true;

            //visible btndb6->10
            this.btnDb6.Visible = true;
            this.btnDb7.Visible = true;
            this.btnDb8.Visible = true;
            this.btnDb9.Visible = true;
            this.btnDb10.Visible = true;

            //visbile nbrdb6->10
            this.nbrDb6.Visible = true;
            this.nbrDb7.Visible = true;
            this.nbrDb8.Visible = true;
            this.nbrDb9.Visible = true;
            this.nbrDb10.Visible = true;

            //visbile lblPhanTramb6->10
            this.lbldonvi6.Visible = true;
            this.lbldonvi7.Visible = true;
            this.lbldonvi8.Visible = true;
            this.lbldonvi9.Visible = true;
            this.lbldonvi10.Visible = true;


            //Change location btnTaodethi, btnThoat,%
            this.btnTaoDeThi.Location = new System.Drawing.Point(this.btnTaoDeThi.Location.X, this.btnTaoDeThi.Location.Y + 180);
            this.btnThoat.Location = new System.Drawing.Point(this.btnThoat.Location.X, this.btnThoat.Location.Y + 180);
            this.lblTong.Location = new System.Drawing.Point(this.lblTong.Location.X, this.lblTong.Location.Y + 180);
            this.lblTongVal.Location = new System.Drawing.Point(this.lblTongVal.Location.X, this.lblTongVal.Location.Y + 180);
            this.statusStrip1.Location = new System.Drawing.Point(this.statusStrip1.Location.X, this.statusStrip1.Location.Y + 180);
            this.pgbTinhTrangExport.Location = new System.Drawing.Point(this.pgbTinhTrangExport.Location.X, this.pgbTinhTrangExport.Location.Y + 180);


            //increase size of form
            this.Size = new System.Drawing.Size(this.Size.Width, this.Size.Height + 180);
            //change text of button
            this.txtMoRong.Text = "Thu hep";
        }


        private void frmTaoDeThi_NhieuDB_Load(object sender, EventArgs e)
        {

            thuhep();

            this.rdPhanTram.Checked = true;

        }



        private void txtMoRong_Click(object sender, EventArgs e)
        {
            if (this.txtMoRong.Text == "Mở rộng")
            {
                morong();

            }
            else
            {
                thuhep();

            }
        }



        private void tinhtong()
        {
            this.Tong = 0;
            foreach (Control control in this.Controls)
            {
                NumericUpDown numControls = control as NumericUpDown;

                if (numControls != null)
                {
                    if (numControls.Name != "nbrTongSoCau")
                        this.Tong += (short)numControls.Value;
                }
            }
            
        }

        
        private int tinhphanconlai()
        {
            
            if (this.rdPhanTram.Checked)
            {
                if (this.Tong > 100)
                {
                    MessageBox.Show("Tỷ lệ câu hỏi lấy từ csdl đã vượt quá số % còn lại", "Không hợp lệ",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return -1;
                }
                else
                {
                    conlai = (Int16)(100 - this.Tong);
                }
            }
            else if (this.rdSoCau.Checked)
            {
                if (this.Tong > this.nbrTongSoCau.Value)
                {
                    MessageBox.Show("Số lượng câu hỏi lấy từ csdl đã vượt quá số câu hỏi còn lại", "Không hợp lệ",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return -1 ;
                }
                else
                {
                    conlai = (Int16)(nbrTongSoCau.Value - this.Tong);
                    
                }
            }
            else if (this.CheckBoxClick)
            {
                CheckBoxClick = false;
                return -2;
            }
            return conlai;
            
            
        }

        //update phan con lai
        private int updatephanconlai()
        {
            
            tinhtong();
            if (tinhphanconlai() != -1 )
            {
                this.lblTongVal.Text = conlai.ToString();
                return 0;
            }

            return -1;
        }

        private void nbrDb1_ValueChanged(object sender, EventArgs e)
        {

                //this.lblTongVal.Text = this.tinhtong().ToString();
                if(updatephanconlai()==-1)
                    this.nbrDb1.Value=0;
        }

        private void nbrDb2_ValueChanged(object sender, EventArgs e)
        {
                if (updatephanconlai() == -1)
                    this.nbrDb2.Value = 0;
          

        }

        private void nbrDb3_ValueChanged(object sender, EventArgs e)
        {
                if (updatephanconlai() == -1)
                    this.nbrDb3.Value = 0;
            

        }



        private void nbrDb4_ValueChanged(object sender, EventArgs e)
        {
               if (updatephanconlai() == -1)
                    this.nbrDb4.Value = 0;
            

        }

        private void nbrDb5_ValueChanged(object sender, EventArgs e)
        {
               if (updatephanconlai() == -1)
                    this.nbrDb5.Value = 0;
           

        }

        private void nbrDb6_ValueChanged(object sender, EventArgs e)
        {
                if (updatephanconlai() == -1)
                    this.nbrDb6.Value = 0;
            

        }

        private void nbrDb7_ValueChanged(object sender, EventArgs e)
        {
           
                if (updatephanconlai() == -1)
                    this.nbrDb7.Value = 0;
           

        }

        private void nbrDb8_ValueChanged(object sender, EventArgs e)
        {
                if (updatephanconlai() == -1)
                    this.nbrDb8.Value = 0;
           

        }

        private void nbrDb9_ValueChanged(object sender, EventArgs e)
        {
                if (updatephanconlai() == -1)
                    this.nbrDb9.Value = 0;
           

        }

        private void nbrDb10_ValueChanged(object sender, EventArgs e)
        {
           
                if (updatephanconlai() == -1)
                    this.nbrDb10.Value = 0;
           

        }

        /*private void txtDb1_TextChanged(object sender, EventArgs e)
        {
            if (txtDb1.Text.Trim() != "")
            {
                if (updatephanconlai() == -1)
                    this.nbrDb1.Value = 0;
            }

        }
       

        private void txtDb2_TextChanged(object sender, EventArgs e)
        {

            if (txtDb2.Text.Trim() != "")
            {
                if (updatephanconlai() == -1)
                    this.nbrDb2.Value = 0;
            }
        }
        private void txtDb3_TextChanged(object sender, EventArgs e)
        {
            if (txtDb3.Text.Trim() != "")
            {
                if (updatephanconlai() == -1)
                    this.nbrDb3.Value = 0;
            }

        }


        private void txtDb4_TextChanged(object sender, EventArgs e)
        {
            if (txtDb4.Text.Trim() != "")
            {
                if (updatephanconlai() == -1)
                    this.nbrDb4.Value = 0;
            }
        }

        private void txtDb5_TextChanged(object sender, EventArgs e)
        {
            if (txtDb5.Text.Trim() != "")
            {
                if (updatephanconlai() == -1)
                    this.nbrDb5.Value = 0;
            }
        }

        private void txtDb6_TextChanged(object sender, EventArgs e)
        {
            if (txtDb6.Text.Trim() != "")
            {
                if (updatephanconlai() == -1)
                    this.nbrDb6.Value = 0;
            }
        }

        private void txtDb7_TextChanged(object sender, EventArgs e)
        {
            if (txtDb7.Text.Trim() != "")
            {
                if (updatephanconlai() == -1)
                    this.nbrDb7.Value = 0;
            }
        }

        private void txtDb8_TextChanged(object sender, EventArgs e)
        {
            if (txtDb8.Text.Trim() != "")
            {
                if (updatephanconlai() == -1)
                    this.nbrDb8.Value = 0;
            }
        }

        private void txtDb9_TextChanged(object sender, EventArgs e)
        {
            if (txtDb9.Text.Trim() != "")
            {
                if (updatephanconlai() == -1)
                    this.nbrDb9.Value = 0;
            }
        }

        private void txtDb10_TextChanged(object sender, EventArgs e)
        {
            if (txtDb10.Text.Trim() != "")
            {
                if (updatephanconlai() == -1)
                    this.nbrDb10.Value = 0;
            }

        }
        */


        private String GetFileNameOnly()
        {
            DialogResult result = openFileDialog.ShowDialog(); // Show the dialog.
            string nameOnly = "";
            if (result == DialogResult.OK) // Test result.
            {
                string fullName = openFileDialog.FileName;

                for (int i = fullName.Length - 1; i >= 0; i--)
                {
                    if (fullName[i] == '\\')
                    {
                        nameOnly = fullName.Substring(i + 1);
                        break;
                    }
                }

                //Kiem tra xem db nay da su dung chua
                foreach (Control control in this.Controls)
                {
                    System.Windows.Forms.TextBox numControls = control as System.Windows.Forms.TextBox;

                    if (numControls != null)
                    {
                        if (nameOnly == numControls.Text)
                        {
                            MessageBox.Show("CSDL này đã được sử dụng để tạo đề thi, hãy chọn csdl khác", "Không hợp lệ",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return "";
                        }
                    }
                }

            }
            return nameOnly;
        }

        private void btnDb1_Click(object sender, EventArgs e)
        {
            string name = GetFileNameOnly();
            if (name != "")
                this.txtDb1.Text = name;
        }


        private void btnDb2_Click(object sender, EventArgs e)
        {
            string name = GetFileNameOnly();
            if (name != "")
                this.txtDb2.Text = name;

        }

        private void btnDb3_Click(object sender, EventArgs e)
        {
            string name = GetFileNameOnly();
            if (name != "")
                this.txtDb3.Text = name;
        }

        private void btnDb4_Click(object sender, EventArgs e)
        {
            string name = GetFileNameOnly();
            if (name != "")
                this.txtDb4.Text = name;
        }

        private void btnDb5_Click(object sender, EventArgs e)
        {
            string name = GetFileNameOnly();
            if (name != "")
                this.txtDb5.Text = name;
        }

        private void btnDb6_Click(object sender, EventArgs e)
        {
            string name = GetFileNameOnly();
            if (name != "")
                this.txtDb6.Text = name;
        }

        private void btnDb7_Click(object sender, EventArgs e)
        {
            string name = GetFileNameOnly();
            if (name != "")
                this.txtDb7.Text = name;
        }

        private void btnDb8_Click(object sender, EventArgs e)
        {
            string name = GetFileNameOnly();
            if (name != "")
                this.txtDb8.Text = name;
        }

        private void btnDb9_Click(object sender, EventArgs e)
        {
            string name = GetFileNameOnly();
            if (name != "")
                this.txtDb9.Text = name;
        }

        private void btnDb10_Click(object sender, EventArgs e)
        {
            string name = GetFileNameOnly();
            if (name != "")
                this.txtDb10.Text = name;
        }





        private void rdPhanTram_CheckedChanged(object sender, EventArgs e)
        {

            
            foreach (Control control in this.Controls)
            {
                System.Windows.Forms.Label lbl = control as System.Windows.Forms.Label;
                NumericUpDown numControls = control as NumericUpDown;
                if (lbl != null)
                {
                    if (lbl.Name.Contains("lbldonvi"))
                    {
                        lbl.Text = "%";
                    }
                }

                if (numControls != null)
                {
                    if (numControls.Name != "nbrTongSoCau")
                    {
                        numControls.Maximum = 100;
                        numControls.Value = 0;
                    }
                }
                
            }

           

            //Change label of Tong
            this.lblTong.Text = "Tổng % còn lại";
            this.lblTongVal.Text = "100";

            
        }

        private void rdSoCau_CheckedChanged(object sender, EventArgs e)
        {
            
            foreach (Control control in this.Controls)
            {
                System.Windows.Forms.Label lbl = control as System.Windows.Forms.Label;
                NumericUpDown numControls = control as NumericUpDown;
                if (lbl != null)
                {
                    if (lbl.Name.Contains("lbldonvi"))
                    {
                        lbl.Text = "Câu";
                    }
                }
                if (numControls != null)
                {
                    if (numControls.Name != "nbrTongSoCau")
                    {
                        numControls.Maximum = this.nbrTongSoCau.Value;
                        numControls.Value = 0;
                    }
                }
               
            }

            //Change label of Tong
            this.lblTong.Text = "Tổng số câu còn lại";

            this.lblTongVal.Text = this.nbrTongSoCau.Value.ToString();
            
        }


        private int csdlNotEmpty(System.Windows.Forms.TextBox textbox, NumericUpDown nmr )
        {
            if (nmr.Value != 0 && textbox.Text == "")
            {
                MessageBox.Show("csdl" + textbox.Name[textbox.Name.Length-1] + "không thể rỗng", "Không hợp lệ",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                return -1;
            }
            return 0;
        }

        private bool checkInvalid()
        {
            if (this.nbrTongSoCau.Value == 0)
            {
                MessageBox.Show("Bạn chưa nhập tổng số câu hỏi trong đề thi", "Không hợp lệ",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (rdPhanTram.Checked)
            {
                if (Tong != 100)
                {
                    MessageBox.Show("Tổng % của bạn chưa đủ 100%", "Không hợp lệ",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }

            }

            if (this.rdSoCau.Checked)
            {
                if (Tong != this.nbrTongSoCau.Value)
                {
                    MessageBox.Show("Tổng số câu trong đề thi và tổng số câu bạn chọn không khớp nhau",
                                    "Không hợp lệ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }

            }

            if (csdlNotEmpty(txtDb1, nbrDb1) == -1)
                return false;
            if (csdlNotEmpty(txtDb2, nbrDb2) == -1)
                return false;
            if (csdlNotEmpty(txtDb3, nbrDb3) == -1)
                return false;
            if (csdlNotEmpty(txtDb4, nbrDb4) == -1)
                return false;
            if (csdlNotEmpty(txtDb5, nbrDb5) == -1)
                return false;
            if (csdlNotEmpty(txtDb6, nbrDb6) == -1)
                return false;
            if (csdlNotEmpty(txtDb7, nbrDb7) == -1)
                return false;
            if (csdlNotEmpty(txtDb8, nbrDb8) == -1)
                return false;
            if (csdlNotEmpty(txtDb9, nbrDb9) == -1)
                return false;
            if (csdlNotEmpty(txtDb10, nbrDb10) == -1)
                return false;


            return true;
        }

       

        private void btnTaoDeThi_Click(object sender, EventArgs e)
        {

            if (checkInvalid())
            {
                SettingsDTO setting = SettingsBUS.loadSettingInfoFromFile();
                SettingsDTO settingTemp = setting;
                //List: Get all QuestionDTO from database
                List<QuestionDTO> ListEntity = new List<QuestionDTO>();
                List<QuestionDTO> listRandom = new List<QuestionDTO>();
                List<QuestionDTO> listTemp = new List<QuestionDTO>();
                int intLevel = -1;
                int intType = -1;
                convertCbValue(cmbCapDo.Text, cmbPhanLoai.Text, ref intLevel, ref intType);
                int solantrung = 3;
                string[] arrDB = new string[10];
                int[] arrSoCau = new int[10];
                int[] arrCau = new int[10];
                string lastcsld = "";
                int tongsocau = 0;

                arrDB = this.addArrDB(txtDb1.Text, txtDb2.Text, txtDb3.Text, txtDb4.Text, txtDb5.Text, txtDb6.Text, txtDb7.Text, txtDb8.Text, txtDb9.Text, txtDb10.Text);
                arrSoCau = this.addArrSo(Convert.ToInt16(nbrDb1.Value), Convert.ToInt16(nbrDb2.Value), Convert.ToInt16(nbrDb3.Value), Convert.ToInt16(nbrDb4.Value), Convert.ToInt16(nbrDb5.Value), Convert.ToInt16(nbrDb6.Value), Convert.ToInt16(nbrDb7.Value), Convert.ToInt16(nbrDb8.Value), Convert.ToInt16(nbrDb9.Value), Convert.ToInt16(nbrDb10.Value));

                //get last csdl
                for (int i = arrDB.Length - 1; i >=0; i--)
                {
                    if (arrDB[i] != "" && arrSoCau[i] != 0)
                    {
                        lastcsld = arrDB[i];
                        break;
                    }

                }

                for (int i = 0; i < arrDB.Length; i++)
                {
                    
                    string strTenDB = arrDB[i];
                    if (strTenDB != "")
                    {
                        int nudSoCau = arrSoCau[i];
                        if (rdPhanTram.Checked)
                        {
                            nudSoCau = this.changeValue(Convert.ToInt32(nbrTongSoCau.Value), nudSoCau);
                            arrCau[i] = nudSoCau;
                            tongsocau += nudSoCau;

                            //Neu tongsocau < nbrTongSoCau.Value do lam tron xuong khi tinh % thi ta cong 
                            //so cau thieu vao db cuoi cung
                            if (strTenDB == lastcsld)
                            {
                                if (tongsocau < Convert.ToInt32(nbrTongSoCau.Value))
                                {
                                    nudSoCau += Convert.ToInt32(nbrTongSoCau.Value) - tongsocau;
                                }

                            }

                        }
                        // update setting
                        settingTemp.Database = strTenDB;
                        SettingsBUS.saveSettingInfoToFile(settingTemp);
                        // get all
                        ListEntity = Bus.GetAll(intType, intLevel);
                        // get random
                        listTemp = Bus.RandomAll(ListEntity, intType, intLevel, solantrung, 1, ListEntity.Count, nudSoCau);
                        if (listTemp.Count == 0)
                        {
                            //MessageBox.Show(message2, thongbao, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                            MessageBox.Show("Xuất hiện csdl ko đc dùng để tạo đề thi do bị trùng với các đề lần trước hoặc tỷ lệ % quá nhỏ dẫn tới số câu = 0", thongbao, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);

                        }
                        this.updateListRandom(listRandom, listTemp);

                    }
                }
                                

                if (listRandom.Count != 0)
                {

                    SaveFileDialog _saveDlg = new SaveFileDialog();
                    _saveDlg.Filter = "Microsoft Excel file(*.xls)|*.xls";
                    _saveDlg.Title = taode;
                    DateTime curDay = DateTime.Now;
                    string phanLoai = String.Empty;
                    string capdo = string.Empty;

                    phanLoai = cmbPhanLoai.Text;
                    if (cmbCapDo.Text == Constant.strN2_N3)
                        capdo = "N2_N3";
                    else
                        capdo = cmbCapDo.Text;
                    _saveDlg.FileName = phanLoai + "_" + capdo + "_" + curDay.Year.ToString() + curDay.Month.ToString() + curDay.Day.ToString() + "_" + curDay.Hour + curDay.Minute;
                    _saveDlg.RestoreDirectory = true;

                    if (_saveDlg.ShowDialog() == DialogResult.OK)
                    {
                        string fileExcel = _saveDlg.FileName;
                        try
                        {
                            CheckExcellProcesses();
                            if (File.Exists(fileExcel))
                            {
                                File.Delete(fileExcel);
                                if (XuatFile(listRandom, fileExcel) == true)
                                {
                                    //Bus.CapNhatDanhSachDeThi(listRandom, cmbPhanLoai.SelectedIndex, cmbCapDo.SelectedIndex);
                                    Bus.SaveFile();
                                }
                            }
                            else
                            {
                                if (XuatFile(listRandom, fileExcel) == true)
                                {
                                    //Bus.CapNhatDanhSachDeThi(listRandom, cmbPhanLoai.SelectedIndex, cmbCapDo.SelectedIndex);
                                    Bus.SaveFile();
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            ShowError(message3);
                        }
                        finally
                        {
                            KillExcel();
                        }

                    }
                }

                SettingsBUS.saveSettingInfoToFile(setting);

            }
        }

        private void CheckExcellProcesses()
        {
            System.Diagnostics.Process[] AllProcesses = System.Diagnostics.Process.GetProcessesByName("excel");
            myHashtable = new System.Collections.Hashtable();
            int iCount = 0;

            foreach (System.Diagnostics.Process ExcelProcess in AllProcesses)
            {
                myHashtable.Add(ExcelProcess.Id, iCount);
                iCount = iCount + 1;
            }
        }

        public bool XuatFile(List<QuestionDTO> list, string filename)
        {


            Object missing = Type.Missing;
            Microsoft.Office.Interop.Excel.Application AppExcel = new Microsoft.Office.Interop.Excel.Application();

            Microsoft.Office.Interop.Excel.Workbooks objwBooks;
            Microsoft.Office.Interop.Excel.Workbook objwBook;

            Microsoft.Office.Interop.Excel.Sheets objSheets;
            Microsoft.Office.Interop.Excel.Worksheet objwSheet;
            Microsoft.Office.Interop.Excel.Range objRange;


            try
            {
                AppExcel.Visible = false;
                AppExcel.DisplayAlerts = false;
                objwBooks = AppExcel.Workbooks;
                objwBook = objwBooks.Add(missing);
                //ham nay truyen vao ten file lay tu dialog hoac vo day show dialog de lay ten file
                objwBook.SaveAs(filename, Microsoft.Office.Interop.Excel.XlFileFormat.xlWorkbookNormal, missing, missing, false, false, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlNoChange, missing, missing, missing, missing, missing);

                //Sheet 2_Answer
                objwSheet = (Microsoft.Office.Interop.Excel.Worksheet)objwBook.Worksheets.Add(missing, missing, missing, missing);
                objwSheet.Name = "Answer";
                objRange = objwSheet.Cells;

                WriteDataSheet2(list, objRange);
                objwBook.SaveAs(filename, Microsoft.Office.Interop.Excel.XlFileFormat.xlWorkbookNormal, missing, missing, false, false, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlNoChange, missing, missing, missing, missing, missing);

                //Sheet 1_Question
                objwSheet = (Microsoft.Office.Interop.Excel.Worksheet)objwBook.Worksheets.Add(missing, missing, missing, missing);
                objwSheet.Name = "Question";
                objRange = objwSheet.Cells;

                WriteDataSheet1(list, objRange);
                objwBook.SaveAs(filename, Microsoft.Office.Interop.Excel.XlFileFormat.xlWorkbookNormal, missing, missing, false, false, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlNoChange, missing, missing, missing, missing, missing);
            }
            catch (Exception ex)
            {
                //MessageBox.Show("Lỗi tạo file \n" + ex.Message, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            finally
            {

                AppExcel.Quit();
                objRange = null;
                objwSheet = null;
                objSheets = null;
                objwBook = null;
                objwBooks = null;
                AppExcel = null;

                System.GC.Collect();

            }
            MessageBox.Show(message4, thongbao, MessageBoxButtons.OK, MessageBoxIcon.Information);
            return true;

        }

        //Sheet question
        public void WriteDataSheet1(List<QuestionDTO> list, Microsoft.Office.Interop.Excel.Range objRange)
        {
            string str;
            int Stt = 1;
            int iRow = 1;
            pgbTinhTrangExport.Visible = true;
            pgbTinhTrangExport.Maximum = list.Count;

            //pgbTinhTrangExport.Step = 1;
            this.Cursor = Cursors.AppStarting;
            foreach (QuestionDTO Entity in list)
            {
                str = Entity.Question.Replace('\n', ' ');
                str = str.Replace('」', '。');
                //str = Entity.Question.Replace('「','[');
                //str = str.Replace('」',']');
                tslStatus.Text = dangxuat + ": " + Entity.Question;
                objRange[iRow, 1] = "問" + Stt + ":     " + str.Trim();
                objRange[iRow + 2, 1] = "A. " + Entity.AnswerA.Trim();
                objRange[iRow + 3, 1] = "B. " + Entity.AnswerB.Trim();
                objRange[iRow + 4, 1] = "C. " + Entity.AnswerC.Trim();
                objRange[iRow + 5, 1] = "D. " + Entity.AnswerD.Trim();
                pgbTinhTrangExport.Value = Stt;
                pgbTinhTrangExport.PerformStep();
                Stt++;
                iRow += 7;

            }
            //objRange.Columns.AutoFit();
            tslStatus.Text = batdau;
            pgbTinhTrangExport.Visible = false;

            this.Cursor = Cursors.Default;
        }

        //Sheet Answer
        private void WriteDataSheet2(List<QuestionDTO> list, Microsoft.Office.Interop.Excel.Range objRange)
        {
            int iCol = 0;
            int iRow = 2;
            objRange[1, 1] = "STT";
            objRange[1, 2] = "Question";
            ((Microsoft.Office.Interop.Excel.Range)objRange.Cells[1, 2]).EntireColumn.ColumnWidth = 80;
            objRange[1, 3] = "Answer";
            ((Microsoft.Office.Interop.Excel.Range)objRange.Cells[1, 3]).EntireColumn.ColumnWidth = 25;
            objRange[1, 4] = "ID";
            this.Cursor = Cursors.AppStarting;
            int stt = 1;
            string str;
            foreach (QuestionDTO Entity in list)
            {
                str = Entity.Question.Replace('\n', ' ');
                str = str.Replace('」', '。');
                objRange[iRow, 1] = stt;
                objRange[iRow, 2] = str.Trim();
                objRange[iRow, 3] = TimNoiDungDapAn(Entity, Entity.Answer.ToString());
                objRange[iRow, 4] = Entity.ID;
                stt++;
                iRow++;
            }
            //objRange.Columns.AutoFit();
        }

        private string TimNoiDungDapAn(QuestionDTO entity, string answer)
        {
            string result;
            if (answer == "A")
                result = "A.  " + entity.AnswerA.Trim();
            else if (answer == "B")
                result = "B.  " + entity.AnswerB.Trim();
            else if (answer == "C")
                result = "C.  " + entity.AnswerC.Trim();
            else
                result = "D.  " + entity.AnswerD.Trim();
            return result;
        }

        private void ShowError(string str)
        {
            MessageBox.Show(str, thongbao, MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void KillExcel()
        {
            System.Diagnostics.Process[] AllProcesses = System.Diagnostics.Process.GetProcessesByName("excel");

            // check to kill the right process
            foreach (System.Diagnostics.Process ExcelProcess in AllProcesses)
            {
                if (myHashtable.ContainsKey(ExcelProcess.Id) == false)
                    ExcelProcess.Kill();
            }

            AllProcesses = null;
        }



        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private List<QuestionDTO> updateListRandom(List<QuestionDTO> lstRandom, List<QuestionDTO> lstTemp)
        {
            for (int i = 0; i < lstTemp.Count; i++)
            {
                lstRandom.Add(lstTemp[i]);
            }
            return lstRandom;
        }

        private int changeValue(int sum, int percent)
        {
            decimal soCau = ((sum * percent) / 100);
            soCau = Math.Round(soCau);

            return (int)soCau;

        }

        private string[] addArrDB(string strDB1, string strDB2, string strDB3, string strDB4, string strDB5, string strDB6, string strDB7, string strDB8, string strDB9, string strDB10)
        {
            string[] arrDB = new string[10] { strDB1, strDB2, strDB3, strDB4, strDB5, strDB6, strDB7, strDB8, strDB9, strDB10 };

            return arrDB;
        }

        private int[] addArrSo(int so1, int so2, int so3, int so4, int so5, int so6, int so7, int so8, int so9, int so10)
        {
            int[] arrSo = new int[10] { so1, so2, so3, so4, so5, so6, so7, so8, so9, so10 };
            return arrSo;
        }

        private void cmbCapDo_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                cmbPhanLoai.Items.Clear();
                List<string> Type = command.getTypeList(cmbCapDo.Text);
                foreach (string strtype in Type)
                {
                    cmbPhanLoai.Items.Add(strtype);
                }
                cmbPhanLoai.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }



        /// <summary>
        /// add text to combobox
        /// </summary>
        public void LoadCombobox()
        {
            cmbCapDo.Items.Clear();
            List<string> LevelsList = command.getLevelList();
            foreach (string strlevel in LevelsList)
            {
                cmbCapDo.Items.Add(strlevel);
            }
            cmbCapDo.SelectedIndex = 0;

        }

        /// @author ToanNN
        /// <summary>
        /// chuyển giá trị trong combobox thành tên table
        /// </summary>
        /// <param name="strLevel"></param>
        /// <param name="strType"></param>
        /// <returns></returns>
        private void convertCbValue(string strLevel, string strType, ref int intLevel, ref int intType)
        {

            string type = String.Empty;
            if (strLevel == Constant.strN1)
            {
                intLevel = 1;
            }
            else if (strLevel == Constant.strN2_N3)
            {
                intLevel = 2;
            }
            else if (strLevel == Constant.strN4)
            {
                intLevel = 3;
            }
            else
            {
                intLevel = 4;
            }

            if (strType == Constant.strVocabulary)
            {
                intType = 1;
            }
            else if (strType == Constant.strGrammer)
            {
                intType = 0;
            }
        }

        

        


    }   
}

﻿namespace JTest.GUI
{
    partial class frmSavePracticeLog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSavePracticeLog));
            this.btOK = new System.Windows.Forms.Button();
            this.cbXuatCauSaiRaExcel = new System.Windows.Forms.CheckBox();
            this.cbLuuFileLog = new System.Windows.Forms.CheckBox();
            this.btCancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btOK
            // 
            this.btOK.Location = new System.Drawing.Point(47, 106);
            this.btOK.Name = "btOK";
            this.btOK.Size = new System.Drawing.Size(75, 23);
            this.btOK.TabIndex = 1;
            this.btOK.Text = "OK";
            this.btOK.UseVisualStyleBackColor = true;
            this.btOK.Click += new System.EventHandler(this.btOK_Click);
            // 
            // cbXuatCauSaiRaExcel
            // 
            this.cbXuatCauSaiRaExcel.AutoSize = true;
            this.cbXuatCauSaiRaExcel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.cbXuatCauSaiRaExcel.Location = new System.Drawing.Point(47, 18);
            this.cbXuatCauSaiRaExcel.Name = "cbXuatCauSaiRaExcel";
            this.cbXuatCauSaiRaExcel.Size = new System.Drawing.Size(234, 20);
            this.cbXuatCauSaiRaExcel.TabIndex = 3;
            this.cbXuatCauSaiRaExcel.Text = "Xuất danh sách câu sai ra file excel";
            this.cbXuatCauSaiRaExcel.UseVisualStyleBackColor = true;
            // 
            // cbLuuFileLog
            // 
            this.cbLuuFileLog.AutoSize = true;
            this.cbLuuFileLog.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.cbLuuFileLog.Location = new System.Drawing.Point(47, 65);
            this.cbLuuFileLog.Name = "cbLuuFileLog";
            this.cbLuuFileLog.Size = new System.Drawing.Size(209, 20);
            this.cbLuuFileLog.TabIndex = 4;
            this.cbLuuFileLog.Text = "Lưu kết quả luyện tập ra file log";
            this.cbLuuFileLog.UseVisualStyleBackColor = true;
            // 
            // btCancel
            // 
            this.btCancel.Location = new System.Drawing.Point(176, 106);
            this.btCancel.Name = "btCancel";
            this.btCancel.Size = new System.Drawing.Size(75, 23);
            this.btCancel.TabIndex = 5;
            this.btCancel.Text = "Cancel";
            this.btCancel.UseVisualStyleBackColor = true;
            this.btCancel.Click += new System.EventHandler(this.btCancel_Click);
            // 
            // frmSavePracticeLog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(304, 141);
            this.ControlBox = false;
            this.Controls.Add(this.btCancel);
            this.Controls.Add(this.cbLuuFileLog);
            this.Controls.Add(this.cbXuatCauSaiRaExcel);
            this.Controls.Add(this.btOK);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmSavePracticeLog";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Kết thúc";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btOK;
        private System.Windows.Forms.CheckBox cbXuatCauSaiRaExcel;
        private System.Windows.Forms.CheckBox cbLuuFileLog;
        private System.Windows.Forms.Button btCancel;
    }
}
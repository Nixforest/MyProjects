﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
//Create by DanDQ
namespace JTest.GUI
{
    public partial class frmThongke : Form

    {
        const string msgYeucauchonfile = "Vì sao (why, doushite)Bạn chưa chọn danh sách file dùng để thống kê.";
        const string msgYeucauchonluu = "Bạn muốn lưu file ở đâu thì chọn đi chứ?";
        const string msgNhaplaiFromTo = "Bạn nhập \" Từ câu\" và \" đến câu\" sai roài. \n Cần thỏa mãn một trong các điều kiện sau: \n 1. Không nhập cả 2 mục \n 2. \" Từ câu\" < \" đến câu\"";
        const string msgTatcacacfilekohople = "Tất cả các file đều không hợp lệ. Nhập lại nhé. :(";
        const string msgCaptionErr = "Nhập lỗi rồi kưng!";
        const string msgCaptionConfirm = "Confirm thao tác!";
        
        public frmThongke()
        {
            InitializeComponent();
        }

        private void btnChonfile_Click(object sender, EventArgs e)
        {
            if (ofdJCD.ShowDialog() == DialogResult.OK)
            {
                StringBuilder listfile = new StringBuilder();
                foreach (String file in ofdJCD.FileNames)
                {
                    listfile.AppendLine(file);
                }
                txtFileThongke.Text = listfile.ToString();
            }
        }

        private void btnLuufile_Click(object sender, EventArgs e)
        {
            if (sfdJCD.ShowDialog() == DialogResult.OK)
            {
                txtLuuFile.Text = sfdJCD.FileName;
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnExcute_Click(object sender, EventArgs e)
        {
            if ("".Equals(txtFileThongke.Text.Trim()))
            {
                MessageBox.Show(msgYeucauchonfile, msgCaptionErr, MessageBoxButtons.OK);
                txtFileThongke.Focus();
                return;
            }
            if ("".Equals(txtLuuFile.Text.Trim()))
            {
                MessageBox.Show(msgYeucauchonluu, msgCaptionErr, MessageBoxButtons.OK);
                txtLuuFile.Focus();
                return;
            }
            if (("".Equals(txtFrom.Text) && !"".Equals(txtTo.Text)) || (!"".Equals(txtFrom.Text) && "".Equals(txtTo.Text)))
            {
                MessageBox.Show(msgNhaplaiFromTo, msgCaptionErr, MessageBoxButtons.OK);
                txtFrom.Focus();
                return;
            }
            if (!"".Equals(txtFrom) && !"".Equals(txtTo.Text))
            {
                if (int.Parse(txtFrom.Text) > int.Parse(txtTo.Text))
                {
                    MessageBox.Show(msgNhaplaiFromTo, msgCaptionErr, MessageBoxButtons.OK);
                    txtFrom.Focus();
                    return;
                }
                List<string> selectedfiles = new List<string>(txtFileThongke.Text.Replace("\n\r", "\n").Replace("\r\n", "\n").Split('\n'));
                List<string> invalidfiles = Statistical.getInvalidFromToFile(selectedfiles, int.Parse(txtFrom.Text), int.Parse(txtTo.Text));
                StringBuilder validfiles = new StringBuilder();
                if (invalidfiles.Count != 0)
                {
                    StringBuilder msgConfirm = new StringBuilder();
                    msgConfirm.AppendLine("Danh sách các file không thỏa mãn vùng thống kê:");
                    foreach (string file in invalidfiles)
                    {
                        msgConfirm.AppendLine("- " + file);
                    }
                    msgConfirm.AppendLine("Bạn có muốn tiếp tục CHỈ thực hiện thống kê các file hợp lệ không?");
                    if (MessageBox.Show(msgConfirm.ToString(), msgCaptionConfirm, MessageBoxButtons.OKCancel) == DialogResult.OK)
                    {
                        // remove cac file khong hop le ra khoi danh sach.
                        for (int i = 0; i < selectedfiles.Count; i++)
                        {
                            for (int j = 0; j < invalidfiles.Count; j++ )
                            {
                                if (selectedfiles[i].Equals(invalidfiles[j].Substring(0,invalidfiles[j].LastIndexOf("***"))))
                                {
                                    selectedfiles.RemoveAt(i);
                                    i--;
                                    break;
                                }
                            }
                        }
                        if (selectedfiles.Count == 1)
                        {
                            MessageBox.Show(msgTatcacacfilekohople, msgCaptionErr);
                            return;
                        }
                        else
                        {
                            foreach (string tmp in selectedfiles)
                            {
                                validfiles.AppendLine(tmp);
                            }
                            txtFileThongke.Text = validfiles.ToString();
                        }
                    }
                    else
                    {
                        btnChonfile.Focus();
                        return;
                    }
                }
            }
            bool isAll = "".Equals(txtFrom.Text) && "".Equals(txtTo.Text);
            try
            {
                Statistical TK = new Statistical();
                List<grouping> groupList = new List<grouping>();
                //if (ofdJCD.ShowDialog() == DialogResult.OK)
                //{

                //int tongfile = 0;
                List<string> dbNameList = new List<string>();
                //duyet qua tung file
                List<wrongRecord> wrongList = new List<wrongRecord>();
                foreach (String file in txtFileThongke.Text.Replace("\n\r", "\n").Replace("\r\n", "\n").Split('\n'))
                {
                    if ("".Equals(file)) continue;
                    //tongfile++;
                    string mode = String.Empty;

                    List<wrongRecord> List = TK.getWrongRecord(file, ref mode, ref dbNameList, ref groupList);

                    foreach (wrongRecord rec in List)
                    {
                        wrongList.Add(rec);
                    }

                }
                //Loai bo nhung record khong thuoc vung thong ke.
                if (!isAll)
                {
                    int intFrom = int.Parse(txtFrom.Text);
                    int intTo = int.Parse(txtTo.Text);

                    for (int i = 0; i < wrongList.Count; i++)
                    {
                        if (wrongList[i].intID < intFrom || wrongList[i].intID > intTo)
                        {
                            wrongList.RemoveAt(i);
                            i--;
                        }
                    }
                }
                for (int i = 0; i < wrongList.Count; i++)
                    for (int j = i + 1; j < wrongList.Count; j++)
                    {
                        bool isEqual = TK.isEqualRecord(wrongList[i], wrongList[j]);
                        if (isEqual)
                        {
                            wrongList.RemoveAt(j);
                            j--;
                            wrongList[i].intTimes++;
                        }
                    }
                for (int i = 0; i < groupList.Count; i++)
                    for (int j = i + 1; j < groupList.Count; j++)
                    {
                        if (groupList[i].intLevel == groupList[j].intLevel)
                            if (groupList[i].strType == groupList[j].strType)
                            {
                                groupList.RemoveAt(j);
                                j--;
                                groupList[i].times++;
                            }
                    }
                    // 
                //if (sfdJCD.ShowDialog() == DialogResult.OK)
                //{

                TK.exportToExcelFile(sfdJCD.FileName, wrongList, groupList);
                MessageBox.Show("Xuất file thành công!", "Thông tin", MessageBoxButtons.OK);
                //}

                this.Show();
            }
            //}
            catch (Exception ex)
            {
                this.Show();
            }
        }

        private void txtFrom_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar) ||
                char.IsSymbol(e.KeyChar) ||
                char.IsWhiteSpace(e.KeyChar) ||
                char.IsPunctuation(e.KeyChar))
                    e.Handled = true;
        }

        private void txtTo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar) ||
                char.IsSymbol(e.KeyChar) ||
                char.IsWhiteSpace(e.KeyChar) ||
                char.IsPunctuation(e.KeyChar))
                    e.Handled = true;
        }
    }
}

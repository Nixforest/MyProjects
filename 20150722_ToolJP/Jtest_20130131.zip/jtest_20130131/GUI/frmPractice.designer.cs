﻿namespace JTest.GUI
{
    partial class frmPractice
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPractice));
            this.rtbCauHoi = new System.Windows.Forms.RichTextBox();
            this.lbSTTCau = new System.Windows.Forms.Label();
            this.gbLuyenTap = new System.Windows.Forms.GroupBox();
            this.picHint = new System.Windows.Forms.PictureBox();
            this.lbSocau = new System.Windows.Forms.Label();
            this.cbTuDongSangCauSau = new System.Windows.Forms.CheckBox();
            this.cbTuDongHienKetQua = new System.Windows.Forms.CheckBox();
            this.pbKetQua = new System.Windows.Forms.PictureBox();
            this.lbDapAnDungValue = new System.Windows.Forms.Label();
            this.lbDapAnDung = new System.Windows.Forms.Label();
            this.btXemKetQua = new System.Windows.Forms.Button();
            this.btNext = new System.Windows.Forms.Button();
            this.btPrevious = new System.Windows.Forms.Button();
            this.gbChonDapAn = new System.Windows.Forms.GroupBox();
            this.rbDapAnD = new System.Windows.Forms.RadioButton();
            this.rbDapAnC = new System.Windows.Forms.RadioButton();
            this.rbDapAnB = new System.Windows.Forms.RadioButton();
            this.rbDapAnA = new System.Windows.Forms.RadioButton();
            this.btKetThuc = new System.Windows.Forms.Button();
            this.lbSoCauDung = new System.Windows.Forms.Label();
            this.gbThongTinLuyenTap = new System.Windows.Forms.GroupBox();
            this.lblDanhHieu = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.ptbAvatar = new System.Windows.Forms.PictureBox();
            this.lbTenCSDL = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lbCauKetThuc = new System.Windows.Forms.Label();
            this.lbCauBatDau = new System.Windows.Forms.Label();
            this.lbThongKeCauDung = new System.Windows.Forms.Label();
            this.lbThongKeCauDaLam = new System.Windows.Forms.Label();
            this.lb8 = new System.Windows.Forms.Label();
            this.lbKieuRaDe = new System.Windows.Forms.Label();
            this.lbCapDo = new System.Windows.Forms.Label();
            this.lbNoiDung = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lb5 = new System.Windows.Forms.Label();
            this.lb6 = new System.Windows.Forms.Label();
            this.lb7 = new System.Windows.Forms.Label();
            this.pbBanner = new System.Windows.Forms.PictureBox();
            this.lblLevel = new System.Windows.Forms.Label();
            this.prgbLevel = new System.Windows.Forms.ProgressBar();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblMaxPoint = new System.Windows.Forms.Label();
            this.tltpHint = new System.Windows.Forms.ToolTip(this.components);
            this.lblKotowazaText = new System.Windows.Forms.Label();
            this.gbLuyenTap.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picHint)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbKetQua)).BeginInit();
            this.gbChonDapAn.SuspendLayout();
            this.gbThongTinLuyenTap.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ptbAvatar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbBanner)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // rtbCauHoi
            // 
            this.rtbCauHoi.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.rtbCauHoi.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.rtbCauHoi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.rtbCauHoi.Location = new System.Drawing.Point(6, 43);
            this.rtbCauHoi.Name = "rtbCauHoi";
            this.rtbCauHoi.ReadOnly = true;
            this.rtbCauHoi.Size = new System.Drawing.Size(627, 217);
            this.rtbCauHoi.TabIndex = 1;
            this.rtbCauHoi.Text = "";
            this.rtbCauHoi.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this._KeyPress);
            // 
            // lbSTTCau
            // 
            this.lbSTTCau.AutoSize = true;
            this.lbSTTCau.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbSTTCau.ForeColor = System.Drawing.Color.Black;
            this.lbSTTCau.Location = new System.Drawing.Point(6, 22);
            this.lbSTTCau.Name = "lbSTTCau";
            this.lbSTTCau.Size = new System.Drawing.Size(48, 18);
            this.lbSTTCau.TabIndex = 2;
            this.lbSTTCau.Text = "Câu: ";
            // 
            // gbLuyenTap
            // 
            this.gbLuyenTap.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.gbLuyenTap.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.gbLuyenTap.Controls.Add(this.picHint);
            this.gbLuyenTap.Controls.Add(this.lbSocau);
            this.gbLuyenTap.Controls.Add(this.cbTuDongSangCauSau);
            this.gbLuyenTap.Controls.Add(this.cbTuDongHienKetQua);
            this.gbLuyenTap.Controls.Add(this.pbKetQua);
            this.gbLuyenTap.Controls.Add(this.lbDapAnDungValue);
            this.gbLuyenTap.Controls.Add(this.lbDapAnDung);
            this.gbLuyenTap.Controls.Add(this.btXemKetQua);
            this.gbLuyenTap.Controls.Add(this.btNext);
            this.gbLuyenTap.Controls.Add(this.btPrevious);
            this.gbLuyenTap.Controls.Add(this.gbChonDapAn);
            this.gbLuyenTap.Controls.Add(this.rtbCauHoi);
            this.gbLuyenTap.Controls.Add(this.lbSTTCau);
            this.gbLuyenTap.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.gbLuyenTap.Location = new System.Drawing.Point(367, 112);
            this.gbLuyenTap.Name = "gbLuyenTap";
            this.gbLuyenTap.Size = new System.Drawing.Size(639, 433);
            this.gbLuyenTap.TabIndex = 4;
            this.gbLuyenTap.TabStop = false;
            this.gbLuyenTap.Text = "Luyện tập";
            // 
            // picHint
            // 
            this.picHint.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.picHint.Image = global::JTest.Properties.Resources.meo;
            this.picHint.Location = new System.Drawing.Point(78, 333);
            this.picHint.Name = "picHint";
            this.picHint.Size = new System.Drawing.Size(41, 35);
            this.picHint.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picHint.TabIndex = 28;
            this.picHint.TabStop = false;
            // 
            // lbSocau
            // 
            this.lbSocau.AutoSize = true;
            this.lbSocau.ForeColor = System.Drawing.Color.Black;
            this.lbSocau.Location = new System.Drawing.Point(60, 20);
            this.lbSocau.Name = "lbSocau";
            this.lbSocau.Size = new System.Drawing.Size(19, 20);
            this.lbSocau.TabIndex = 26;
            this.lbSocau.Text = "1";
            // 
            // cbTuDongSangCauSau
            // 
            this.cbTuDongSangCauSau.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.cbTuDongSangCauSau.AutoSize = true;
            this.cbTuDongSangCauSau.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.cbTuDongSangCauSau.ForeColor = System.Drawing.Color.Black;
            this.cbTuDongSangCauSau.Location = new System.Drawing.Point(114, 374);
            this.cbTuDongSangCauSau.Name = "cbTuDongSangCauSau";
            this.cbTuDongSangCauSau.Size = new System.Drawing.Size(277, 22);
            this.cbTuDongSangCauSau.TabIndex = 25;
            this.cbTuDongSangCauSau.Text = "Tự động sang câu sau nếu trả lời đúng";
            this.cbTuDongSangCauSau.UseVisualStyleBackColor = true;
            this.cbTuDongSangCauSau.CheckStateChanged += new System.EventHandler(this.cbTuDongSangCauSau_CheckStateChanged);
            this.cbTuDongSangCauSau.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this._KeyPress);
            // 
            // cbTuDongHienKetQua
            // 
            this.cbTuDongHienKetQua.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.cbTuDongHienKetQua.AutoSize = true;
            this.cbTuDongHienKetQua.Enabled = false;
            this.cbTuDongHienKetQua.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.cbTuDongHienKetQua.ForeColor = System.Drawing.Color.Black;
            this.cbTuDongHienKetQua.Location = new System.Drawing.Point(114, 402);
            this.cbTuDongHienKetQua.Name = "cbTuDongHienKetQua";
            this.cbTuDongHienKetQua.Size = new System.Drawing.Size(164, 22);
            this.cbTuDongHienKetQua.TabIndex = 25;
            this.cbTuDongHienKetQua.Text = "Tự động hiện kết quả";
            this.cbTuDongHienKetQua.UseVisualStyleBackColor = true;
            this.cbTuDongHienKetQua.CheckedChanged += new System.EventHandler(this.cbTuDongHienKetQua_CheckedChanged);
            this.cbTuDongHienKetQua.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this._KeyPress);
            // 
            // pbKetQua
            // 
            this.pbKetQua.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.pbKetQua.Image = global::JTest.Properties.Resources.question;
            this.pbKetQua.Location = new System.Drawing.Point(463, 266);
            this.pbKetQua.Name = "pbKetQua";
            this.pbKetQua.Size = new System.Drawing.Size(140, 134);
            this.pbKetQua.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbKetQua.TabIndex = 24;
            this.pbKetQua.TabStop = false;
            // 
            // lbDapAnDungValue
            // 
            this.lbDapAnDungValue.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lbDapAnDungValue.AutoSize = true;
            this.lbDapAnDungValue.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbDapAnDungValue.ForeColor = System.Drawing.Color.Red;
            this.lbDapAnDungValue.Location = new System.Drawing.Point(582, 223);
            this.lbDapAnDungValue.Name = "lbDapAnDungValue";
            this.lbDapAnDungValue.Size = new System.Drawing.Size(21, 20);
            this.lbDapAnDungValue.TabIndex = 23;
            this.lbDapAnDungValue.Text = "A";
            // 
            // lbDapAnDung
            // 
            this.lbDapAnDung.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lbDapAnDung.AutoSize = true;
            this.lbDapAnDung.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbDapAnDung.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbDapAnDung.ForeColor = System.Drawing.Color.Black;
            this.lbDapAnDung.Location = new System.Drawing.Point(459, 223);
            this.lbDapAnDung.Name = "lbDapAnDung";
            this.lbDapAnDung.Size = new System.Drawing.Size(117, 20);
            this.lbDapAnDung.TabIndex = 22;
            this.lbDapAnDung.Text = "Đáp án đúng:";
            // 
            // btXemKetQua
            // 
            this.btXemKetQua.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btXemKetQua.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btXemKetQua.ForeColor = System.Drawing.Color.Black;
            this.btXemKetQua.Location = new System.Drawing.Point(282, 334);
            this.btXemKetQua.Name = "btXemKetQua";
            this.btXemKetQua.Size = new System.Drawing.Size(100, 26);
            this.btXemKetQua.TabIndex = 12;
            this.btXemKetQua.Text = "Xem kết quả";
            this.btXemKetQua.UseVisualStyleBackColor = true;
            this.btXemKetQua.Click += new System.EventHandler(this.btXemKetQua_Click);
            this.btXemKetQua.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this._KeyPress);
            // 
            // btNext
            // 
            this.btNext.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btNext.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btNext.ForeColor = System.Drawing.Color.Black;
            this.btNext.Location = new System.Drawing.Point(214, 334);
            this.btNext.Name = "btNext";
            this.btNext.Size = new System.Drawing.Size(37, 26);
            this.btNext.TabIndex = 17;
            this.btNext.Text = ">";
            this.btNext.UseVisualStyleBackColor = true;
            this.btNext.Click += new System.EventHandler(this.btNext_Click);
            this.btNext.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this._KeyPress);
            // 
            // btPrevious
            // 
            this.btPrevious.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btPrevious.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btPrevious.ForeColor = System.Drawing.Color.Black;
            this.btPrevious.Location = new System.Drawing.Point(145, 334);
            this.btPrevious.Name = "btPrevious";
            this.btPrevious.Size = new System.Drawing.Size(35, 26);
            this.btPrevious.TabIndex = 16;
            this.btPrevious.Text = "<";
            this.btPrevious.UseVisualStyleBackColor = true;
            this.btPrevious.Click += new System.EventHandler(this.btPrevious_Click);
            this.btPrevious.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this._KeyPress);
            // 
            // gbChonDapAn
            // 
            this.gbChonDapAn.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.gbChonDapAn.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.gbChonDapAn.Controls.Add(this.rbDapAnD);
            this.gbChonDapAn.Controls.Add(this.rbDapAnC);
            this.gbChonDapAn.Controls.Add(this.rbDapAnB);
            this.gbChonDapAn.Controls.Add(this.rbDapAnA);
            this.gbChonDapAn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.gbChonDapAn.Location = new System.Drawing.Point(78, 266);
            this.gbChonDapAn.Name = "gbChonDapAn";
            this.gbChonDapAn.Size = new System.Drawing.Size(304, 62);
            this.gbChonDapAn.TabIndex = 11;
            this.gbChonDapAn.TabStop = false;
            this.gbChonDapAn.Text = "Chọn đáp án:";
            // 
            // rbDapAnD
            // 
            this.rbDapAnD.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.rbDapAnD.AutoSize = true;
            this.rbDapAnD.ForeColor = System.Drawing.Color.Black;
            this.rbDapAnD.Location = new System.Drawing.Point(243, 29);
            this.rbDapAnD.Name = "rbDapAnD";
            this.rbDapAnD.Size = new System.Drawing.Size(36, 20);
            this.rbDapAnD.TabIndex = 3;
            this.rbDapAnD.Text = "D";
            this.rbDapAnD.UseVisualStyleBackColor = true;
            this.rbDapAnD.CheckedChanged += new System.EventHandler(this.rbDapAnD_CheckedChanged);
            this.rbDapAnD.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this._KeyPress);
            // 
            // rbDapAnC
            // 
            this.rbDapAnC.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.rbDapAnC.AutoSize = true;
            this.rbDapAnC.ForeColor = System.Drawing.Color.Black;
            this.rbDapAnC.Location = new System.Drawing.Point(174, 29);
            this.rbDapAnC.Name = "rbDapAnC";
            this.rbDapAnC.Size = new System.Drawing.Size(35, 20);
            this.rbDapAnC.TabIndex = 2;
            this.rbDapAnC.Text = "C";
            this.rbDapAnC.UseVisualStyleBackColor = true;
            this.rbDapAnC.CheckedChanged += new System.EventHandler(this.rbDapAnC_CheckedChanged);
            this.rbDapAnC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this._KeyPress);
            // 
            // rbDapAnB
            // 
            this.rbDapAnB.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.rbDapAnB.AutoSize = true;
            this.rbDapAnB.Checked = true;
            this.rbDapAnB.ForeColor = System.Drawing.Color.Black;
            this.rbDapAnB.Location = new System.Drawing.Point(101, 29);
            this.rbDapAnB.Name = "rbDapAnB";
            this.rbDapAnB.Size = new System.Drawing.Size(35, 20);
            this.rbDapAnB.TabIndex = 1;
            this.rbDapAnB.TabStop = true;
            this.rbDapAnB.Text = "B";
            this.rbDapAnB.UseVisualStyleBackColor = true;
            this.rbDapAnB.CheckedChanged += new System.EventHandler(this.rbDapAnB_CheckedChanged);
            this.rbDapAnB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this._KeyPress);
            // 
            // rbDapAnA
            // 
            this.rbDapAnA.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.rbDapAnA.AutoSize = true;
            this.rbDapAnA.ForeColor = System.Drawing.Color.Black;
            this.rbDapAnA.Location = new System.Drawing.Point(34, 29);
            this.rbDapAnA.Name = "rbDapAnA";
            this.rbDapAnA.Size = new System.Drawing.Size(35, 20);
            this.rbDapAnA.TabIndex = 0;
            this.rbDapAnA.Text = "A";
            this.rbDapAnA.UseVisualStyleBackColor = true;
            this.rbDapAnA.CheckedChanged += new System.EventHandler(this.rbDapAnA_CheckedChanged);
            this.rbDapAnA.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this._KeyPress);
            // 
            // btKetThuc
            // 
            this.btKetThuc.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btKetThuc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btKetThuc.ForeColor = System.Drawing.Color.Black;
            this.btKetThuc.Location = new System.Drawing.Point(897, 571);
            this.btKetThuc.Name = "btKetThuc";
            this.btKetThuc.Size = new System.Drawing.Size(93, 32);
            this.btKetThuc.TabIndex = 5;
            this.btKetThuc.Text = "Kết thúc";
            this.btKetThuc.UseVisualStyleBackColor = true;
            this.btKetThuc.Click += new System.EventHandler(this.btKetThuc_Click);
            // 
            // lbSoCauDung
            // 
            this.lbSoCauDung.AutoSize = true;
            this.lbSoCauDung.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbSoCauDung.ForeColor = System.Drawing.Color.Black;
            this.lbSoCauDung.Location = new System.Drawing.Point(7, 118);
            this.lbSoCauDung.Name = "lbSoCauDung";
            this.lbSoCauDung.Size = new System.Drawing.Size(98, 16);
            this.lbSoCauDung.TabIndex = 6;
            this.lbSoCauDung.Text = "Số câu đúng:";
            // 
            // gbThongTinLuyenTap
            // 
            this.gbThongTinLuyenTap.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.gbThongTinLuyenTap.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.gbThongTinLuyenTap.Controls.Add(this.lblDanhHieu);
            this.gbThongTinLuyenTap.Controls.Add(this.label1);
            this.gbThongTinLuyenTap.Controls.Add(this.ptbAvatar);
            this.gbThongTinLuyenTap.Controls.Add(this.lbTenCSDL);
            this.gbThongTinLuyenTap.Controls.Add(this.label3);
            this.gbThongTinLuyenTap.Controls.Add(this.lbCauKetThuc);
            this.gbThongTinLuyenTap.Controls.Add(this.lbCauBatDau);
            this.gbThongTinLuyenTap.Controls.Add(this.lbThongKeCauDung);
            this.gbThongTinLuyenTap.Controls.Add(this.lbThongKeCauDaLam);
            this.gbThongTinLuyenTap.Controls.Add(this.lb8);
            this.gbThongTinLuyenTap.Controls.Add(this.lbKieuRaDe);
            this.gbThongTinLuyenTap.Controls.Add(this.lbCapDo);
            this.gbThongTinLuyenTap.Controls.Add(this.lbNoiDung);
            this.gbThongTinLuyenTap.Controls.Add(this.label4);
            this.gbThongTinLuyenTap.Controls.Add(this.label2);
            this.gbThongTinLuyenTap.Controls.Add(this.lbSoCauDung);
            this.gbThongTinLuyenTap.Controls.Add(this.lb5);
            this.gbThongTinLuyenTap.Controls.Add(this.lb6);
            this.gbThongTinLuyenTap.Controls.Add(this.lb7);
            this.gbThongTinLuyenTap.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.gbThongTinLuyenTap.Location = new System.Drawing.Point(12, 110);
            this.gbThongTinLuyenTap.Name = "gbThongTinLuyenTap";
            this.gbThongTinLuyenTap.Size = new System.Drawing.Size(349, 435);
            this.gbThongTinLuyenTap.TabIndex = 12;
            this.gbThongTinLuyenTap.TabStop = false;
            this.gbThongTinLuyenTap.Text = "Thông tin luyện tập";
            // 
            // lblDanhHieu
            // 
            this.lblDanhHieu.AutoSize = true;
            this.lblDanhHieu.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblDanhHieu.ForeColor = System.Drawing.Color.Black;
            this.lblDanhHieu.Location = new System.Drawing.Point(80, 404);
            this.lblDanhHieu.Name = "lblDanhHieu";
            this.lblDanhHieu.Size = new System.Drawing.Size(50, 16);
            this.lblDanhHieu.TabIndex = 27;
            this.lblDanhHieu.Text = "Lính Lệ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(8, 404);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 16);
            this.label1.TabIndex = 26;
            this.label1.Text = "Chức vụ:";
            // 
            // ptbAvatar
            // 
            this.ptbAvatar.InitialImage = null;
            this.ptbAvatar.Location = new System.Drawing.Point(11, 137);
            this.ptbAvatar.Name = "ptbAvatar";
            this.ptbAvatar.Size = new System.Drawing.Size(332, 261);
            this.ptbAvatar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.ptbAvatar.TabIndex = 0;
            this.ptbAvatar.TabStop = false;
            // 
            // lbTenCSDL
            // 
            this.lbTenCSDL.AutoSize = true;
            this.lbTenCSDL.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbTenCSDL.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lbTenCSDL.Location = new System.Drawing.Point(175, 22);
            this.lbTenCSDL.Name = "lbTenCSDL";
            this.lbTenCSDL.Size = new System.Drawing.Size(31, 16);
            this.lbTenCSDL.TabIndex = 25;
            this.lbTenCSDL.Text = "N/A";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(7, 22);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(86, 16);
            this.label3.TabIndex = 24;
            this.label3.Text = "Tên CSDL: ";
            // 
            // lbCauKetThuc
            // 
            this.lbCauKetThuc.AutoSize = true;
            this.lbCauKetThuc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbCauKetThuc.ForeColor = System.Drawing.Color.Black;
            this.lbCauKetThuc.Location = new System.Drawing.Point(244, 86);
            this.lbCauKetThuc.Name = "lbCauKetThuc";
            this.lbCauKetThuc.Size = new System.Drawing.Size(29, 16);
            this.lbCauKetThuc.TabIndex = 23;
            this.lbCauKetThuc.Text = "400";
            // 
            // lbCauBatDau
            // 
            this.lbCauBatDau.AutoSize = true;
            this.lbCauBatDau.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbCauBatDau.ForeColor = System.Drawing.Color.Black;
            this.lbCauBatDau.Location = new System.Drawing.Point(175, 86);
            this.lbCauBatDau.Name = "lbCauBatDau";
            this.lbCauBatDau.Size = new System.Drawing.Size(29, 16);
            this.lbCauBatDau.TabIndex = 22;
            this.lbCauBatDau.Text = "150";
            // 
            // lbThongKeCauDung
            // 
            this.lbThongKeCauDung.AutoSize = true;
            this.lbThongKeCauDung.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbThongKeCauDung.ForeColor = System.Drawing.Color.Black;
            this.lbThongKeCauDung.Location = new System.Drawing.Point(175, 118);
            this.lbThongKeCauDung.Name = "lbThongKeCauDung";
            this.lbThongKeCauDung.Size = new System.Drawing.Size(83, 16);
            this.lbThongKeCauDung.TabIndex = 21;
            this.lbThongKeCauDung.Text = "15 / 20 (75%)";
            // 
            // lbThongKeCauDaLam
            // 
            this.lbThongKeCauDaLam.AutoSize = true;
            this.lbThongKeCauDaLam.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbThongKeCauDaLam.ForeColor = System.Drawing.Color.Black;
            this.lbThongKeCauDaLam.Location = new System.Drawing.Point(175, 102);
            this.lbThongKeCauDaLam.Name = "lbThongKeCauDaLam";
            this.lbThongKeCauDaLam.Size = new System.Drawing.Size(53, 16);
            this.lbThongKeCauDaLam.TabIndex = 20;
            this.lbThongKeCauDaLam.Text = "20 / 250";
            // 
            // lb8
            // 
            this.lb8.AutoSize = true;
            this.lb8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lb8.ForeColor = System.Drawing.Color.Black;
            this.lb8.Location = new System.Drawing.Point(207, 86);
            this.lb8.Name = "lb8";
            this.lb8.Size = new System.Drawing.Size(31, 16);
            this.lb8.TabIndex = 18;
            this.lb8.Text = "đến";
            // 
            // lbKieuRaDe
            // 
            this.lbKieuRaDe.AutoSize = true;
            this.lbKieuRaDe.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbKieuRaDe.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lbKieuRaDe.Location = new System.Drawing.Point(175, 70);
            this.lbKieuRaDe.Name = "lbKieuRaDe";
            this.lbKieuRaDe.Size = new System.Drawing.Size(76, 16);
            this.lbKieuRaDe.TabIndex = 17;
            this.lbKieuRaDe.Text = "Ngẫu nhiên";
            // 
            // lbCapDo
            // 
            this.lbCapDo.AutoSize = true;
            this.lbCapDo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbCapDo.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lbCapDo.Location = new System.Drawing.Point(175, 54);
            this.lbCapDo.Name = "lbCapDo";
            this.lbCapDo.Size = new System.Drawing.Size(25, 16);
            this.lbCapDo.TabIndex = 16;
            this.lbCapDo.Text = "N3";
            // 
            // lbNoiDung
            // 
            this.lbNoiDung.AutoSize = true;
            this.lbNoiDung.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbNoiDung.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lbNoiDung.Location = new System.Drawing.Point(175, 38);
            this.lbNoiDung.Name = "lbNoiDung";
            this.lbNoiDung.Size = new System.Drawing.Size(67, 16);
            this.lbNoiDung.TabIndex = 15;
            this.lbNoiDung.Text = "Ngữ pháp";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(6, 102);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(111, 16);
            this.label4.TabIndex = 13;
            this.label4.Text = "Số câu đã làm:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(6, 86);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(163, 16);
            this.label2.TabIndex = 9;
            this.label2.Text = "Phạm vi câu luyện tập:";
            // 
            // lb5
            // 
            this.lb5.AutoSize = true;
            this.lb5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lb5.ForeColor = System.Drawing.Color.Black;
            this.lb5.Location = new System.Drawing.Point(7, 70);
            this.lb5.Name = "lb5";
            this.lb5.Size = new System.Drawing.Size(82, 16);
            this.lb5.TabIndex = 2;
            this.lb5.Text = "Kiểu ra đề:";
            // 
            // lb6
            // 
            this.lb6.AutoSize = true;
            this.lb6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lb6.ForeColor = System.Drawing.Color.Black;
            this.lb6.Location = new System.Drawing.Point(7, 54);
            this.lb6.Name = "lb6";
            this.lb6.Size = new System.Drawing.Size(66, 16);
            this.lb6.TabIndex = 1;
            this.lb6.Text = "Cấp độ: ";
            // 
            // lb7
            // 
            this.lb7.AutoSize = true;
            this.lb7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lb7.ForeColor = System.Drawing.Color.Black;
            this.lb7.Location = new System.Drawing.Point(7, 38);
            this.lb7.Name = "lb7";
            this.lb7.Size = new System.Drawing.Size(141, 16);
            this.lb7.TabIndex = 0;
            this.lb7.Text = "Nội dung luyện tập:";
            // 
            // pbBanner
            // 
            this.pbBanner.BackColor = System.Drawing.Color.Transparent;
            this.pbBanner.Dock = System.Windows.Forms.DockStyle.Top;
            this.pbBanner.Image = global::JTest.Properties.Resources.banner_jtest_2;
            this.pbBanner.Location = new System.Drawing.Point(0, 0);
            this.pbBanner.Name = "pbBanner";
            this.pbBanner.Size = new System.Drawing.Size(1008, 106);
            this.pbBanner.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbBanner.TabIndex = 13;
            this.pbBanner.TabStop = false;
            // 
            // lblLevel
            // 
            this.lblLevel.AutoSize = true;
            this.lblLevel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblLevel.ForeColor = System.Drawing.Color.Red;
            this.lblLevel.Location = new System.Drawing.Point(7, 22);
            this.lblLevel.Name = "lblLevel";
            this.lblLevel.Size = new System.Drawing.Size(21, 24);
            this.lblLevel.TabIndex = 26;
            this.lblLevel.Text = "0";
            // 
            // prgbLevel
            // 
            this.prgbLevel.Location = new System.Drawing.Point(62, 19);
            this.prgbLevel.Name = "prgbLevel";
            this.prgbLevel.Size = new System.Drawing.Size(646, 23);
            this.prgbLevel.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.prgbLevel.TabIndex = 28;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblMaxPoint);
            this.groupBox1.Controls.Add(this.prgbLevel);
            this.groupBox1.Controls.Add(this.lblLevel);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(12, 551);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(833, 52);
            this.groupBox1.TabIndex = 15;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Level";
            // 
            // lblMaxPoint
            // 
            this.lblMaxPoint.AutoSize = true;
            this.lblMaxPoint.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblMaxPoint.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblMaxPoint.Location = new System.Drawing.Point(742, 22);
            this.lblMaxPoint.Name = "lblMaxPoint";
            this.lblMaxPoint.Size = new System.Drawing.Size(26, 16);
            this.lblMaxPoint.TabIndex = 29;
            this.lblMaxPoint.Text = "0/5";
            // 
            // tltpHint
            // 
            this.tltpHint.AutoPopDelay = 32768;
            this.tltpHint.InitialDelay = 500;
            this.tltpHint.IsBalloon = true;
            this.tltpHint.ReshowDelay = 100;
            // 
            // lblKotowazaText
            // 
            this.lblKotowazaText.AutoSize = true;
            this.lblKotowazaText.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblKotowazaText.Location = new System.Drawing.Point(612, 52);
            this.lblKotowazaText.Name = "lblKotowazaText";
            this.lblKotowazaText.Size = new System.Drawing.Size(242, 39);
            this.lblKotowazaText.TabIndex = 16;
            this.lblKotowazaText.Text = "頑張ってください";
            this.lblKotowazaText.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // frmPractice
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(1008, 615);
            this.Controls.Add(this.lblKotowazaText);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.pbBanner);
            this.Controls.Add(this.gbThongTinLuyenTap);
            this.Controls.Add(this.gbLuyenTap);
            this.Controls.Add(this.btKetThuc);
            this.ForeColor = System.Drawing.Color.Red;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1024, 685);
            this.MinimumSize = new System.Drawing.Size(868, 568);
            this.Name = "frmPractice";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Luyện tập";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frLuyenTap_FormClosing);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this._KeyPress);
            this.gbLuyenTap.ResumeLayout(false);
            this.gbLuyenTap.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picHint)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbKetQua)).EndInit();
            this.gbChonDapAn.ResumeLayout(false);
            this.gbChonDapAn.PerformLayout();
            this.gbThongTinLuyenTap.ResumeLayout(false);
            this.gbThongTinLuyenTap.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ptbAvatar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbBanner)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox rtbCauHoi;
        private System.Windows.Forms.Label lbSTTCau;
        private System.Windows.Forms.GroupBox gbLuyenTap;
        private System.Windows.Forms.Button btKetThuc;
        private System.Windows.Forms.Label lbSoCauDung;
        private System.Windows.Forms.GroupBox gbThongTinLuyenTap;
        private System.Windows.Forms.Label lb5;
        private System.Windows.Forms.Label lb6;
        private System.Windows.Forms.Label lb7;
        private System.Windows.Forms.GroupBox gbChonDapAn;
        private System.Windows.Forms.RadioButton rbDapAnD;
        private System.Windows.Forms.RadioButton rbDapAnC;
        private System.Windows.Forms.RadioButton rbDapAnB;
        private System.Windows.Forms.RadioButton rbDapAnA;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btXemKetQua;
        private System.Windows.Forms.Label lbKieuRaDe;
        private System.Windows.Forms.Label lbCapDo;
        private System.Windows.Forms.Label lbNoiDung;
        private System.Windows.Forms.Label lb8;
        private System.Windows.Forms.Label lbThongKeCauDung;
        private System.Windows.Forms.Label lbThongKeCauDaLam;
        private System.Windows.Forms.Button btNext;
        private System.Windows.Forms.Button btPrevious;
        private System.Windows.Forms.Label lbDapAnDung;
        private System.Windows.Forms.Label lbCauKetThuc;
        private System.Windows.Forms.Label lbCauBatDau;
        private System.Windows.Forms.Label lbDapAnDungValue;
        private System.Windows.Forms.PictureBox pbKetQua;
        private System.Windows.Forms.PictureBox pbBanner;
        private System.Windows.Forms.CheckBox cbTuDongHienKetQua;
        private System.Windows.Forms.Label lbTenCSDL;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox cbTuDongSangCauSau;
        private System.Windows.Forms.Label lbSocau;
        private System.Windows.Forms.Label lblLevel;
        private System.Windows.Forms.ProgressBar prgbLevel;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblMaxPoint;
        private System.Windows.Forms.PictureBox ptbAvatar;
        private System.Windows.Forms.PictureBox picHint;
        private System.Windows.Forms.ToolTip tltpHint;
        private System.Windows.Forms.Label lblDanhHieu;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblKotowazaText;
    }
}
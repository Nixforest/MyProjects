﻿//////////////////////////////////////////////////////
// Edit Database form                               //
//                                                  //        
// KhanhNX2                                         //
//                                                  //
//////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Text.RegularExpressions;
using System.Collections;
using JTest;
using JTest.Others;
using JTest.GUI;
using JTest.DTO;
using JTest.DAO;
using JTest.BUS;
using System.Data.OleDb;
using System.Xml;

namespace JTest.GUI
{
    public partial class frmEditDB : Form
    {
        SettingsPractiseDTO settingPractice = new SettingsPractiseDTO();
        PracticeBUS pBUS = new PracticeBUS();
        List<string> lisTablesName = new List<string>();
        List<QuestionDTO> questionList;//mang cac cau hoi
        static SettingsDTO s;
        string strTableName;
        string strtype;
        int maxId;
        int minId;
        int level;
        int inttype;
        int curId;
        bool IsChanged;
        bool Recursive;
        bool IsFirstLoad;
        string strComment = "";

        public frmEditDB(string strCSDL, string strCapDo, string strNoiDung, int currentID)
        {
            InitializeComponent();
            IsFirstLoad = true;
            //++KhanhNX2
            //load list DB for cmbDB
            s = SettingsBUS.loadSettingInfoFromFile();
            //cmbDB.DataSource = SettingsBUS.loadDbaseSources();
            List<string> list = new List<string>();
            list.Add(strCSDL);
            cmbDB.DataSource = list;
            //cmbDB.Items.Add(
            cmbDB.SelectedItem = s.Database;
            addcbLevelItems();
            level = (strCapDo == "N1") ? 1 : (strCapDo == "N2/N3") ? 2 : (strCapDo == "N4") ? 3 : 4;
//          cmbLevel.SelectedIndex = level - 1;     //DEL, 14/01/2012, KYNX
            cmbLevel.SelectedIndex = 0;             //ADD, 14/01/2012, KYNX
            curId = currentID;
            nmID.Value = curId;

            //nmID.Value = curId;

            List<ComboBoxItem> items = new List<ComboBoxItem>();
            items.Add(new ComboBoxItem("Ngữ pháp", "Ngữ pháp"));
            items.Add(new ComboBoxItem("Từ vựng", "Từ vựng"));
            cmbType.ValueMember = "Value";
            cmbType.DisplayMember = "Display";
            cmbType.DataSource = items;
            if (strNoiDung == Constant.strVocabulary)
            {
                cmbType.SelectedIndex = 1;
            }
            else
            {
                cmbType.SelectedIndex = 0;
            }
            //level = 0;
            strtype = "";
            inttype = 0;
            convertCbValue(ref level, ref strtype);

            if (strtype == "vocabulary")
                inttype = 1;
            else
                inttype = 2;

            strTableName = strtype + "level" + level;
            maxId = pBUS.getMaxID(strTableName);
            minId = 1;

            //select init DB and QuestID

            //load init info of selected Quest
            questionList = PracticeBUS.getQuestionListInSuccessionOrder(minId, maxId, level, strtype);

            ShowQuestInfo();
            IsChanged = false;
            Recursive = true;
            IsFirstLoad = false;
            //--KhanhNX2
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            lblStatus.Text = "Updating"; //ADD, 14/01/2012, KYNX
            //update question list
            UpdateQuestInfo();

            //update DB
            bool bRet = UpdateDB();

            IsChanged = false;
            if(bRet) lblStatus.Text = "Done"; //ADD, 14/01/2012, KYNX
            else lblStatus.Text = "Failed";   //ADD, 14/01/2012, KYNX
        }

        private bool UpdateDB()
        {
            bool result = false;
            bool result2 = false; //ADD, 14/01/2012, KYNX
            try
            {
                string connStr = "Provider = Microsoft.Jet.OLEDB.4.0; Jet OLEDB:Database Password=" + JTest.Constant.DBPassWord + "; Data Source = " + AppDomain.CurrentDomain.BaseDirectory + "App_Data\\" + cmbDB.SelectedItem.ToString();
                using (OleDbConnection conn = DataProvider.openConnection(connStr))
                {

                    strTableName = strtype + "level" + level;
                    string strSQL = "UPDATE " + strTableName + " ";
                    strSQL += "SET " + "question = '" + questionList[curId - 1].Question + "'";
                    strSQL += " , " + "A = '" + questionList[curId - 1].AnswerA + "'";
                    strSQL += " , " + "B = '" + questionList[curId - 1].AnswerB + "'";
                    strSQL += " , " + "C = '" + questionList[curId - 1].AnswerC + "'";
                    strSQL += " , " + "D = '" + questionList[curId - 1].AnswerD + "'";
                    strSQL += " , " + "answer = '" + questionList[curId - 1].Answer + "'";
                    strSQL += " WHERE " + strTableName + ".id = " + curId.ToString();

                    OleDbCommand cmd = new OleDbCommand();
                    cmd.Connection = conn;
                    cmd.CommandText = strSQL;
                    int rs = cmd.ExecuteNonQuery();

                    result = (rs == 1) ? true : false;

////{{ADD_HEAD, 14/01/2012, KYNX
                    if (result == true)
                    {
                        if (txtHint.Text.Trim() != strComment)
                        {
                            CommentDTO q = new CommentDTO();
                            q.TableName = strTableName;
                            q.Id = curId.ToString();
                            q.Comment = txtHint.Text.Trim();

                            if (!CommentDAO.checkExistTable(connStr))
                            {
                                CommentDAO.createTable(connStr);
                            }
                            if (CommentDAO.select(q.TableName, q.Id, connStr) == null)
                            {
                                result2 = CommentDAO.insert(connStr, q);
                            }
                            else
                            {
                                result2 = CommentDAO.update(q, connStr);
                            }

                            if (result2) strComment = q.Comment;
                        }
                        else
                        {
                            result2 = true;
                        }
                    }
////}}ADD_TAIL, 14/01/2012, KYNX
                }

            }
            catch (OleDbException ex)
            {
                throw ex;
            }
            return (result && result2);
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();   //ADD, 14/01/2012, KYNX
        }

        //show question info
        private void ShowQuestInfo()
        {
            if (questionList.Count < curId)
                return;
            txtQuestion.Text = questionList[curId - 1].Question;
            txtAnsA.Text = questionList[curId - 1].AnswerA;
            txtAnsB.Text = questionList[curId - 1].AnswerB;
            txtAnsC.Text = questionList[curId - 1].AnswerC;
            txtAnsD.Text = questionList[curId - 1].AnswerD;
            txtAnswer.Text = questionList[curId - 1].Answer.ToString();

////{{ADD_HEAD, 14/01/2012, KYNX
            strComment = "";
            try
            {
                string connStr = "Provider = Microsoft.Jet.OLEDB.4.0; Jet OLEDB:Database Password=" + JTest.Constant.DBPassWord + "; Data Source = "
                                + AppDomain.CurrentDomain.BaseDirectory + "App_Data\\" + cmbDB.SelectedItem.ToString();
                using (OleDbConnection conn = DataProvider.openConnection(connStr))
                {
                    strTableName = strtype + "level" + level;
                    CommentDTO q = new CommentDTO();

                    if (CommentDAO.checkExistTable(connStr))
                    {
                        if ((q = CommentDAO.select(strTableName, curId.ToString(), connStr)) != null)
                        {
                            strComment = q.Comment;
                        }
                    }
                }
            }
            catch (OleDbException ex)
            {
                throw ex;
            }

            txtHint.Text = strComment;
////}}ADD_TAIL, 14/01/2012, KYNX
        }

        //update question info
        private void UpdateQuestInfo()
        {
            questionList[curId - 1].Question = txtQuestion.Text;
            questionList[curId - 1].AnswerA = txtAnsA.Text;
            questionList[curId - 1].AnswerB = txtAnsB.Text;
            questionList[curId - 1].AnswerC = txtAnsC.Text;
            questionList[curId - 1].AnswerD = txtAnsD.Text;
            questionList[curId - 1].Answer = txtAnswer.Text.ToCharArray()[0];
        }

        ///@author ToanNN
        /// <summary>
        /// thêm giá trị vào combobox dựa vào data hiện tại
        /// </summary>
        private void addcbLevelItems()
        {
            try
            {
                cmbLevel.Items.Clear();
                lisTablesName = command.getLevelList();
                foreach (string strlevel in lisTablesName)
                {
                    cmbLevel.Items.Add(strlevel);
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// @author ToanNN
        /// <summary>
        /// chuyển từ giá trị trên combobox sang tên table
        /// </summary>
        /// <param name="level"></param>
        /// <param name="type"></param>
        private void convertCbValue(ref int level, ref string type)
        {
            if (cmbLevel.Text == Constant.strN1)
            {
                level = 1;
            }
            else if (cmbLevel.Text == Constant.strN2_N3)
            {
                level = 2;
            }
            else if (cmbLevel.Text == Constant.strN4)
            {
                level = 3;
            }
            else
            {
                level = 4;
            }

            if (cmbType.Text == Constant.strVocabulary)
            {
                type = "vocabulary";
            }
            else if (cmbType.Text == Constant.strGrammer)
            {
                type = "grammar";
            }
        }

        private void IDChange(object sender, EventArgs e)
        {
            if (IsFirstLoad)
                return;
            if (Recursive == false)
                return;
            if (IsChanged)
            {
                //show confirm message
                DialogResult result = MessageBox.Show("Update changed contents to DB ?",
                                        "Update Database", MessageBoxButtons.YesNoCancel);
                if (result == DialogResult.Yes)
                {
                    btnSave_Click(sender, e);
                }
                else if (result == DialogResult.No)
                {

                }
                else
                {
                    Recursive = false;
                    nmID.Value = curId;
                    Recursive = true;
                    return;
                }
            }
            if (nmID.Value < minId)
            {
                nmID.Value = minId;
            }
            else if (nmID.Value > maxId)
            {
                nmID.Value = maxId;
            }
            curId = Int32.Parse(nmID.Value.ToString());
            ShowQuestInfo();
            IsChanged = false;
        }

        private void ChangeContent(object sender, EventArgs e)
        {
            IsChanged = true;
            lblStatus.Text = "";
        }

        private void ChangeTable(object sender, EventArgs e)
        {
            if (IsFirstLoad)
                return;
            convertCbValue(ref level, ref strtype);
            strTableName = strtype + "level" + level;
            maxId = pBUS.getMaxID(strTableName);
            minId = 1;
            questionList = PracticeBUS.getQuestionListInSuccessionOrder(minId, maxId, level, strtype);

            ShowQuestInfo();
            IsChanged = false;
            Recursive = true;
        }

        private void ChangeDatabase(object sender, EventArgs e)
        {
            if (IsFirstLoad)
                return;
            convertCbValue(ref level, ref strtype);
            strTableName = strtype + "level" + level;
            maxId = pBUS.getMaxID(strTableName);
            minId = 1;


            questionList = PracticeBUS.getQuestionListInSuccessionOrder(minId, maxId, level, strtype);

            ShowQuestInfo();
            IsChanged = false;
            Recursive = true;
        }
    }
}

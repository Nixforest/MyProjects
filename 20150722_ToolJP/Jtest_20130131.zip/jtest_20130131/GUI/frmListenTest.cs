﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Xml;
using System.IO;

namespace JTest.GUI
{
    /// <summary>
    /// Created by ToanNN
    /// </summary>
    public partial class frmListenTest : Form
    {
        List<JTest.Others.ListenQuestion> TestList = new List<Others.ListenQuestion>();
        int intwaitTime = Constant.intWaitForAns;
        private bool mouse_is_down = false;
        private Point mouse_pos;
        string strTestLevel;

        ///@nhannc
        ///
        string message1 = "";
        string thongtin = "";
        string message2 = "";
        string message3 = "";
        string ketquatest = "";
        string fileketqua = "";
        string luulog = "";
        string message4 = "";
        string thongbaoloi = "";

        /// <summary>
        /// Initializes a new instance of the <see cref="frmListenTest"/> class.
        /// </summary>
        /// <param name="Level">The level.</param>
        /// <param name="NumOfTest">The num of test.</param>
        /// <param name="QuestionCount">The question count.</param>
        public frmListenTest(String Level, List<string> WithImageList, List<string> WithoutImageList,int WithImageQue,int NumOfWithimangeTest,int WithoutImageQue, int NumOfWithoutimangeTest)
        {
            InitializeComponent();
            controlLang();
            strTestLevel = Level;
            axWMP.settings.volume = 50;
            sliderVol.Value = axWMP.settings.volume;
            textCurrentQue.Text = "1/" + (NumOfWithimangeTest+NumOfWithoutimangeTest).ToString();
            List<int> randomList = command.createRamdomList(WithImageQue, NumOfWithimangeTest, null);
            foreach (int i in randomList)
            {
                JTest.Others.ListenQuestion questionItemp = new Others.ListenQuestion();
                questionItemp.strfileName = WithImageList[i];
                if (questionItemp.getKey())
                {
                    TestList.Add(questionItemp);
                }
            }

            randomList = command.createRamdomList(WithoutImageQue, NumOfWithoutimangeTest, null);

            foreach (int i in randomList)
            {
                JTest.Others.ListenQuestion questionItemp = new Others.ListenQuestion();
                questionItemp.strfileName = WithoutImageList[i];
                if (questionItemp.getKey())
                {
                    TestList.Add(questionItemp);
                }
            }

            for (int i = 0; i < TestList.Count; i++)
            {
                listBoxQuestion.Items.Add(TestList[i].strfileName);
            }
            if(listBoxQuestion.Items.Count!=0)
            listBoxQuestion.SelectedIndex = 0;
        }

        ///@nhannc
        ///
        private void controlLang()
        {
            try
            {
                XmlNodeList xnList = frmMain.xml.SelectNodes("lang/listentest");
                foreach (XmlNode xn in xnList)
                {
                    //this.Text = xn["title"].InnerText;
                    groupPanelInfo.Text = xn["thongtin"].InnerText;
                    labLevel.Text = xn["capdo"].InnerText;
                    labQuestion.Text = xn["cauhoi"].InnerText;
                    butFinish.Text = xn["ketthuc"].InnerText;

                    groupPanelAnswer.Text = xn["cautraloi"].InnerText;

                    message1 = xn["message1"].InnerText;
                    thongtin = xn["thongtin"].InnerText;
                    message2 = xn["message2"].InnerText;
                    message3 = xn["message3"].InnerText;
                    ketquatest = xn["ketquatest"].InnerText;
                    fileketqua = xn["fileketqua"].InnerText;
                    luulog = xn["luulog"].InnerText;
                    message4 = xn["message4"].InnerText;
                    thongbaoloi = xn["thongbaoloi"].InnerText;
                    labelXNoImageMess.Text = xn["khonghinh"].InnerText;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        /// Handles the Click event of the butFinish control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void butFinish_Click(object sender, EventArgs e)
        {
            if (listBoxQuestion.SelectedIndex < listBoxQuestion.Items.Count - 2)
            {// Todo: need update for multilang
                if (DialogResult.Yes == MessageBox.Show(message1, thongtin, MessageBoxButtons.YesNo, MessageBoxIcon.Information))
                {
                    FinishTest();
                    this.Close();
                }
            }
            else
            {
                FinishTest();
                this.Close();
            }
            
        }

        /// <summary>
        /// Finishes the test.
        /// </summary>
        private void FinishTest()
        {
            try
            {
                int TrueAnswer = JTest.BUS.ListenBUS.checkrResult(TestList);
                // Todo: need update for multilang
                if (DialogResult.Yes == MessageBox.Show(message2 + " " + TrueAnswer.ToString() + "/" + TestList.Count + message3, ketquatest, MessageBoxButtons.YesNo, MessageBoxIcon.Question))
                    while (true)
                    {
                        saveFileDialogListenTested.Filter = fileketqua + "|*.jlog.xml";
                        saveFileDialogListenTested.Title = luulog;
                        if (DialogResult.OK == saveFileDialogListenTested.ShowDialog())
                        {
                            if (!JTest.BUS.ListenBUS.saveTestLog(saveFileDialogListenTested.FileName, TestList, strTestLevel, TrueAnswer.ToString() + " are corrected."))
                            {
                                if (DialogResult.No == MessageBox.Show(message4, thongbaoloi, MessageBoxButtons.YesNo))
                                    break;
                            }
                            else
                                break;
                        }
                        else
                            break;
                    }
            }
            catch
            {

            }
        }

        /// <summary>
        /// Handles the SelectedIndexChanged event of the listBoxQuestion control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void listBoxQuestion_SelectedIndexChanged(object sender, EventArgs e)
        {
            radAnswer1.Checked = false;
            radAnswer2.Checked = false;
            radAnswer3.Checked = false;
            radAnswer4.Checked = false;
            labelXNoImageMess.Visible = false;

            textCurrentQue.Text = (listBoxQuestion.SelectedIndex+1).ToString()+"/" + TestList.Count.ToString();
            string strMp3URL=listBoxQuestion.SelectedItem.ToString();
            string strImageUrl = strMp3URL.Remove(strMp3URL.Length - 3) + "gif";

            if (File.Exists(strImageUrl))
            {
                picQuestion.ImageLocation = strImageUrl;
            }
            else
            {
                strImageUrl = strMp3URL.Remove(strMp3URL.Length - 3) + "jpg";
                if (File.Exists(strImageUrl))
                    picQuestion.ImageLocation = strImageUrl;
                else
                {
                    picQuestion.ImageLocation = null;
                    labelXNoImageMess.Visible = true;
                }
            }
            axWMP.URL = strMp3URL;  

        }

        private void radAnswer1_CheckedChanged(object sender, EventArgs e)
        {
            if ((radAnswer1.Checked) && (listBoxQuestion.SelectedIndex!=-1))
            {
                TestList[listBoxQuestion.SelectedIndex].strAnswer = "1";
            }
        }

        private void radAnswer2_CheckedChanged(object sender, EventArgs e)
        {
            if ((radAnswer2.Checked) && (listBoxQuestion.SelectedIndex != -1))
            {
                TestList[listBoxQuestion.SelectedIndex].strAnswer = "2";
            }
        }

        private void radAnswer3_CheckedChanged(object sender, EventArgs e)
        {
            if ((radAnswer3.Checked) && (listBoxQuestion.SelectedIndex != -1))
            {
                TestList[listBoxQuestion.SelectedIndex].strAnswer = "3";
            }
        }

        private void radAnswer4_CheckedChanged(object sender, EventArgs e)
        {
            if ((radAnswer4.Checked) && (listBoxQuestion.SelectedIndex != -1))
            {
                TestList[listBoxQuestion.SelectedIndex].strAnswer = "4";
            }
        }

        private void axWMP_OpenStateChange(object sender, AxWMPLib._WMPOCXEvents_OpenStateChangeEvent e)
        {
            
        }

        private void timerCountDown_Tick(object sender, EventArgs e)
        {
            if (intwaitTime >= 0)
            {
                intwaitTime--;
                textCountDown.Text = intwaitTime.ToString();
            }
            if (intwaitTime < 0)
            {
                textCountDown.Visible = false;
                if (listBoxQuestion.SelectedIndex < listBoxQuestion.Items.Count - 1)
                {
                    intwaitTime = Constant.intWaitForAns;
                    textCountDown.Text = intwaitTime.ToString();
                    timerCountDown.Enabled = false;
                    listBoxQuestion.SelectedIndex += 1;
                }
                else
                {
                    // todo: thực hiện hàm báo cáo kết quả thi tại đây.
                    timerCountDown.Enabled = false;
                    FinishTest();
                    this.Close();
                   
                }
            }
        }

        private void axWMP_PlayStateChange(object sender, AxWMPLib._WMPOCXEvents_PlayStateChangeEvent e)
        {
            try
            {

                switch (e.newState)
                {

                    case 1:// wmp ở trạng thái stop do bấm nút stop
                    case 2: // wmp ở trạng thái pause
                        break;
                    case 3: // wmp ở trạng thái playing
                        break;
                    case 4: // wmp ở trạng thái connecting to resource
                    case 5: // wmp ở trạng thái bad URL, tức là mở url thất bại
                    case 6: // wmp ở trạng thái buffering...tức bài hát đang được load vào bộ đệm
                    case 8:
                       // if (listBoxQuestion.SelectedIndex < listBoxQuestion.Items.Count - 1)
                        {
                            timerCountDown.Enabled = true;
                            textCountDown.Visible = true;
                            //libPlaylist.SelectedIndex = libPlaylist.SelectedIndex + 1;
                        }
                        //else
                        //{
                        //    MessageBox.Show("Het câu hỏi rồi");
                        //}
                        break;
                    case 9: // wmp ở trạng thái Openning...
                    default:
                        axWMP.Ctlcontrols.play();
                        break;
                }
            }
            catch (Exception ex)
            {
                // throw new Exception(ex.Message);
            }
        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            mouse_pos.X = e.X;
            mouse_pos.Y = e.Y;
            mouse_is_down = true;
        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            if (mouse_is_down)
            {
                Point current_pos = Control.MousePosition;
                current_pos.X = current_pos.X - mouse_pos.X; // .Offset(mouseOffset.X, mouseOffset.Y);
                current_pos.Y = current_pos.Y - mouse_pos.Y;
                this.Location = current_pos;
            }
        }

        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            mouse_is_down = false;
        }

        private void picQuestion_MouseDown(object sender, MouseEventArgs e)
        {
            pictureBox1_MouseDown(sender, e);
        }

        private void picQuestion_MouseMove(object sender, MouseEventArgs e)
        {
            pictureBox1_MouseMove(sender, e);
        }

        private void picQuestion_MouseUp(object sender, MouseEventArgs e)
        {
            pictureBox1_MouseUp(sender, e);
        }

        private void sliderVol_ValueChanged(object sender, EventArgs e)
        {
            axWMP.settings.volume = sliderVol.Value;
        }
       
    }
}

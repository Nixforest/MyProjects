﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.OleDb;
using JTest.BUS;
using JTest.DTO;
using System.Data;
namespace JTest
{
    class DataProvider
    {

        public static OleDbConnection ConnectionData()
        {
            OleDbConnection objConnect;
            String varChuoiConnect = SettingsBUS.ConnectionString;
            objConnect = new OleDbConnection(varChuoiConnect);//Tạo đối tượng Connect                
            objConnect.Open(); //Mở kết nối    
            return objConnect;

            //string cnStr = SettingsBUS.ConnectionString;
            //OleDbConnection cn = new OleDbConnection(cnStr);
        
            //cn.Open();
            //return cn;
        }

        public static OleDbConnection openConnection(string connStr)
        {
            OleDbConnection cn = new OleDbConnection(connStr);
            cn.Open();
            return cn;
        }

        public static OleDbConnection ConnectionDataLog(SettingsPractiseDTO sp)
        {
            
            string cnStr = PracticeLogBUS.ConnectionString(sp);
            OleDbConnection cn = new OleDbConnection(cnStr);
            cn.Open();
            return cn;
        }
    }
}

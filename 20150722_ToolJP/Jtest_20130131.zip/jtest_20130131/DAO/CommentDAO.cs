﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.OleDb;
using System.Data;
using JTest;
using JTest.DTO;
using System.Windows.Forms;

namespace JTest.DAO
{
    // create by DanDQ
    class CommentDAO
    {
        public static bool insert(string connStr, CommentDTO comment)
        {
            bool success = false;
            try
            {
                using (OleDbConnection conn = DataProvider.openConnection(connStr))
                {

                    StringBuilder query = new StringBuilder();
                    query.Append("INSERT INTO Explanation ");
                    query.Append("([TableName],[ID],[Content]) ");
                    query.Append("VALUES('" + comment.TableName + "','" + comment.Id + "','");
                    query.Append(comment.Comment + "')");

                    OleDbCommand cmd = new OleDbCommand();
                    cmd.Connection = conn;
                    cmd.CommandText = query.ToString();

                    int rs = cmd.ExecuteNonQuery();

                    success = (rs == 1) ? true : false;

                }
            }
            catch (OleDbException ex)
            {
                throw ex;
            }

            return success;
        }
        public static bool checkExistTable(string connStr)
        {
            bool success = false;
             try
            {
                using (OleDbConnection connection = new OleDbConnection(connStr))
                {
                    connection.Open();
                    DataTable schemaTable = connection.GetOleDbSchemaTable(
                        OleDbSchemaGuid.Tables,
                        new object[] { null, null, null, "TABLE" });
                    foreach (DataRow row in schemaTable.Rows)
                    {
                        // If we have a table name match, make our return true
                        // and break the looop
                        if ("Explanation".Equals(row.ItemArray[2].ToString()))
                        {
                            success = true;
                            break;
                        }
                    }
                    connection.Close();
                }
            }
            catch (OleDbException ex)
            {
                throw ex;
            }
            return success;
        }
        public static bool createTable(string connStr)
        {
            bool success = false;
            try
            {
                using (OleDbConnection conn = DataProvider.openConnection(connStr))
                {
                    StringBuilder query = new StringBuilder();
                    query.Append("CREATE TABLE Explanation ( ");
                    query.Append("TableName Text, ");
                    query.Append("ID Text, ");
                    query.Append("Content Memo) ");
                    OleDbCommand cmd = new OleDbCommand();
                    cmd.Connection = conn;
                    cmd.CommandText = query.ToString();

                    int rs = cmd.ExecuteNonQuery();

                    success = (rs == 1) ? true : false;

                }
            }
            catch (OleDbException ex)
            {
                throw ex;
            }
            return success;
        }
        public static CommentDTO select(string tableName, string id, string connStr)
        {
            CommentDTO commentDTO = null;
            try
            {
                using (OleDbConnection conn = DataProvider.openConnection(connStr))
                {
                    StringBuilder query = new StringBuilder();
                    query.Append("SELECT TableName, ID, Content FROM Explanation ");
                    query.Append("WHERE TableName = '" + tableName + "' AND ");
                    query.Append("ID = '" + id + "'");

                    OleDbCommand myCommand = new OleDbCommand();
                    OleDbDataReader reader;
                    myCommand.Connection = conn;
                    myCommand.CommandText = query.ToString();
                    reader = myCommand.ExecuteReader();
                    if (reader.Read())
                    {
                        commentDTO = new CommentDTO();
                        commentDTO.Comment = reader["Content"].ToString();
                        commentDTO.Id = reader["ID"].ToString();
                        commentDTO.TableName = reader["TableName"].ToString();
                    }
                }
            }
            catch (OleDbException ex)
            {
                throw ex;
            }
            return commentDTO;
        }
        public static bool update(CommentDTO commentDTO, string connStr)
        {
            bool success = false;
            try
            {
                using (OleDbConnection conn = DataProvider.openConnection(connStr))
                {
                    StringBuilder query = new StringBuilder();
                    query.Append("UPDATE Explanation SET ");
                    query.Append("Content = '" + commentDTO.Comment + "' ");
                    query.Append("WHERE TableName = '" + commentDTO.TableName + "' ");
                    query.Append("AND ID = '" + commentDTO.Id +"'");
                    OleDbCommand cmd = new OleDbCommand();
                    cmd.Connection = conn;
                    cmd.CommandText = query.ToString();

                    int rs = cmd.ExecuteNonQuery();

                    success = (rs == 1) ? true : false;

                }
            }
            catch (OleDbException ex)
            {
                throw ex;
            }
            return success;
        }
    }
}

using System;
using System.Collections.Generic;
using System.Text;
using JTest.DTO;
using System.IO;

namespace JTest.DAO
{
    class SettingsDAO
    {
        /// <summary>
        /// Ham doc setting tu file
        /// </summary>
        /// <param name="filename">kieu string, ten file</param>
        /// <returns>kieu SettingsDTO, chua thong tin setting</returns>
        public static SettingsDTO loadSetting(string filename)
        {
            SettingsDTO s = new SettingsDTO();
            StreamReader r = new StreamReader(AppDomain.CurrentDomain.BaseDirectory+filename);
            //read info
            try
            {
                s.NumberOfQuestion = Int32.Parse(r.ReadLine());
                s.Hour = Int32.Parse(r.ReadLine());
                s.Minute = Int32.Parse(r.ReadLine());
                s.Second = Int32.Parse(r.ReadLine());
                s.Database = r.ReadLine().ToString();// @LuongGV
            }
            catch (Exception e)
            {         
                throw e;
            }
            r.Close();
            //end read info
            return s;
        }

        /// <summary>
        /// Ham ghi setting ra file
        /// </summary>
        /// <param name="filename">kieu string, ten file</param>
        /// <param name="s">kieu SettingsDTO, chu thong tin setting</param>
        public static void saveSetting(string filename, SettingsDTO s)
        {

            StreamWriter w = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory+filename, false);//overwrite neu file dang ton tai
            try 
	        {	        
		        w.WriteLine(s.NumberOfQuestion);
                w.WriteLine(s.Hour);
                w.WriteLine(s.Minute);
                w.WriteLine(s.Second);
                w.WriteLine(s.Database);// @LuongGV
	        }
	        catch (Exception e)
	        {
        		
		        throw e;
	        }
            w.Close();
        }
    }
}

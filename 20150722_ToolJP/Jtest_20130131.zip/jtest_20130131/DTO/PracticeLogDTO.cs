using System;
using System.Collections.Generic;
using System.Text;

namespace JTest.DTO
{
    /// <summary>
    /// @Author: SonLT4, TanLA
    /// @Version: 30092010
    /// </summary>
    public class PracticeLogDTO
    {
        #region Properties
       
        private int[] _id;//mang id
        private int[] _answers;//mang cau tra loi. Values : -1 -> 4. -1: chua lam, 0: lam roi nhung ko chon, 1-4: dap an da chon
        private int[] _statistic;//thong ke cau da lam, cau dung. [0]: so cau da lam, [1]: so cau dung
        private int[] _wrongAnswerIDs;//list id cac cau sai
        
        private SettingsPractiseDTO _settingPractice;//chua thong tin tuy chon luyen tap

        #endregion


        #region get & set methods
        public PracticeLogDTO()
        {
            _statistic = new int[] { 0, 0 };
            _settingPractice = new SettingsPractiseDTO();
        }

        public int[] Id
        {
            get { return _id; }
            set { _id = value; }
        }


        public int[] WrongAnswerIDs
        {
            get { return _wrongAnswerIDs; }
            set { _wrongAnswerIDs = value; }
        }

        public int[] Answers
        {
            get { return _answers; }
            set { _answers = value; }
        }

        public int[] Statistic
        {
            get { return _statistic; }
            set { _statistic = value; }
        }


        public SettingsPractiseDTO SettingPractice
        {
            get { return _settingPractice; }
            set 
            { 
                _settingPractice.From = value.From;
                _settingPractice.To = value.To;
                _settingPractice.Level = value.Level;
                _settingPractice.Mode = value.Mode;
                _settingPractice.Type = value.Type;
                _settingPractice.DbName = value.DbName;
            }
        }
        #endregion
        
        
    }
}

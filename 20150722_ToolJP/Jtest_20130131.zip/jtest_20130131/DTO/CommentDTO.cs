﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JTest.DTO
{
    // Create by DanDQ
    public class CommentDTO
    {
        #region Properties
        private string _tableName;
        private string _id;
        private string _comment;

        public string TableName
        {
            get { return _tableName; }
            set { _tableName = value; }
        }

        public string Id
        {
            get { return _id; }
            set { _id = value; }
        }

        public string Comment
        {
            get { return _comment; }
            set { _comment = value; }
        }

        #endregion
    }
}

using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;

namespace JTest.DTO
{
    class QuestionsMark
    {
        private Rectangle rMark;

        public Rectangle RMark
        {
            get { return rMark; }
            set { rMark = value; }
        }
        private int mIndex;

        public int MIndex
        {
            get { return mIndex; }
            set { mIndex = value; }
        }
    }
}

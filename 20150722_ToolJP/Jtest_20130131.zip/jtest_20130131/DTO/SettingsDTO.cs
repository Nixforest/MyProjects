using System;
using System.Collections.Generic;
using System.Text;

namespace JTest
{
    public class SettingsDTO
    {
        int numberOfQuestion;

        public int NumberOfQuestion
        {
            get { return numberOfQuestion; }
            set { numberOfQuestion = value; }
        }

        int hour;

        public int Hour
        {
            get { return hour; }
            set { hour = value; }
        }

        int minute;

        public int Minute
        {
            get { return minute; }
            set { minute = value; }
        }
        int second;

        public int Second
        {
            get { return second; }
            set { second = value; }
        }

        string db;
        public string Database
        {
            get { return db; }
            set { db = value; }
        }

        //Author: ThemNN
        public SettingsDTO(SettingsDTO dto)
        {
            this.Database = dto.Database;
            this.Hour = dto.Hour;
            this.Minute = dto.Minute;
            this.NumberOfQuestion = dto.NumberOfQuestion;
            this.Second = dto.Second;
        }

        public SettingsDTO()
        {
        }

    }
}

using System;
using System.Collections.Generic;
using System.Text;

namespace JTest.DTO
{
    /// <summary>
    /// @Author: TanLA
    /// @Version: 30092010
    /// Cau truc du lieu cho cac thong tin tuy chon cua man hinh luyen tap
    /// </summary>
    public class SettingsPractiseDTO : SettingsDTO
    {
        #region Properties

        private int from;//id cau bat dau
        private int to;//id cau ket thuc
        private int level;//value : 1-5
        
        private int type;//1 : tu vung, 2: ngu phap
        private int mode;//0: ngau nhien, 1: tuan tu, 2: lam lai cau sai
        private string dbName;// ten db trong file log

        //TrongNV2 Start
        private int levelCharater;//Level cua nguoi choi
        private int currentPoint;//Diem kinh nghiem

        private string avatarName;//ten avatar
        //TrongNV2 End
        #endregion


        #region get & set methods
        public int From
        {
            get { return from; }
            set { from = value; }
        }


        public int To
        {
            get { return to; }
            set { to = value; }
        }


        public int Level
        {
            get { return level; }
            set { level = value; }
        }


        public int Type
        {
            get { return type; }
            set { type = value; }
        }


        public int Mode
        {
            get { return mode; }
            set { mode = value; }
        }

        public string DbName
        {
            get { return dbName; }
            set { dbName = value; }
        }

        //TrongNV2 Start
        public int LevelCharacter
        {
            get { return levelCharater; }
            set { levelCharater = value; }
        }

        public int CurrentPoint
        {
            get { return currentPoint; }
            set { currentPoint = value; }
        }
        public string AvatarName
        {
            get { return avatarName; }
            set { avatarName = value; }
        }
        //TrongNV2 End
        #endregion
        
    }
}

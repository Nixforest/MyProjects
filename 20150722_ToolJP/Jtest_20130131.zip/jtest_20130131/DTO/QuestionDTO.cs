using System;
using System.Collections.Generic;
using System.Text;

namespace JTest.DTO
{
    public class QuestionDTO
    {
        #region Properties
        private int _id;
        private string _question;
        private string _answerA;
        private string _answerB;
        private string _answerC;
        private string _answerD;
        private char answer;
        private string _comment; //ADD, 14/01/2012, KYNX

        public int ID
        {
            get { return _id; }
            set { _id = value; }
        }

        public string Question
        {
            get { return _question; }
            set { _question = value; }
        }

        public string AnswerA
        {
            get { return _answerA; }
            set { _answerA = value; }
        }

        public string AnswerB
        {
            get { return _answerB; }
            set { _answerB = value; }
        }

        public string AnswerC
        {
            get { return _answerC; }
            set { _answerC = value; }
        }


        public string AnswerD
        {
            get { return _answerD; }
            set { _answerD = value; }
        }


        public char Answer
        {
            get { return answer; }
            set { answer = value; }
        }

        #endregion
    }
}


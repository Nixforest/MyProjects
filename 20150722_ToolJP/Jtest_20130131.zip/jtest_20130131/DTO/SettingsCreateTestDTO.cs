using System;
using System.Collections.Generic;
using System.Text;

namespace JTest
{
    public class SettingsCreateTestDTO : SettingsDTO
    {
        public SettingsCreateTestDTO(SettingsDTO dto) : base(dto)
        {
        }
    }
}

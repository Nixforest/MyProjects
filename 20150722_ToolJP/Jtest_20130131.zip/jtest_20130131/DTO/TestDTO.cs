using System;
using System.Collections.Generic;
using System.Text;

namespace JTest.DTO
{
    public class TestDTO
    {
        #region properties
        private List<QuestionDTO> _questions;
        private Dictionary<int,char> _answers;
        private Dictionary<int,bool> _flags;
        private long _time;
        private long _remaintime;
        private int _level;
        private string _type;
        private int _numberOfQuestion;

        public int NumberOfQuestion
        {
            get { return _numberOfQuestion; }
            set { _numberOfQuestion = value; }
        }

        public long Time
        {
            get { return _time; }
            set { _time = value; }
        }

        public long RemainTime
        {
            get { return _remaintime; }
            set { _remaintime = value; }
        }
        public Dictionary<int,char> Answer
        {
            get { return _answers; }
            set { _answers = value; }
        }

        public Dictionary<int,bool> Flag
        {
            get { return _flags; }
            set { _flags = value; }
        }

        public List<QuestionDTO> Question
        {
            get { return _questions; }
            set { _questions = value; }
        }

        public int Level
        {
            get { return _level; }
            set { _level = value; }
        }

        public string Type
        {
            get { return _type; }
            set { _type = value; }
        }
        #endregion

        public TestDTO(List<QuestionDTO> questions , string type,int level,long time)
        {
            this._questions = questions;
            this._type = type;
            this._level = level;
            this._time = time;
            this._numberOfQuestion = questions.Count;
            _flags = new Dictionary<int, bool>(questions.Count);
            _answers = new Dictionary<int, char>(questions.Count);
            this.RemainTime = time;
        }
    }
}

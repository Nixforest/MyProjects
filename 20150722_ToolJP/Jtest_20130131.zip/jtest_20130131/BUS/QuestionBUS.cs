using System;
using System.Collections.Generic;
using System.Text;
using JTest.DAO;
using JTest.DTO;

namespace JTest.BUS
{
    public class QuestionBUS
    {
        public QuestionDTO QuestionDTO
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }
    }
}

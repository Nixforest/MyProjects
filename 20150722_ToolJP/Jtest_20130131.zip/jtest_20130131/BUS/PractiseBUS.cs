using System;
using System.Collections.Generic;
using System.Text;
using JTest.DTO;
using JTest.DAO;

namespace JTest.BUS
{
    public class PractiseBUS
    {
        public SettingsPractiseDTO SettingsPractiseDTO
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        public QuestionDTO QuestionDTO
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        public PracticeLogDTO PracticeLogDTO
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }
    }
}

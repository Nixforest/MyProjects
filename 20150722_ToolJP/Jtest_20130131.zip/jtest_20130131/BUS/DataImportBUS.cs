﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Office.Interop.Excel;
using JTest.DTO;
using JTest.DAO;
using System.IO;
using System.Text.RegularExpressions;

namespace JTest.BUS
{
    class DataImportBUS
    {
        public static int insertData(List<QuestionDTO> list, string db, string type, int level)
        {
            string connStr = "Provider = Microsoft.Jet.OLEDB.4.0; Jet OLEDB:Database Password=" + JTest.Constant.DBPassWord + "; Data Source = " + AppDomain.CurrentDomain.BaseDirectory + "App_Data\\" + db;
            int totalRecord = 0;
            foreach (QuestionDTO q in list)
            {
                bool rs = QuestionDAO.insert(connStr, type, level, q);
                if (rs == true)
                {
                    totalRecord++;
                }
            }
            return totalRecord;
        }
        // DanDQ add - start
        public static int addCommentData(List<CommentDTO> list, string db)
        {
            string connStr = "Provider = Microsoft.Jet.OLEDB.4.0; Jet OLEDB:Database Password=" + JTest.Constant.DBPassWord + "; Data Source = " + AppDomain.CurrentDomain.BaseDirectory + "App_Data\\" + db;
            int totalRecord = 0;
            if (!CommentDAO.checkExistTable(connStr))
            {
                CommentDAO.createTable(connStr);
            }
            foreach (CommentDTO q in list)
            {
                if (CommentDAO.select(q.TableName, q.Id, connStr) == null)
                {
                    if (CommentDAO.insert(connStr, q))
                    {
                        totalRecord++;
                    }
                }
                else
                {
                    if (CommentDAO.update(q, connStr))
                    {
                        totalRecord++;
                    }
                }
            }
            return totalRecord;
        }
        // DanDQ add - end
        public static string createNewDbase(string dbName)
        {
            string savePath;
            Stream objStream = null;
            FileStream objFileStream = null;
            try
            {
                byte[] abytResource;
                System.Reflection.Assembly objAssembly =
            System.Reflection.Assembly.GetExecutingAssembly();

                objStream = objAssembly.GetManifestResourceStream("JTest.template.jtest_template.mdb");
                abytResource = new Byte[objStream.Length];
                objStream.Read(abytResource, 0, (int)objStream.Length);

                savePath = AppDomain.CurrentDomain.BaseDirectory + "App_Data/" + dbName + ".mdb";
                objFileStream = new FileStream(savePath, FileMode.Create);
                objFileStream.Write(abytResource, 0, (int)objStream.Length);
                objFileStream.Close();
            }
            catch (Exception ex)
            {
                throw ;
            }
            finally
            {
                if (objFileStream != null)
                {
                    objFileStream.Close();
                    objFileStream = null;
                }
                if (objStream != null)
                {
                    objStream = null;
                }
            }

            return dbName + ".mdb";
        }

        public static List<QuestionDTO> getQuestionListFromExcel(string filepath)
        {
            List<QuestionDTO> list = new List<QuestionDTO>();

            string Path = filepath;
            // initialize the Excel Application class
            ApplicationClass app = new ApplicationClass();
            // create the workbook object by opening the excel file.
            Workbook workBook = app.Workbooks.Open(Path,
                                                         0,
                                                         true,
                                                         5,
                                                         "",
                                                         "",
                                                         true,
                                                         XlPlatform.xlWindows,
                                                         "\t",
                                                         false,
                                                         false,
                                                         0,
                                                         true,
                                                         1,
                                                         0);
            // get the active worksheet using sheet index 
            Worksheet wsQuestion = (Worksheet)workBook.Worksheets[1];
            // sheet row,column index .
            int rowQIndex = 1;
            int colQIndex = 1;
            int colAIndex = 9;
            try
            {
                while (((Range)wsQuestion.Cells[rowQIndex, colQIndex]).Value2 != null)
                {
                    string question = ((Range)wsQuestion.Cells[rowQIndex, colQIndex]).Value2.ToString();
                    string ansA = ((Range)wsQuestion.Cells[rowQIndex + 2, colQIndex]).Value2.ToString();
                    string ansB = ((Range)wsQuestion.Cells[rowQIndex + 3, colQIndex]).Value2.ToString();
                    string ansC = ((Range)wsQuestion.Cells[rowQIndex + 4, colQIndex]).Value2.ToString();
                    string ansD = ((Range)wsQuestion.Cells[rowQIndex + 5, colQIndex]).Value2.ToString();
                    string answer = ((Range)wsQuestion.Cells[rowQIndex + 6, colAIndex]).Value2.ToString();

                    // jump to next question
                    rowQIndex += 8;

                    // check blank data
                    if (question.Trim().Length == 0 || ansA.Trim().Length == 0
                        || ansB.Trim().Length == 0 || ansC.Trim().Length == 0
                        || ansD.Trim().Length == 0 || answer.Trim().Length == 0)
                    {
                        // not add this question
                        continue;
                    }

                    // create dto obj add to result list
                    QuestionDTO dto = new QuestionDTO();
                    dto.Question = Regex.Replace(question, "問[0-9]*\\.", "");
                    dto.AnswerA = Regex.Replace(ansA, "[ABCD]{1}.", "");
                    dto.AnswerB = Regex.Replace(ansB, "[ABCD]{1}.", "");
                    dto.AnswerC = Regex.Replace(ansC, "[ABCD]{1}.", "");
                    dto.AnswerD = Regex.Replace(ansD, "[ABCD]{1}.", "");
                    dto.Answer = answer[4];
                    list.Add(dto);
                  
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                workBook.Close(false, false, false);
                app.Quit();
                wsQuestion = null;
                workBook = null;
                app = null;
                System.GC.Collect();
            }

            return list;
        }
        //DanDQ add - start
        public static List<CommentDTO> getCommentListFromExcel(string filepath)
        {
            List<CommentDTO> list = new List<CommentDTO>();

            string Path = filepath;
            // initialize the Excel Application class
            ApplicationClass app = new ApplicationClass();
            // create the workbook object by opening the excel file.
            Workbook workBook = app.Workbooks.Open(Path,
                                                         0,
                                                         true,
                                                         5,
                                                         "",
                                                         "",
                                                         true,
                                                         XlPlatform.xlWindows,
                                                         "\t",
                                                         false,
                                                         false,
                                                         0,
                                                         true,
                                                         1,
                                                         0);
            // get the active worksheet using sheet index 
            Worksheet wsQuestion = (Worksheet)workBook.Worksheets[1];
            // sheet row,column index .
            int rowIdx = 3;
            int colTypeIdx = 2;
            int colLevelIdx = 3;
            int colIdIdx = 4; 
            int colCommentIdx = 13;
            
            try
            {
                while (((Range)wsQuestion.Cells[rowIdx, colTypeIdx]).Value2 != null)
                {
                    string type = ((Range)wsQuestion.Cells[rowIdx, colTypeIdx]).Value2 == null? "" : ((Range)wsQuestion.Cells[rowIdx, colTypeIdx]).Value2.ToString();
                    string level = ((Range)wsQuestion.Cells[rowIdx, colLevelIdx]).Value2 == null? "" : ((Range)wsQuestion.Cells[rowIdx, colLevelIdx]).Value2.ToString();
                    string id = ((Range)wsQuestion.Cells[rowIdx, colIdIdx]).Value2 == null? "" : ((Range)wsQuestion.Cells[rowIdx, colIdIdx]).Value2.ToString();
                    string commentstr = ((Range)wsQuestion.Cells[rowIdx, colCommentIdx]).Value2 == null? "" : ((Range)wsQuestion.Cells[rowIdx, colCommentIdx]).Value2.ToString();

                    rowIdx += 1;

                    if (commentstr.Trim().Length == 0 || type.Trim().Length == 0
                        || level.Trim().Length == 0 || id.Trim().Length == 0)
                    {
                        continue;
                    }

                    // create dto obj to add to result list
                    CommentDTO dto = new CommentDTO();
                    dto.TableName = type + "level" + command.convertLevel(level);
                    dto.Id = id;
                    dto.Comment = commentstr;
                    list.Add(dto);

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                workBook.Close(false, false, false);
                app.Quit();
                wsQuestion = null;
                workBook = null;
                app = null;
                System.GC.Collect();
            }

            return list;
        }
        public static bool checkFormatCommentExcel(string filepath)
        {
            bool rslt = false;

            string Path = filepath;
            // initialize the Excel Application class
            ApplicationClass app = new ApplicationClass();
            // create the workbook object by opening the excel file.
            Workbook workBook = app.Workbooks.Open(Path,
                                                         0,
                                                         true,
                                                         5,
                                                         "",
                                                         "",
                                                         true,
                                                         XlPlatform.xlWindows,
                                                         "\t",
                                                         false,
                                                         false,
                                                         0,
                                                         true,
                                                         1,
                                                         0);
            // get the active worksheet using sheet index 
            Worksheet wsQuestion = (Worksheet)workBook.Worksheets[1];
            // sheet row,column index .
            int rowIdx = 2;
            int colTypeIdx = 2;
            int colLevelIdx = 3;
            int colIdIdx = 4;
            int colCommentIdx = 13;

            try
            {
                    string type = ((Range)wsQuestion.Cells[rowIdx, colTypeIdx]).Value2 == null ? "" : ((Range)wsQuestion.Cells[rowIdx, colTypeIdx]).Value2.ToString();
                    string level = ((Range)wsQuestion.Cells[rowIdx, colLevelIdx]).Value2 == null ? "" : ((Range)wsQuestion.Cells[rowIdx, colLevelIdx]).Value2.ToString();
                    string id = ((Range)wsQuestion.Cells[rowIdx, colIdIdx]).Value2 == null ? "" : ((Range)wsQuestion.Cells[rowIdx, colIdIdx]).Value2.ToString();
                    string commentstr = ((Range)wsQuestion.Cells[rowIdx, colCommentIdx]).Value2 == null ? "" : ((Range)wsQuestion.Cells[rowIdx, colCommentIdx]).Value2.ToString();

                    if ("解説".Equals(commentstr.Trim()) && "形".Equals(type.Trim())
                        && "水準".Equals(level.Trim()) && "ID".Equals(id.Trim()))
                    {
                        rslt = true;
                    }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                workBook.Close(false, false, false);
                app.Quit();
                wsQuestion = null;
                workBook = null;
                app = null;
                System.GC.Collect();
            }

            return rslt;
        }
        //DanDQ add - end
        public static List<QuestionDTO> getQuestionListFromStatisticalTables(string filepath)
        {
            List<QuestionDTO> list = new List<QuestionDTO>();

            string Path = filepath;
            // initialize the Excel Application class
            ApplicationClass app = new ApplicationClass();
            // create the workbook object by opening the excel file.
            Workbook workBook = app.Workbooks.Open(Path,
                                                         0,
                                                         true,
                                                         5,
                                                         "",
                                                         "",
                                                         true,
                                                         XlPlatform.xlWindows,
                                                         "\t",
                                                         false,
                                                         false,
                                                         0,
                                                         true,
                                                         1,
                                                         0);
            // get the active worksheet using sheet index 
            Worksheet wsQuestion = (Worksheet)workBook.Worksheets[1];
            // sheet row,column index .
            int rowQIndex = 3;
            int Question=5;
            int A=6;
            int B=7;
            int C = 8;
            int D = 9;
            int Answer = 10;

            try
            {
                while (((Range)wsQuestion.Cells[rowQIndex, Question]).Value2 != null)
                {
                    string question = ((Range)wsQuestion.Cells[rowQIndex, Question]).Value2.ToString();
                    string ansA = ((Range)wsQuestion.Cells[rowQIndex, A]).Value2.ToString();
                    string ansB = ((Range)wsQuestion.Cells[rowQIndex, B]).Value2.ToString();
                    string ansC = ((Range)wsQuestion.Cells[rowQIndex, C]).Value2.ToString();
                    string ansD = ((Range)wsQuestion.Cells[rowQIndex, D]).Value2.ToString();
                    string answer = ((Range)wsQuestion.Cells[rowQIndex, Answer]).Value2.ToString();

                    // jump to next question
                    rowQIndex ++;

                     //check blank data
                    if (question.Trim().Length == 0 || ansA.Trim().Length == 0
                        || ansB.Trim().Length == 0 || ansC.Trim().Length == 0
                        || ansD.Trim().Length == 0 || answer.Trim().Length == 0)
                    {
                        // not add this question
                        continue;
                    }

                    // create dto obj add to result list
                    QuestionDTO dto = new QuestionDTO();
                   
                    dto.Question = question;
                    dto.AnswerA = ansA;
                    dto.AnswerB = ansB;
                    dto.AnswerC = ansC;
                    dto.AnswerD = ansD;
                    dto.Answer =answer[0];
                    list.Add(dto);

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                workBook.Close(false, false, false);
                app.Quit();
                wsQuestion = null;
                workBook = null;
                app = null;
                System.GC.Collect();
            }
            return list;
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;
using JTest.DAO;
using System.IO;
using System.Reflection;

namespace JTest.BUS
{
    class SettingsBUS
    {
        static string filename = "jtest.config";//ten file chua setting, mac dinh nam chung thu muc voi file thuc thi

        /// <summary>
        /// Ham doc thong tin setting tu file
        /// </summary>
        /// <returns>kieu SettingsDTO, chua thong tin settings</returns>
        public static SettingsDTO loadSettingInfoFromFile()
        {
            SettingsDTO s = new SettingsDTO();
            try
            {
                s = SettingsDAO.loadSetting(filename);
            }
            catch (Exception e)
            {
                
                throw e; 
            }
            return s;
        }

        /// <summary>
        /// Ham luu thong tin setting ra file
        /// </summary>
        /// <param name="?">kieu SettingsDTO, chua thong tin setting</param>
        public static void saveSettingInfoToFile(SettingsDTO s)
        {
            try
            {
                SettingsDAO.saveSetting(filename, s);
            }
            catch (Exception e)
            {
                
                throw e;
            }
        }

        /// <summary>
        /// @Author LuongGV
        /// Update by ToanNN 
        /// Gets or sets the connection string.
        /// </summary>
        /// <value>The connection string.</value>
        public static string ConnectionString //ToanNN
        {
            get {
                try
                {

                    string currentDB = loadSettingInfoFromFile().Database;
                    {
                        if (File.Exists(AppDomain.CurrentDomain.BaseDirectory + "App_Data\\" + currentDB))
                        {
                            return "Provider = Microsoft.Jet.OLEDB.4.0; Jet OLEDB:Database Password=" + JTest.Constant.DBPassWord + "; Data Source = " + AppDomain.CurrentDomain.BaseDirectory + "App_Data\\" + currentDB;
                        }
                        string strConnectString = "";
                        strConnectString =command.GetTempDirectory();
                        command.extractDB(strConnectString);
                        strConnectString = "Provider = Microsoft.Jet.OLEDB.4.0; Jet OLEDB:Database Password=" + JTest.Constant.DBPassWord + "; Data Source = " + strConnectString + "\\data.dat";
                        return strConnectString;
                    }
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);
                }
            }
        }

        /// @Author LuongGB
        /// <summary>
        /// Loads databases name
        /// </summary>
        /// <returns></returns>
        public static List<string> loadDbaseSources()
        {
            List<string> list = new List<string>();
            DirectoryInfo dic = new DirectoryInfo(AppDomain.CurrentDomain.BaseDirectory + "App_Data\\");
            FileInfo[] fileInfo = dic.GetFiles("*.mdb");

            foreach (FileInfo f in fileInfo)
            {
                list.Add(f.Name);
            }

            return list;
        }
    }
}

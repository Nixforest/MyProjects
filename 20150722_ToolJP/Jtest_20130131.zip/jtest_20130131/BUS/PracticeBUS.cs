using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using JTest;
using JTest.DTO;
using JTest.DAO;

namespace JTest.BUS
{
    /// <summary>
    /// @Author: SonLT4
    /// @Version: 30092010
    /// </summary>
    public class PracticeBUS
    {
        /// <summary>
        /// Ham lay ve mot so cau hoi ngau nhien trong mot khoang cua CSDL
        /// , chuc nang ra de ngau nhien trong khoang cho man hinh luyen tap
        /// </summary>
        /// <param name="begin">kieu int, chua ID cua cau hoi bat dau</param>
        /// <param name="end">kieu int, chua ID cua cau hoi ket thuc</param>
        /// <param name="level">kieu int, chua cap do cau hoi</param>
        /// <param name="type">kieu string, chua loai cau hoi</param>
        /// <returns>mang cac QuestionDTO,chua thong tin cau hoi</returns>
        public static List<QuestionDTO> getQuestionListInRandomOrder(int begin, int end, int level, string type)
        {
            List<QuestionDTO> l = new List<QuestionDTO>();
            try
            {
                List<QuestionDTO> temp = QuestionDAO.getQuestionListInRange(begin, end, level, type);
                int[] order = Utils.getRandomIntegerList(end - begin + 1);

                int intRandom = -1;
                Random random = new Random();
                int intRightAns = 0;
                for (int i = 0; i < order.Length; i++)
                {
                    QuestionDTO q = new QuestionDTO();
                    q.ID = temp[order[i]].ID;
                    q.AnswerA = temp[order[i]].AnswerA;
                    q.AnswerB = temp[order[i]].AnswerB;
                    q.AnswerC = temp[order[i]].AnswerC;
                    q.AnswerD = temp[order[i]].AnswerD;
                    q.Answer = temp[order[i]].Answer;
                    q.Question = temp[order[i]].Question;
                    #region<Dao vi tri cau hoi>
                    // ToanNN
                    if (q.Answer == 'A')
                    {
                        intRightAns = 1;
                    }
                    else if (q.Answer == 'B')
                    {
                        intRightAns = 2;
                    }
                    else if (q.Answer == 'C')
                    {
                        intRightAns = 3;
                    }
                    else
                    {
                        intRightAns = 4;
                    }
                    intRandom = random.Next(5);
                    string a = q.AnswerA;
                    string b = q.AnswerB;
                    string c = q.AnswerC;
                    string d = q.AnswerD;

                    if (q.Answer == 'A')
                    {
                        if (intRandom == 2)
                        {
                            command.SwapString(ref a, ref b);
                            q.Answer = 'B';
                        }
                        else if (intRandom == 3)
                        {
                            command.SwapString(ref a, ref c);
                            q.Answer = 'C';
                        }
                        else if (intRandom == 4)
                        {
                            command.SwapString(ref a, ref d);
                            q.Answer = 'D';
                        }
                    }
                    else if (q.Answer == 'B')
                    {
                        if (intRandom == 1)
                        {
                            command.SwapString(ref a, ref b);
                            q.Answer = 'A';
                        }
                        else if (intRandom == 3)
                        {
                            command.SwapString(ref b, ref c);
                            q.Answer = 'C';
                        }
                        else if (intRandom == 4)
                        {
                            command.SwapString(ref b, ref d);
                            q.Answer = 'D';
                        }
                    }
                    else if (q.Answer == 'C')
                    {
                        if (intRandom == 1)
                        {
                            command.SwapString(ref a, ref c);
                            q.Answer = 'A';
                        }
                        else if (intRandom == 2)
                        {
                            command.SwapString(ref b, ref c);
                            q.Answer = 'B';
                        }
                        else if (intRandom == 4)
                        {
                            command.SwapString(ref c, ref d);
                            q.Answer = 'D';
                        }
                    }
                    else if (q.Answer == 'D')
                    {
                        if (intRandom == 2)
                        {
                            command.SwapString(ref d, ref b);
                            q.Answer = 'B';
                        }
                        else if (intRandom == 3)
                        {
                            command.SwapString(ref d, ref c);
                            q.Answer = 'C';
                        }
                        else if (intRandom == 1)
                        {
                            command.SwapString(ref a, ref d);
                            q.Answer = 'A';
                        }
                    }

                    q.AnswerA = a;
                    q.AnswerB = b;
                    q.AnswerC = c;
                    q.AnswerD = d;
                    #endregion<Doi vi tri cau hoi>
                    l.Add(q);
                }
            }
            catch(Exception e)
            {
                throw e;
            }
            return l;
        }

        /// <summary>
        /// Ham lay ve mot so cau hoi tuan tu trong mot khoang cua CSDL
        /// , chuc nang ra de tuan tu trong khoang cho man hinh luyen tap
        /// </summary>
        /// <param name="num">kieu int, chua so luong cau hoi can lay</param>
        /// <param name="begin">kieu int, chua ID cau hoi bat dau</param>
        /// <param name="level">kieu int, chua cap do cau hoi</param>
        /// <param name="type">kieu string, chua loai cau hoi</param>
        /// <returns>mang cac QuestionDTO, chua thong tin cau hoi</returns>
        public static List<QuestionDTO> getQuestionListInSuccessionOrder(int begin, int end, int level, string type)
        {
            try
            {
                return QuestionDAO.getQuestionListInRange(begin, end, level, type);
            }
            catch (Exception e)
            {
                
                throw e;
            }
        }

        /// <summary>
        /// Ham lay ve mang cac danh sach theo cac ids cho truoc
        /// , chuc nang lam lai cac cau sai trong lan luyen tap truoc
        /// </summary>
        /// <param name="ids">kieu int[], chua list cac ids</param>
        /// <param name="level">kieu int, chua level cau hoi</param>
        /// <param name="type">kieu string, chua loai cau hoi</param>
        /// <returns>mang cac QuestionDTO,chua thong tin cau hoi</returns>
        public static List<QuestionDTO> getQuestionsFromIDsList(int[] ids, int level, string type)
        {
            try
            {
                return QuestionDAO.getQuestionsFromIDsList(ids, level, type);
            }
            catch(Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// Ham lay id cuoi cung trong danh sach
        /// </summary>
        /// <param name="table">kieu string, ten bang</param>
        /// <returns>kieu int, id cua cau hoi cuoi cung trong bang</returns>
        public int getMaxID(string table)
        {
            QuestionDAO qDAO = new QuestionDAO();
            int id = qDAO.getMaxID(table);
            return id;
        }

        /// <summary>
        /// Ham lay mot mang cac cau hoi lien tiep tu CSDL, ten CSDL luu trong SettingPractice
        /// </summary>
        /// <param name="sp">kieu SettingPractice, chua thong tin luyen tap</param>
        /// <returns>mang cac QuestionDTO</returns>
        public static List<QuestionDTO> getQuestionListInSuccessionOrder(SettingsPractiseDTO sp)
        {
            try
            {
                return QuestionDAO.getQuestionListInRange(sp.From,sp.To,sp.Level,
                    (sp.Type == 1) ? "vocabulary" : "grammar", DataProvider.ConnectionDataLog(sp));
            }
            catch (Exception e)
            {

                throw e;
            }
        }

        /// <summary>
        /// Ham lay mot mang cac cau hoi theo IDs cho truoc tu CSDL, ten CSDL luu trong SettingPractice
        /// </summary>
        /// <param name="ids">kieu int[], mang cac IDS cua cau hoi can lay</param>
        /// <param name="sp">kieu SettingPracticeDTO, chua thong tin luyen tap</param>
        /// <returns>mang cac QuestionDTO</returns>
        public static List<QuestionDTO> getQuestionsFromIDsList(int[] ids, SettingsPractiseDTO sp)
        {
            try
            {
                return QuestionDAO.getQuestionsFromIDsList(ids, sp.Level, 
                    (sp.Type == 1) ? "vocabulary" : "grammar", DataProvider.ConnectionDataLog(sp));
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        // DanDQ add - start
        public static CommentDTO getComment(string tableName, string id, string db)
        {
            CommentDTO commentDTO = null;
            string connStr = "Provider = Microsoft.Jet.OLEDB.4.0; Jet OLEDB:Database Password=" + JTest.Constant.DBPassWord + "; Data Source = " + AppDomain.CurrentDomain.BaseDirectory + "App_Data\\" + db;
            if (CommentDAO.checkExistTable(connStr))
            {
                commentDTO = CommentDAO.select(tableName, id, connStr);    
            }
            return commentDTO;
        }
        // DanDQ add - end
    }
}

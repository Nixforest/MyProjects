﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Xml;

namespace JTest.BUS
{
    class ListenBUS
    {
        /// Created by ToanNN
        /// <summary>
        /// Gets the levels list.
        /// </summary>
        /// <returns>List of Level or null if can't get list of Level</returns>
        public static List<string> GetSubDirList(string Path)
        {
            try
            {
                List<string> Level = new List<string>();
                //string mediPath = AppDomain.CurrentDomain.BaseDirectory + "media";
                DirectoryInfo subDirs = new DirectoryInfo(Path);
                DirectoryInfo[] dirs = subDirs.GetDirectories();
                foreach (DirectoryInfo dir in dirs)
                {
                    if(!dir.Name.Contains("."))
                    Level.Add(dir.Name);
                }
                if (Level.Count == 0)
                    return null;
                return Level;
            }
            catch
            {
                return null;
            }
        }

        //public static List<string> GetTopicssList(string strLevel)
        //{
        //    List<string> Topic = new List<string>();
        //    string mediPath = AppDomain.CurrentDomain.BaseDirectory + "media\\"+strLevel;
        //    DirectoryInfo mediaDir = new DirectoryInfo(mediPath);
        //    DirectoryInfo[] dirs = mediaDir.GetDirectories();
        //    foreach (DirectoryInfo dir in dirs)
        //    {
        //        if (!dir.Name.Contains("."))
        //            Level.Add(dir.Name);
        //    }
        //    if (Level.Count == 0)
        //        return null;
        //    return Level;

        //    return null;
        //}
        /// <summary>
        /// Checkrs the result.
        /// </summary>
        /// <param name="List">The list.</param>
        /// <returns></returns>
        public static int checkrResult(List<JTest.Others.ListenQuestion> List)
        {
            int countTrue=0;
            foreach(JTest.Others.ListenQuestion item in List)
            {
                if (item.isTrue()==1)
                {
                    countTrue++;
                }
            }

            return countTrue;
        }

        /// <summary>
        /// Saves the test log.
        /// </summary>
        /// <param name="path">The path.</param>
        /// <param name="testedList">The tested list.</param>
        /// <returns>If save success -> true else ->false</returns>
        public static bool saveTestLog(string path, List<JTest.Others.ListenQuestion> testedList,string strlevel,string strTrueAnswer)
        {
            try
            {
                int items = testedList.Count;

                XmlTextWriter myXmlTextWriter = null;
                myXmlTextWriter = new XmlTextWriter(path, null);

                myXmlTextWriter.Formatting = Formatting.Indented;
                myXmlTextWriter.WriteStartDocument(false);
                myXmlTextWriter.WriteComment("Level:"+strlevel);
                myXmlTextWriter.WriteComment(strTrueAnswer+"/"+testedList.Count.ToString());
                myXmlTextWriter.WriteStartElement("questions");
                //start node
                for (int i = 0; i < items; ++i)
                {
                    myXmlTextWriter.WriteStartElement("question", null);
                    //myXmlTextWriter.WriteAttributeString("genre", "autobiography");                                
                    myXmlTextWriter.WriteElementString("strfileName", testedList[i].strfileName);
                    myXmlTextWriter.WriteElementString("strKey", testedList[i].strKey);
                    myXmlTextWriter.WriteElementString("strAnswer", testedList[i].strAnswer);
                    myXmlTextWriter.WriteEndElement();
                }
                //end node

                myXmlTextWriter.WriteEndElement();

                //Write the XML to file and close the writer
                myXmlTextWriter.Flush();
                myXmlTextWriter.Close();
                if (myXmlTextWriter != null)
                    myXmlTextWriter.Close();
                return true;
            }
            catch 
            {
               // MessageBox.Show(ex.Message);
                return false;
            }
        }

        /// <summary>
        /// Reads the tested log file.
        /// </summary>
        /// <param name="path">The path.</param>
        /// <returns>If load success -> List of question else ->null</returns>
        public static List<JTest.Others.ListenQuestion> readTestedLogFile(string path)
        {
            List<JTest.Others.ListenQuestion> testedList = new List<JTest.Others.ListenQuestion>();
            try
            {
                XmlDocument xml = new XmlDocument();
                xml.Load(path);
                XmlNodeList xnList = xml.SelectNodes("/questions/question");
                foreach (XmlNode xn in xnList)
                {
                    JTest.Others.ListenQuestion ques = new JTest.Others.ListenQuestion();
                    ques.strfileName = xn["strfileName"].InnerText;
                    ques.strKey = xn["strKey"].InnerText;
                    ques.strAnswer += xn["strAnswer"].InnerText;
                    testedList.Add(ques);
                }

                return testedList;
            }
            catch 
            {
                //MessageBox.Show(ex.Message);
                return null;
            }
        }
    }
}

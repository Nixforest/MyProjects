﻿using System;
using System.Collections.Generic;
using System.Text;
using JTest;
using JTest.DTO;
using JTest.DAO;


namespace JTest.BUS
{
    /// <summary>
    /// @Author: TanLA
    /// @Version: 30092010
    /// </summary>
    public class PracticeLogBUS
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="file"></param>
        /// <returns></returns>
        public static PracticeLogDTO loadPracticeLog(string file)
        {
            PracticeLogDTO practiceLog = new PracticeLogDTO();
            PracticeLogDAO practiceLogDAO = new PracticeLogDAO();
            practiceLog = practiceLogDAO.loadPracticeLog(file);
            
            return practiceLog;
        
        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="filename"></param>
        /// <param name="practiceLog"></param>
        /// <returns></returns>
        public static bool createPracticeLog(string filename, PracticeLogDTO practiceLog)
        {
            
            PracticeLogDAO pLogDAO = new PracticeLogDAO();
            pLogDAO.createPracticeLog(@filename,practiceLog);
            return true;
            
        }

        /// <summary>
        /// Ham xuat danh sach cau sai ra file excel
        /// </summary>
        /// <param name="filename">kieu string, chua ten file excel</param>
        /// <param name="p">kieu PracticeLogDTO, chua thong tin log luyen tap</param>
        /// <returns></returns>
        public static bool exportWrongAnswersToExcel(string filename, PracticeLogDTO p)
        {
            try
            {
                PracticeLogDAO.exportToExcelFile(filename, p);
            }
            catch (Exception e)
            {

                throw e;
            }
            return true;
        }

        public static string ConnectionString(SettingsPractiseDTO spDTO)
        {
            try
            {
                return PracticeLogDAO.ConnectionString(spDTO);
            }
            catch(Exception e)
            {
                throw e;
            }

        }

        /// <summary>
        /// 
        /// </summary>
        public PracticeLogDTO PracticeLogDTO
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }
    }
}
